<?php
ob_start();
// ============================================================================
// BARANGAY HEALTH WORKER (BHW) DASHBOARD - STANDALONE FILE
// ============================================================================
// Complete self-contained dashboard for BHW portal in ScanCare application
// Features: Patient identification, consultations, inventory, appointments, SMS
// ============================================================================

session_start();
require_once 'db_config.php';

// Temporary POST debugger removed to ensure AJAX endpoints return clean JSON.
// Log POST submissions to error log instead of printing HTML (prevents JSON parse errors).
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    error_log("POST received on dashboard_bhw.php: " . print_r($_POST, true));
}

// --- SEMAPHORE SMS HELPER (temporary placement) ---
function sendScanCareAlert($number, $message) {
    $ch = curl_init();
    $parameters = array(
        'apikey' => 'f43478ec3207194df9db9f90ba337fa0',
        'number' => $number,
        'message' => $message,
        'sendername' => 'SEMAPHORE'
    );
    curl_setopt($ch, CURLOPT_URL, 'https://api.semaphore.co/api/v4/messages');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($parameters));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $output = curl_exec($ch);
    $err = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return ['output' => $output, 'error' => $err, 'http_code' => $httpCode];
}

// Residents render a read-only community surveillance widget from their
// dashboard. Handle that request before the worker-only dashboard guard so a
// resident request cannot destroy the resident's authenticated session.
if ($_SERVER['REQUEST_METHOD'] === 'GET'
    && ($_GET['action'] ?? '') === 'get_surveillance_metrics'
    && ($_SESSION['user_type'] ?? '') === 'resident') {
    header('Content-Type: application/json; charset=utf-8');

    try {
        $residentMetricsPdo = getDatabaseConnection();
        if ($residentMetricsPdo === false) {
            throw new RuntimeException('Database connection failed.');
        }

        $residentMetricsPdo->exec("CREATE TABLE IF NOT EXISTS surveillance_metrics (
            id INT AUTO_INCREMENT PRIMARY KEY,
            worker_id INT NOT NULL,
            reporting_period VARCHAR(255) DEFAULT NULL,
            dengue_count INT DEFAULT 0,
            dengue_trend VARCHAR(255) DEFAULT NULL,
            dengue_meta VARCHAR(255) DEFAULT NULL,
            dengue_progress INT DEFAULT 0,
            rabies_count INT DEFAULT 0,
            rabies_trend VARCHAR(255) DEFAULT NULL,
            rabies_meta VARCHAR(255) DEFAULT NULL,
            rabies_progress INT DEFAULT 0,
            respiratory_count INT DEFAULT 0,
            respiratory_trend VARCHAR(255) DEFAULT NULL,
            respiratory_meta VARCHAR(255) DEFAULT NULL,
            respiratory_progress INT DEFAULT 0,
            nutrition_count INT DEFAULT 0,
            nutrition_trend VARCHAR(255) DEFAULT NULL,
            nutrition_meta VARCHAR(255) DEFAULT NULL,
            nutrition_progress INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $residentMetricsStmt = $residentMetricsPdo->query(
            'SELECT * FROM surveillance_metrics ORDER BY updated_at DESC LIMIT 1'
        );

        ob_clean();
        echo json_encode($residentMetricsStmt->fetch(PDO::FETCH_ASSOC) ?: new stdClass());
    } catch (Exception $e) {
        error_log('RESIDENT SURVEILLANCE METRICS ERROR: ' . $e->getMessage());
        http_response_code(500);
        ob_clean();
        echo json_encode(['success' => false, 'message' => 'Unable to load surveillance metrics.']);
    }
    exit;
}

// Trigger a live alert when the Publish Updates button was clicked
// Log the Semaphore response instead of printing HTML so JSON responses remain valid.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['publish_updates'])) {
    $res = sendScanCareAlert('09984026995', 'Hi this is RHU II and your appointment is getting close to time');
    error_log("Semaphore send result: " . print_r($res, true));
}

// ============================================================================
// SESSION PROTECTION - BHW AUTHENTICATION GUARD
// ============================================================================
// Verify BHW is logged in with proper session variables
// Redirect unauthorized users cleanly to login.php
// ============================================================================

$sessionWorkerRole = strtolower($_SESSION['worker_role'] ?? $_SESSION['user_role'] ?? $_SESSION['user_type'] ?? 'guest');
$validBhwRoles = ['bhw', 'worker', 'health_worker'];
$sessionWorkerId = $_SESSION['worker_id'] ?? $_SESSION['user_id'] ?? null;

if ($sessionWorkerId === null ||
    ($_SESSION['user_type'] ?? '') !== 'health_worker' ||
    !in_array($sessionWorkerRole, $validBhwRoles, true)) {
    header('Location: login.php');
    exit;
}

// Retrieve worker identity from session
$worker_id = intval($sessionWorkerId);
$worker_name = $_SESSION['user_name'] ?? 'Health Worker';
$worker_email = $_SESSION['email'] ?? '';
$announcementStatus = $_GET['announcement_status'] ?? '';
$requestedAnnouncementTab = $_GET['announcement_tab'] ?? 'create';
$requestedAnnouncementState = $_GET['announcement_state'] ?? 'upcoming';
$announcementTab = in_array($requestedAnnouncementTab, ['create', 'manage'], true) ? $requestedAnnouncementTab : 'create';
$announcementState = in_array($requestedAnnouncementState, ['upcoming', 'now', 'done'], true) ? $requestedAnnouncementState : 'upcoming';
$manual_search_token_expires = time() + 3600;
$manual_search_token_payload = $worker_id . '|' . $manual_search_token_expires;
$manual_search_token = base64_encode($manual_search_token_payload . '|' . hash_hmac('sha256', $manual_search_token_payload, DB_NAME . '|' . DB_USER . '|' . DB_PASS));

try {
    $announcementPdo = getDatabaseConnection();
    if ($announcementPdo !== false) {
        $announcementPdo->exec("CREATE TABLE IF NOT EXISTS health_announcements (
            announcement_id INT AUTO_INCREMENT PRIMARY KEY,
            worker_id INT NOT NULL,
            title VARCHAR(150) NOT NULL,
            message TEXT NOT NULL,
            service_date DATE DEFAULT NULL,
            location VARCHAR(150) DEFAULT NULL,
            state VARCHAR(20) NOT NULL DEFAULT 'upcoming',
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_active_date (is_active, service_date, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        if (!hasTableColumn($announcementPdo, 'health_announcements', 'state')) {
            $announcementPdo->exec("ALTER TABLE health_announcements ADD COLUMN state VARCHAR(20) NOT NULL DEFAULT 'upcoming'");
        }
    }
} catch (Exception $e) {
    error_log('ANNOUNCEMENT TABLE SETUP ERROR: ' . $e->getMessage());
}

// Initialize module states for tab navigation
$active_module = $_GET['module'] ?? 'identify-patient';
$patient_identified = false;
$patient_data = null;

// ================================================================
// LOAD PATIENT PROFILE DATA IF PATIENT_ID IS PROVIDED
// ================================================================
if (isset($_GET['patient_id']) && $active_module === 'patient-profile') {
    $patient_id = intval($_GET['patient_id']);
    
    if ($patient_id > 0) {
        try {
            $pdo = getDatabaseConnection();
            error_log("DEBUG: Loading patient profile for resident_id = {$patient_id}");
            
            // Fetch patient basic information
            $patient_query = "
                SELECT 
                    resident_id,
                    patient_code,
                    full_name,
                    email,
                    contact_number,
                    date_of_birth,
                    address
                FROM resident
                WHERE resident_id = ?
                LIMIT 1
            ";
            
            $stmt = $pdo->prepare($patient_query);
            if (!$stmt) {
                throw new Exception("Failed to prepare resident query: " . implode(", ", $pdo->errorInfo()));
            }
            
            if (!$stmt->execute([$patient_id])) {
                throw new Exception("Failed to execute resident query: " . implode(", ", $stmt->errorInfo()));
            }
            
            $resident = $stmt->fetch(PDO::FETCH_ASSOC);
            error_log("DEBUG: Resident query result: " . ($resident ? "Found resident" : "No resident found"));
            
            if ($resident) {
                $resident['patient_code'] = ensureResidentPatientCode($pdo, (int)$resident['resident_id']);
                $patient_identified = true;
                $patient_data = $resident;
                error_log("DEBUG: Patient identified - {$resident['full_name']}");
                
                // Fetch medical history (uses user_id foreign key)
                $history_query = "
                    SELECT 
                        history_id,
                        user_id,
                        visit_date,
                        visit_type,
                        bhw_name,
                        diagnosis,
                        treatment,
                        notes,
                        created_at
                    FROM medical_history
                    WHERE user_id = ?
                    ORDER BY created_at DESC
                    LIMIT 10
                ";
                
                $stmt = $pdo->prepare($history_query);
                if (!$stmt) {
                    throw new Exception("Failed to prepare medical_history query: " . implode(", ", $pdo->errorInfo()));
                }
                
                if (!$stmt->execute([$patient_id])) {
                    throw new Exception("Failed to execute medical_history query: " . implode(", ", $stmt->errorInfo()));
                }
                
                $medical_history = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
                $patient_data['medical_history'] = $medical_history;
                error_log("DEBUG: Medical history records found: " . count($medical_history));
                
                // Fetch follow-up check-ups (flagged appointments)
                $followup_query = "
                    SELECT 
                        appointment_id,
                        resident_id,
                        appointment_date,
                        appointment_time,
                        purpose,
                        status,
                        updated_at
                    FROM appointment
                    WHERE resident_id = ? AND status = 'flagged'
                    ORDER BY appointment_date ASC, appointment_time ASC
                    LIMIT 10
                ";
                
                $stmt = $pdo->prepare($followup_query);
                if (!$stmt) {
                    throw new Exception("Failed to prepare follow-up query: " . implode(", ", $pdo->errorInfo()));
                }
                
                if (!$stmt->execute([$patient_id])) {
                    throw new Exception("Failed to execute follow-up query: " . implode(", ", $stmt->errorInfo()));
                }
                
                $followup_checkups = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
                $patient_data['followup_checkups'] = $followup_checkups;
                error_log("DEBUG: Follow-up check-up records found: " . count($followup_checkups));
                
                // Fetch appointments
                $appointment_query = "
                    SELECT 
                        appointment_id,
                        resident_id,
                        appointment_date,
                        appointment_time,
                        purpose,
                        status,
                        updated_at
                    FROM appointment
                    WHERE resident_id = ?
                    ORDER BY appointment_date DESC, appointment_time DESC
                    LIMIT 10
                ";
                
                $stmt = $pdo->prepare($appointment_query);
                if (!$stmt) {
                    throw new Exception("Failed to prepare appointment query: " . implode(", ", $pdo->errorInfo()));
                }
                
                if (!$stmt->execute([$patient_id])) {
                    throw new Exception("Failed to execute appointment query: " . implode(", ", $stmt->errorInfo()));
                }
                
                $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
                $patient_data['appointments'] = $appointments;
                error_log("DEBUG: Appointment records found: " . count($appointments));
                
                error_log("✓ Patient profile loaded successfully for ID: {$patient_id}");
            } else {
                error_log("DEBUG: Resident not found for ID: {$patient_id}");
                $patient_identified = false;
                $patient_data = null;
            }
        } catch (Exception $e) {
            error_log("❌ Error loading patient profile: " . $e->getMessage());
            error_log("Exception trace: " . $e->getTraceAsString());
            $patient_identified = false;
            $patient_data = null;
        }
    }
}

// Determine connectivity state (frontend simulation - hardcoded)
$is_online = true; // In production, detect via JavaScript or backend logic

// ================================================================
// FETCH APPROVED PATIENTS FOR CONSULTATION DROPDOWN
// ================================================================
$approved_patients = [];
try {
    $pdo = getDatabaseConnection();
    $approved_query = "
        SELECT 
            a.appointment_id,
            a.resident_id,
            r.full_name as patient_name,
            r.date_of_birth,
            r.sex,
            r.contact_number,
            r.email,
            a.appointment_date,
            a.appointment_time,
            a.purpose
        FROM appointment a
        INNER JOIN resident r ON a.resident_id = r.resident_id
        WHERE a.status = 'approved'
        ORDER BY a.appointment_date ASC, a.appointment_time ASC
    ";
    
    $stmt = $pdo->prepare($approved_query);
    $stmt->execute();
    $approved_patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("APPROVED PATIENTS QUERY ERROR: " . $e->getMessage());
    $approved_patients = [];
}

// ================================================================
// LOAD SAVED SURVEILLANCE METRICS
// ================================================================
$surveillance_metrics = [];
$highest_surveillance_metric = null;
try {
    $pdo = getDatabaseConnection();
    if ($pdo !== false) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS surveillance_metrics (
            id INT AUTO_INCREMENT PRIMARY KEY,
            worker_id INT NOT NULL,
            reporting_period VARCHAR(255) DEFAULT NULL,
            disease_name VARCHAR(255) DEFAULT NULL,
            case_count INT DEFAULT 0,
            trend_status VARCHAR(255) DEFAULT NULL,
            meta_notes TEXT DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("ALTER TABLE surveillance_metrics MODIFY disease_name VARCHAR(255) DEFAULT NULL");

        $stmt = $pdo->prepare("SELECT * FROM surveillance_metrics WHERE worker_id = ? AND case_count > 0 AND disease_name IS NOT NULL AND TRIM(disease_name) <> '' AND LOWER(TRIM(disease_name)) <> 'record entry' ORDER BY case_count DESC, created_at DESC");
        $stmt->execute([$worker_id]);
        $surveillance_metrics = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $surveillance_metrics = array_values(array_filter($surveillance_metrics, static function ($metric) {
            $diseaseName = trim((string)($metric['disease_name'] ?? ''));
            return $diseaseName !== '' && strcasecmp($diseaseName, 'Record Entry') !== 0;
        }));
        $highest_surveillance_metric = $surveillance_metrics[0] ?? null;
    }
} catch (Exception $e) {
    error_log("SURVEILLANCE METRICS LOAD ERROR: " . $e->getMessage());
    $surveillance_metrics = [];
}

// ================================================================
// GET: Return latest surveillance metrics as JSON (simple API)
// ================================================================
if ($_SERVER['REQUEST_METHOD'] === 'GET' && (isset($_GET['action']) && $_GET['action'] === 'get_surveillance_metrics')) {
    header('Content-Type: application/json');
    try {
        $pdoApi = getDatabaseConnection();
        if ($pdoApi === false) {
            echo json_encode(['success' => false, 'message' => 'Database connection failed']);
            exit;
        }

        $stmtApi = $pdoApi->prepare("SELECT * FROM surveillance_metrics WHERE worker_id = ? AND case_count > 0 AND disease_name IS NOT NULL AND TRIM(disease_name) <> '' AND LOWER(TRIM(disease_name)) <> 'record entry' ORDER BY case_count DESC, created_at DESC");
        $stmtApi->execute([$worker_id]);
        echo json_encode($stmtApi->fetchAll(PDO::FETCH_ASSOC) ?: []);
        exit;
    } catch (Exception $e) {
        error_log('GET SURVEILLANCE METRICS ERROR: ' . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Unable to load surveillance metrics.']);
        exit;
    }
}

// ================================================================
// HANDLE POST ACTIONS
// ================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_announcement') {
        $title = trim((string)($_POST['title'] ?? ''));
        $message = trim((string)($_POST['message'] ?? ''));
        $serviceDate = trim((string)($_POST['service_date'] ?? ''));
        $location = trim((string)($_POST['location'] ?? ''));
        $state = trim((string)($_POST['state'] ?? 'upcoming'));

        if ($title === '' || $message === '' || !in_array($state, ['upcoming', 'now', 'done'], true)) {
            header('Location: dashboard_bhw.php?module=announcements&announcement_status=missing');
            exit;
        }

        try {
            $announcementPdo = getDatabaseConnection();
            $announcementStmt = $announcementPdo->prepare(
                'INSERT INTO health_announcements (worker_id, title, message, service_date, location, state) VALUES (?, ?, ?, ?, ?, ?)'
            );
            $announcementStmt->execute([$worker_id, $title, $message, $serviceDate !== '' ? $serviceDate : null, $location !== '' ? $location : null, $state]);
            header('Location: dashboard_bhw.php?module=announcements&announcement_status=published');
            exit;
        } catch (Exception $e) {
            error_log('CREATE ANNOUNCEMENT ERROR: ' . $e->getMessage());
            header('Location: dashboard_bhw.php?module=announcements&announcement_status=error');
            exit;
        }
    }

    if ($action === 'update_announcement') {
        $announcementId = intval($_POST['announcement_id'] ?? 0);
        $title = trim((string)($_POST['title'] ?? ''));
        $message = trim((string)($_POST['message'] ?? ''));
        $serviceDate = trim((string)($_POST['service_date'] ?? ''));
        $location = trim((string)($_POST['location'] ?? ''));
        $state = trim((string)($_POST['state'] ?? 'upcoming'));

        if ($announcementId <= 0 || $title === '' || $message === '' || !in_array($state, ['upcoming', 'now', 'done'], true)) {
            header('Location: dashboard_bhw.php?module=announcements&announcement_tab=manage&announcement_status=missing');
            exit;
        }

        try {
            $announcementPdo = getDatabaseConnection();
            $announcementStmt = $announcementPdo->prepare(
                'UPDATE health_announcements SET title = ?, message = ?, service_date = ?, location = ?, state = ? WHERE announcement_id = ? AND worker_id = ?'
            );
            $announcementStmt->execute([$title, $message, $serviceDate !== '' ? $serviceDate : null, $location !== '' ? $location : null, $state, $announcementId, $worker_id]);
            header('Location: dashboard_bhw.php?module=announcements&announcement_tab=manage&announcement_state=' . urlencode($state) . '&announcement_status=updated');
            exit;
        } catch (Exception $e) {
            error_log('UPDATE ANNOUNCEMENT ERROR: ' . $e->getMessage());
            header('Location: dashboard_bhw.php?module=announcements&announcement_tab=manage&announcement_status=error');
            exit;
        }
    }

    if ($action === 'delete_metric') {
        header('Content-Type: application/json; charset=utf-8');
        $metricIdInput = $_POST['id'] ?? ($_POST['disease_id'] ?? ($_POST['metric_id'] ?? null));
        $metric_id = is_scalar($metricIdInput) ? intval($metricIdInput) : 0;
        $disease_name = isset($_POST['disease_name']) && is_string($_POST['disease_name']) ? trim($_POST['disease_name']) : '';
        if ($metric_id <= 0 && $disease_name === '') {
            ob_clean();
            echo json_encode(['success' => false, 'message' => 'Invalid disease record ID.']);
            exit;
        }

        try {
            $pdo = getDatabaseConnection();
            if ($pdo === false) {
                throw new RuntimeException('Database connection failed.');
            }
            if ($metric_id > 0) {
                $deleteStmt = $pdo->prepare('DELETE FROM surveillance_metrics WHERE id = ? AND worker_id = ?');
                $deleteStmt->execute([$metric_id, $worker_id]);
            } else {
                $deleteStmt = $pdo->prepare('DELETE FROM surveillance_metrics WHERE disease_name = ? AND worker_id = ?');
                $deleteStmt->execute([$disease_name, $worker_id]);
            }
            ob_clean();
            echo json_encode(['success' => true, 'deleted_id' => $metric_id, 'disease_name' => $disease_name]);
        } catch (Exception $e) {
            error_log('DELETE SURVEILLANCE METRIC ERROR: ' . $e->getMessage());
            ob_clean();
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        exit;
    }

    if ($action === 'search_patient') {
        header('Content-Type: application/json; charset=utf-8');
        $searchTerm = trim($_POST['search_term'] ?? $_POST['search'] ?? '');

        if ($searchTerm === '') {
            echo json_encode(['success' => false, 'message' => 'Please enter a name, email, phone number, or resident ID.']);
            exit;
        }

        try {
            $searchPdo = getDatabaseConnection();
            if ($searchPdo === false) {
                throw new RuntimeException('Database connection unavailable.');
            }
            ensureResidentPatientCodeColumn($searchPdo);
            $searchLike = '%' . $searchTerm . '%';
            $phoneLike = '%' . str_replace([' ', '-', '+'], '', $searchTerm) . '%';
            $searchStmt = $searchPdo->prepare(
                "SELECT resident_id, patient_code, full_name, email, contact_number, date_of_birth
                 FROM resident
                 WHERE LOWER(full_name) LIKE LOWER(?)
                    OR LOWER(email) LIKE LOWER(?)
                    OR REPLACE(REPLACE(REPLACE(contact_number, ' ', ''), '-', ''), '+', '') LIKE ?
                    OR patient_code LIKE ?
                    OR CAST(resident_id AS CHAR) LIKE ?
                 LIMIT 10"
            );
            $searchStmt->execute([$searchLike, $searchLike, $phoneLike, $searchLike, $searchLike]);
            $patients = [];

            foreach ($searchStmt->fetchAll(PDO::FETCH_ASSOC) as $patient) {
                $patientCode = ensureResidentPatientCode($searchPdo, (int)$patient['resident_id']);
                $dob = 'N/A';
                if (!empty($patient['date_of_birth'])) {
                    $dobDate = DateTime::createFromFormat('Y-m-d', $patient['date_of_birth']);
                    $dob = $dobDate ? $dobDate->format('M d, Y') : (string)$patient['date_of_birth'];
                }
                $patients[] = [
                    'id' => (int)$patient['resident_id'],
                    'patient_code' => $patientCode ?: str_pad((string)$patient['resident_id'], 6, '0', STR_PAD_LEFT),
                    'name' => htmlspecialchars($patient['full_name'] ?? 'Unknown', ENT_QUOTES, 'UTF-8'),
                    'email' => htmlspecialchars($patient['email'] ?? 'N/A', ENT_QUOTES, 'UTF-8'),
                    'phone' => htmlspecialchars($patient['contact_number'] ?? 'N/A', ENT_QUOTES, 'UTF-8'),
                    'dob' => $dob
                ];
            }

            echo json_encode([
                'success' => !empty($patients),
                'patients' => $patients,
                'data' => $patients,
                'message' => !empty($patients) ? count($patients) . ' patient result(s) found.' : 'No patient found matching that ID or details.'
            ]);
        } catch (Throwable $e) {
            error_log('DASHBOARD PATIENT SEARCH ERROR: ' . $e->getMessage());
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Patient search failed. Please try again.']);
        }
        exit;
    }
    
    // ================================================================
    // HANDLE UPDATE APPOINTMENT STATUS
    // ================================================================
    if ($action === 'update_appointment_status') {
        header('Content-Type: application/json');
        $appointment_id = intval($_POST['appointment_id'] ?? 0);
        $resident_id = intval($_POST['resident_id'] ?? 0);
        $new_status = trim($_POST['status'] ?? '');
        
        if ($appointment_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid appointment ID']);
            exit;
        }
        
        if (empty($new_status)) {
            echo json_encode(['success' => false, 'message' => 'Status is required']);
            exit;
        }
        
        try {
            $pdo = getDatabaseConnection();
            
            if ($pdo === false) {
                echo json_encode(['success' => false, 'message' => 'Database connection failed']);
                exit;
            }
            
            // ========================================================================
            // CRITICAL: If status is 'completed' (Rendered), CREATE MEDICAL RECORD
            // ========================================================================
            if ($new_status === 'completed' && $resident_id > 0) {
                try {
                    // Get appointment details first
                    $apt_stmt = $pdo->prepare("SELECT * FROM appointment WHERE appointment_id = ?");
                    $apt_stmt->execute([$appointment_id]);
                    $appointment = $apt_stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($appointment) {
                        $resident_id_from_apt = intval($appointment['resident_id']);
                        $appointment_purpose = $appointment['purpose'] ?? 'General Consultation';
                        
                        // Try to create PATIENT_RECORD entry first (NEW ERD schema)
                        try {
                            $insert_stmt = $pdo->prepare("
                                INSERT INTO patient_record (
                                    resident_id,
                                    health_worker_id,
                                    visit_date,
                                    diagnosis,
                                    treatment,
                                    notes,
                                    created_at
                                ) VALUES (?, ?, ?, ?, ?, ?, NOW())
                            ");
                            
                            $insert_stmt->execute([
                                $resident_id_from_apt,
                                $worker_id,
                                date('Y-m-d'),  // Today's date
                                $appointment_purpose,  // Use appointment purpose as diagnosis
                                'Medical visit completed',     // Default treatment
                                'Visit completed on ' . date('Y-m-d H:i:s'),  // Log note
                            ]);
                            
                            error_log("✓ PATIENT_RECORD created for resident_id=$resident_id_from_apt from appointment_id=$appointment_id");
                        } catch (Exception $patient_record_err) {
                            // FALLBACK: If PATIENT_RECORD table doesn't exist, try medical_history table
                            error_log("PATIENT_RECORD insertion failed, attempting medical_history fallback: " . $patient_record_err->getMessage());
                            
                            try {
                                $insert_history = $pdo->prepare("
                                    INSERT INTO medical_history (
                                        user_id,
                                        visit_date,
                                        visit_type,
                                        bhw_name,
                                        diagnosis,
                                        treatment,
                                        notes,
                                        created_at
                                    ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
                                ");
                                
                                $bhw_name = $worker_id > 0 ? "BHW ID: $worker_id" : 'Health Worker';
                                
                                $insert_history->execute([
                                    $resident_id_from_apt,
                                    date('Y-m-d'),
                                    'Consultation',
                                    $bhw_name,
                                    $appointment_purpose,
                                    'Medical visit completed',
                                    'Visit completed on ' . date('Y-m-d H:i:s'),
                                ]);
                                
                                error_log("✓ FALLBACK: medical_history record created for resident_id=$resident_id_from_apt from appointment_id=$appointment_id");
                            } catch (Exception $fallback_err) {
                                error_log("WARNING: Both PATIENT_RECORD and medical_history creation failed: " . $fallback_err->getMessage());
                            }
                        }
                    }
                } catch (Exception $record_err) {
                    error_log("WARNING: Error during medical record creation: " . $record_err->getMessage());
                    // Don't fail the appointment update if record creation fails
                }
            }
            
            // Update appointment status
            $stmt = $pdo->prepare("
                UPDATE appointment
                SET status = ?, health_worker_id = ?
                WHERE appointment_id = ?
            ");
            
            if ($stmt->execute([$new_status, $worker_id, $appointment_id])) {
                // Log the activity
                $status_display = ucfirst(str_replace('_', ' ', $new_status));
                $resident_name = "Resident ID: {$resident_id}";
                
                // Try to get resident name
                try {
                    $res_stmt = $pdo->prepare("SELECT full_name FROM resident WHERE resident_id = ? LIMIT 1");
                    $res_stmt->execute([$resident_id]);
                    $resident = $res_stmt->fetch(PDO::FETCH_ASSOC);
                    if ($resident) {
                        $resident_name = $resident['full_name'];
                    }
                } catch (Exception $e) {
                    error_log("Warning: Could not fetch resident name: " . $e->getMessage());
                }
                
                // Log activity using logActivity function
                try {
                    logActivity(
                        $pdo,
                        $worker_id,
                        'bhw',
                        'appointment_rendered',
                        "Rendered appointment for {$resident_name} - Status changed to: {$status_display}"
                    );
                } catch (Exception $log_err) {
                    error_log("Warning: Activity logging failed: " . $log_err->getMessage());
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Appointment status updated successfully',
                    'new_status' => $new_status
                ]);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update appointment']);
                exit;
            }
        } catch (Exception $e) {
            error_log("UPDATE APPOINTMENT STATUS ERROR: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Unable to update the appointment.']);
            exit;
        }
    }
    
    // ================================================================
    // HANDLE SAVE SURVEILLANCE METRICS
    // ================================================================
    if ($action === 'save_surveillance_metrics') {
        header('Content-Type: application/json; charset=utf-8');
        $reportingPeriodInput = $_POST['reporting_period'] ?? null;
        $diseaseNameInput = $_POST['disease_name'] ?? null;
        $caseCountInput = $_POST['case_count'] ?? ($_POST['quantity_count'] ?? null);
        $trendStatusInput = $_POST['trend_status'] ?? null;
        $metaNotesInput = $_POST['meta_notes'] ?? ($_POST['disease_meta'] ?? null);

        $reporting_period = is_string($reportingPeriodInput) && trim($reportingPeriodInput) !== '' ? trim($reportingPeriodInput) : 'Current 4 Weeks';
        $disease_name = is_string($diseaseNameInput) ? trim($diseaseNameInput) : '';
        $case_count = is_scalar($caseCountInput) ? intval($caseCountInput) : 0;
        $trend_status = is_string($trendStatusInput) && trim($trendStatusInput) !== '' ? trim($trendStatusInput) : 'Baseline';
        $meta_notes = is_string($metaNotesInput) ? trim($metaNotesInput) : '';

        if ($disease_name === '') {
            ob_clean();
            echo json_encode(['success' => false, 'message' => 'Disease name is required.']);
            exit;
        }
        
        try {
            $pdo = getDatabaseConnection();
            if ($pdo === false) {
                ob_clean();
                echo json_encode(['success' => false, 'message' => 'Database connection failed']);
                exit;
            }

            $pdo->exec("CREATE TABLE IF NOT EXISTS surveillance_metrics (
                id INT AUTO_INCREMENT PRIMARY KEY,
                worker_id INT NOT NULL,
                reporting_period VARCHAR(255) DEFAULT NULL,
                disease_name VARCHAR(255) DEFAULT NULL,
                case_count INT DEFAULT 0,
                trend_status VARCHAR(255) DEFAULT NULL,
                meta_notes TEXT DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            $pdo->exec("ALTER TABLE surveillance_metrics MODIFY disease_name VARCHAR(255) DEFAULT NULL");

                $metric_id = isset($_POST['metric_id']) && is_scalar($_POST['metric_id']) ? intval($_POST['metric_id']) : 0;
                if ($case_count <= 0 && $metric_id > 0) {
                    $deleteStmt = $pdo->prepare("DELETE FROM surveillance_metrics WHERE id = ? AND worker_id = ?");
                    $deleteStmt->execute([$metric_id, $worker_id]);
                } elseif ($case_count > 0 && $metric_id > 0) {
                    $updateStmt = $pdo->prepare("UPDATE surveillance_metrics
                        SET case_count = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = ? AND worker_id = ?");
                    $updateStmt->execute([$case_count, $metric_id, $worker_id]);
                } elseif ($case_count > 0) {
                    $insertStmt = $pdo->prepare("INSERT INTO surveillance_metrics
                        (worker_id, reporting_period, disease_name, case_count, trend_status, meta_notes)
                        VALUES (?, ?, ?, ?, ?, ?)");
                    $insertStmt->execute([$worker_id, $reporting_period, $disease_name, $case_count, $trend_status, $meta_notes]);
                        $created_metric_id = (int)$pdo->lastInsertId();
                }

                $cleanupStmt = $pdo->prepare("DELETE FROM surveillance_metrics
                    WHERE worker_id = ? AND (case_count <= 0 OR disease_name IS NULL OR TRIM(disease_name) = '' OR LOWER(TRIM(disease_name)) = 'record entry')");
                $cleanupStmt->execute([$worker_id]);

            // Fetch the freshly saved/updated metrics for this worker so frontend can reflect exact DB state
            try {
                $fetchStmt = $pdo->prepare("SELECT * FROM surveillance_metrics WHERE worker_id = ? AND case_count > 0 AND disease_name IS NOT NULL AND TRIM(disease_name) <> '' AND LOWER(TRIM(disease_name)) <> 'record entry' ORDER BY case_count DESC, created_at DESC");
                $fetchStmt->execute([$worker_id]);
                $saved = $fetchStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            } catch (Exception $fetchErr) {
                error_log("FETCH SAVED SURVEILLANCE METRICS ERROR: " . $fetchErr->getMessage());
                $saved = [];
            }

            ob_clean();
            echo json_encode([
                'success' => true,
                'message' => 'Surveillance metrics saved successfully',
                'id' => $created_metric_id ?? ($metric_id > 0 ? $metric_id : null),
                'created_id' => $created_metric_id ?? null,
                'disease_name' => $disease_name,
                'case_count' => $case_count,
                'metrics' => $saved
            ]);
            exit;
        } catch (Exception $e) {
            error_log("SAVE SURVEILLANCE METRICS ERROR: " . $e->getMessage());
            ob_clean();
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
            exit;
        }
    }
    
    // ================================================================
    // HANDLE UPDATE FOLLOW-UP TIME
    // ================================================================
    if ($action === 'update_followup_time') {
        header('Content-Type: application/json');
        $appointment_id = intval($_POST['appointment_id'] ?? 0);
        $follow_time = trim($_POST['follow_time'] ?? '');
        
        if ($appointment_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid appointment ID']);
            exit;
        }
        
        if (empty($follow_time)) {
            echo json_encode(['success' => false, 'message' => 'Time is required']);
            exit;
        }
        
        try {
            $pdo = getDatabaseConnection();
            
            if ($pdo === false) {
                echo json_encode(['success' => false, 'message' => 'Database connection failed']);
                exit;
            }
            
            // Update appointment time (follow-up will be at the new time)
            $stmt = $pdo->prepare("
                UPDATE appointment
                SET appointment_time = ?
                WHERE appointment_id = ?
            ");
            
            if ($stmt->execute([$follow_time, $appointment_id])) {
                // Log activity
                try {
                    // Get appointment and resident details
                    $apt_stmt = $pdo->prepare("SELECT resident_id, purpose FROM appointment WHERE appointment_id = ? LIMIT 1");
                    $apt_stmt->execute([$appointment_id]);
                    $apt = $apt_stmt->fetch(PDO::FETCH_ASSOC);
                    
                    $resident_name = "Resident ID: " . ($apt['resident_id'] ?? $appointment_id);
                    if ($apt && isset($apt['resident_id'])) {
                        $res_stmt = $pdo->prepare("SELECT full_name FROM resident WHERE resident_id = ? LIMIT 1");
                        $res_stmt->execute([$apt['resident_id']]);
                        $resident = $res_stmt->fetch(PDO::FETCH_ASSOC);
                        if ($resident) {
                            $resident_name = $resident['full_name'];
                        }
                    }
                    
                    logActivity(
                        $pdo,
                        $worker_id,
                        'bhw',
                        'rescheduled_appointment',
                        "Rescheduled appointment for {$resident_name} - New time: {$follow_time}"
                    );
                } catch (Exception $log_err) {
                    error_log("Warning: Activity logging failed: " . $log_err->getMessage());
                }
                
                echo json_encode([
                    'success' => true,
                    'message' => 'Follow-up time updated successfully'
                ]);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to update time']);
                exit;
            }
        } catch (Exception $e) {
            error_log("UPDATE FOLLOWUP TIME ERROR: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Unable to update the follow-up schedule.']);
            exit;
        }
    }
    
    if ($action === 'add_medicine') {
        header('Content-Type: application/json');
        $medicine_name = trim($_POST['medicine_name'] ?? '');
        $dosage = trim($_POST['dosage'] ?? '');
        $quantity = filter_var($_POST['quantity'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
        $available = filter_var($_POST['available_stock'] ?? $quantity, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
        
        // Debug logging
        error_log("ADD MEDICINE DEBUG - Name: '$medicine_name', Dosage: '$dosage', Quantity: " . var_export($quantity, true) . ", Available: " . var_export($available, true));
        
        try {
            $pdo = getDatabaseConnection();
            
            if ($pdo === false) {
                error_log("ADD MEDICINE ERROR: Database connection failed");
                echo json_encode(['success' => false, 'message' => 'Database connection failed']);
                exit;
            }
            
            if (empty($medicine_name)) {
                error_log("ADD MEDICINE ERROR: Medicine name is empty");
                echo json_encode(['success' => false, 'message' => 'Medicine name is required']);
                exit;
            }
            
            if ($quantity === false || $available === false) {
                error_log("ADD MEDICINE ERROR: Stock values must be non-negative integers");
                echo json_encode(['success' => false, 'message' => 'Stock values must be non-negative whole numbers.']);
                exit;
            }

            if ($available > $quantity) {
                error_log("ADD MEDICINE ERROR: Available stock exceeds total stock");
                echo json_encode(['success' => false, 'message' => 'Available stock cannot exceed total stock.']);
                exit;
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO medicine (name, dosage, stock_quantity, available, dispensed, status) 
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            
            $status = ($available > 5) ? 'Available' : (($available > 0) ? 'Low Stock' : 'Out of Stock');
            $clean_name = $medicine_name;
            $clean_dosage = $dosage !== '' ? $dosage : '-';
            
            error_log("ADD MEDICINE: Executing insert with - Name: '$clean_name', Dosage: '$clean_dosage', Qty: $quantity, Status: '$status'");
            
            if ($stmt->execute([$clean_name, $clean_dosage, $quantity, $available, 0, $status])) {
                error_log("ADD MEDICINE SUCCESS: Medicine inserted successfully");
                
                // Log activity
                try {
                    logActivity(
                        $pdo,
                        $worker_id,
                        'bhw',
                        'added_medicine',
                        "Added medicine: {$clean_name} ({$clean_dosage}) with quantity {$quantity}"
                    );
                } catch (Exception $log_err) {
                    error_log("Warning: Activity logging failed: " . $log_err->getMessage());
                }
                
                echo json_encode(['success' => true, 'message' => 'Medicine added successfully']);
                exit;
            } else {
                error_log("ADD MEDICINE ERROR: Execute returned false");
                echo json_encode(['success' => false, 'message' => 'Failed to execute database insert']);
                exit;
            }
            
        } catch (Exception $e) {
            $error_msg = $e->getMessage();
            error_log("ADD MEDICINE ERROR: {$error_msg}");
            echo json_encode([
                'success' => false,
                'message' => 'Unable to add medicine: ' . $error_msg,
                'error' => $error_msg
            ]);
            exit;
        }
    }
    
    if ($action === 'update_medicine') {
        header('Content-Type: application/json');
        $medicine_id = intval($_POST['medicine_id'] ?? 0);
        $name = trim($_POST['medicine_name'] ?? '');
        $dosage = trim($_POST['dosage'] ?? '');
        $stock = intval($_POST['stock'] ?? 0);
        $available = intval($_POST['available'] ?? $stock);
        $dispensed = intval($_POST['dispensed'] ?? 0);
        
        try {
            $pdo = getDatabaseConnection();
            if ($pdo !== false && $medicine_id > 0) {
                $status = ($stock > 5) ? 'Available' : (($stock > 0) ? 'Low Stock' : 'Out of Stock');
                $stmt = $pdo->prepare("
                    UPDATE medicine 
                    SET name = ?, dosage = ?, stock_quantity = ?, available = ?, dispensed = ?, status = ? 
                    WHERE medicine_id = ?
                ");
                if ($stmt->execute([htmlspecialchars($name), htmlspecialchars($dosage), $stock, $available, $dispensed, $status, $medicine_id])) {
                    // Log activity
                    try {
                        $clean_name = htmlspecialchars($name);
                        $clean_dosage = htmlspecialchars($dosage);
                        logActivity(
                            $pdo,
                            $worker_id,
                            'bhw',
                            'edited_medicine',
                            "Edited medicine: {$clean_name} ({$clean_dosage}) - New stock: {$stock}"
                        );
                    } catch (Exception $log_err) {
                        error_log("Warning: Activity logging failed: " . $log_err->getMessage());
                    }
                    
                    echo json_encode(['success' => true, 'message' => 'Medicine updated successfully']);
                    exit;
                }
            }
        } catch (Exception $e) {
            error_log("Medicine update error: " . $e->getMessage());
        }
        echo json_encode(['success' => false, 'message' => 'Error updating medicine']);
        exit;
    }

    if ($action === 'delete_medicine') {
        header('Content-Type: application/json');
        $medicine_id = intval($_POST['medicine_id'] ?? 0);

        if ($medicine_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid medicine ID']);
            exit;
        }

        try {
            $pdo = getDatabaseConnection();
            if ($pdo !== false) {
                $deleteStmt = $pdo->prepare('DELETE FROM medicine WHERE medicine_id = ?');
                if ($deleteStmt->execute([$medicine_id])) {
                    try {
                        logActivity(
                            $pdo,
                            $worker_id,
                            'bhw',
                            'deleted_medicine',
                            "Deleted medicine ID: {$medicine_id}"
                        );
                    } catch (Exception $log_err) {
                        error_log("Warning: Activity logging failed: " . $log_err->getMessage());
                    }

                    echo json_encode(['success' => true, 'message' => 'Medicine deleted successfully']);
                    exit;
                }
            }
        } catch (Exception $e) {
            error_log("Medicine delete error: " . $e->getMessage());
        }

        echo json_encode(['success' => false, 'message' => 'Error deleting medicine']);
        exit;
    }
    
    // ================================================================
    // HANDLE CLEAR MEDICAL HISTORY
    // ================================================================
    if ($action === 'clear_medical_history') {
        header('Content-Type: application/json');
        $patient_id = intval($_POST['patient_id'] ?? 0);
        
        if ($patient_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid patient ID']);
            exit;
        }
        
        try {
            $pdo = getDatabaseConnection();
            
            if ($pdo === false) {
                echo json_encode(['success' => false, 'message' => 'Database connection failed']);
                exit;
            }
            
            // Get record count before deletion for confirmation
            $count_stmt = $pdo->prepare("SELECT COUNT(*) as count FROM medical_history WHERE user_id = ?");
            $count_stmt->execute([$patient_id]);
            $count_result = $count_stmt->fetch(PDO::FETCH_ASSOC);
            $deleted_count = $count_result['count'] ?? 0;
            
            // Delete all medical history records for the patient
            $delete_stmt = $pdo->prepare("DELETE FROM medical_history WHERE user_id = ?");
            
            if ($delete_stmt->execute([$patient_id])) {
                error_log("✓ Medical history cleared for patient_id=$patient_id. Deleted $deleted_count records.");
                echo json_encode([
                    'success' => true,
                    'message' => "Medical history cleared successfully. Deleted $deleted_count record(s).",
                    'deleted_count' => $deleted_count
                ]);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to clear medical history']);
                exit;
            }
        } catch (Exception $e) {
            error_log("CLEAR MEDICAL HISTORY ERROR: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Unable to clear medical history.']);
            exit;
        }
    }
    
    // ================================================================
    // HANDLE CLEAR FOLLOW-UP CHECK-UPS
    // ================================================================
    if ($action === 'clear_followup_checkups') {
        header('Content-Type: application/json');
        $patient_id = intval($_POST['patient_id'] ?? 0);
        
        if ($patient_id <= 0) {
            echo json_encode(['success' => false, 'message' => 'Invalid patient ID']);
            exit;
        }
        
        try {
            $pdo = getDatabaseConnection();
            
            if ($pdo === false) {
                echo json_encode(['success' => false, 'message' => 'Database connection failed']);
                exit;
            }
            
            // Get record count before deletion for confirmation
            $count_stmt = $pdo->prepare("SELECT COUNT(*) as count FROM appointment WHERE resident_id = ? AND status = 'flagged'");
            $count_stmt->execute([$patient_id]);
            $count_result = $count_stmt->fetch(PDO::FETCH_ASSOC);
            $deleted_count = $count_result['count'] ?? 0;
            
            // Delete all follow-up check-up records (flagged appointments)
            $delete_stmt = $pdo->prepare("DELETE FROM appointment WHERE resident_id = ? AND status = 'flagged'");
            
            if ($delete_stmt->execute([$patient_id])) {
                error_log("✓ Follow-up check-ups cleared for patient_id=$patient_id. Deleted $deleted_count records.");
                echo json_encode([
                    'success' => true,
                    'message' => "Follow-up check-ups cleared successfully. Deleted $deleted_count record(s).",
                    'deleted_count' => $deleted_count
                ]);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to clear follow-up check-ups']);
                exit;
            }
        } catch (Exception $e) {
            error_log("CLEAR FOLLOWUP CHECKUPS ERROR: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => 'Unable to clear follow-up checkups.']);
            exit;
        }
    }
}

// ================================================================
// FETCH REAL APPOINTMENT DATA FROM DATABASE
// ================================================================
$total_appointments = 0;
$pending_consultations = 0;
$medicine_count = 0;
$medicine_available = 0;
$pending_reminders = 0;
$upcoming_appointments = [];
$medicine_list = [];

try {
    $pdo = getDatabaseConnection();
    
    if ($pdo !== false) {
        // Get total appointments (all active/upcoming appointments)
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM appointment WHERE status IN ('scheduled', 'pending', 'flagged', 'approved')");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $total_appointments = $result['count'] ?? 0;
        
        // Get pending consultations (scheduled or pending, future dates only)
        $today = date('Y-m-d');
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as count FROM appointment
            WHERE status IN ('scheduled', 'pending') 
            AND appointment_date >= ?
        ");
        $stmt->execute([$today]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $pending_consultations = $result['count'] ?? 0;
        
        // Get upcoming appointments with resident details
        // NOTE: Include ALL statuses (pending, completed, no_show, etc.) so we can display them
        // in their respective tabs (Today's Queue, Follow-Up, and Appointment History)
        $stmt = $pdo->prepare("
            SELECT 
                a.appointment_id,
                a.resident_id,
                a.appointment_date,
                a.appointment_time,
                a.purpose,
                a.status,
                r.full_name as resident_name,
                r.contact_number
            FROM appointment a
            LEFT JOIN resident r ON a.resident_id = r.resident_id
            WHERE a.status IN ('scheduled', 'pending', 'flagged', 'approved', 'completed', 'no_show')
            AND a.appointment_date >= ?
            ORDER BY a.appointment_date DESC, a.appointment_time DESC
            LIMIT 100
        ");
        $stmt->execute([$today]);
        $upcoming_appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get medicine inventory count
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM medicine");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $medicine_count = $result['count'] ?? 0;
        
        // Get available medicines count
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM medicine WHERE stock_quantity > 0");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $medicine_available = $result['count'] ?? 0;
        
        // Get all medicines for inventory table with all 7 columns
        $stmt = $pdo->query("SELECT medicine_id, name, dosage, stock_quantity, available, dispensed, status FROM medicine ORDER BY name ASC");
        $medicine_list = $stmt->fetchAll(PDO::FETCH_ASSOC) ?? [];
    }
} catch (Exception $e) {
    error_log("BHW Dashboard Error: " . $e->getMessage());
}

$managedAnnouncements = [];
$announcementCounts = ['upcoming' => 0, 'now' => 0, 'done' => 0];
if ($active_module === 'announcements') {
    try {
        $announcementPdo = getDatabaseConnection();
        $announcementStmt = $announcementPdo->prepare(
            'SELECT announcement_id, title, message, service_date, location, state, created_at FROM health_announcements WHERE worker_id = ? ORDER BY created_at DESC'
        );
        $announcementStmt->execute([$worker_id]);
        $managedAnnouncements = $announcementStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($managedAnnouncements as $managedAnnouncement) {
            if (isset($announcementCounts[$managedAnnouncement['state']])) {
                $announcementCounts[$managedAnnouncement['state']]++;
            }
        }
    } catch (Exception $e) {
        error_log('MANAGE ANNOUNCEMENTS LOAD ERROR: ' . $e->getMessage());
    }
}

// Helper function for active tab styling
function isModuleActive($module) {
    global $active_module;
    return $active_module === $module;
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BHW Dashboard — ScanCare</title>
    <script src="theme-state.js"></script>
    <link rel="stylesheet" href="global-theme.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>tailwind.config = { darkMode: 'class' };</script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap');
        
        .font-heading { font-family: 'Plus Jakarta Sans', sans-serif; }
        .font-body { font-family: 'Inter', sans-serif; }

        /* Tab Navigation Active State */
        .tab-button {
            position: relative;
            padding: 12px 16px;
            border-radius: 8px;
            transition: all 0.3s ease;
            color: #64748b;
            text-decoration: none;
            font-weight: 500;
            font-size: 14px;
        }

        .tab-button:hover {
            color: #2d5016;
            background-color: rgba(79, 119, 38, 0.08);
        }

        .tab-button.active {
            color: #1b5e20;
            background: linear-gradient(135deg, rgba(76, 175, 80, 0.1), rgba(56, 142, 60, 0.05));
            font-weight: 600;
        }

        .tab-button.active::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 60%;
            height: 3px;
            background: linear-gradient(90deg, #4f7726, #66bb6a);
            border-radius: 2px;
            box-shadow: 0 2px 8px rgba(79, 119, 38, 0.2);
        }

        /* Ensure Publish Updates button is clickable even if overlays exist */
        #saveSurveillanceBtn {
            position: relative !important;
            z-index: 12000 !important;
            pointer-events: auto !important;
        }

        .surveillance-status-pill {
            display: inline-flex;
            align-items: center;
            border-radius: 9999px;
            padding: 0.25rem 0.6rem;
            font-size: 0.7rem;
            font-weight: 700;
            line-height: 1.2;
        }

        .surveillance-status-pill.status-baseline {
            background: #fef3c7;
            color: #b45309;
        }

        .surveillance-status-pill.status-low {
            background: #d1fae5;
            color: #047857;
        }

        .surveillance-status-pill.status-moderate {
            background: #dbeafe;
            color: #0369a1;
        }

        .surveillance-status-pill.status-high {
            background: #ffe4e6;
            color: #be123c;
        }

        /* Sidebar Layout */
        html,
        body {
            overflow-x: hidden;
        }

        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        *,
        *::before,
        *::after {
            box-sizing: border-box;
        }

        .sidebar {
            position: fixed;
            top: 80px;
            left: 0;
            bottom: 0;
            width: 5rem;
            padding: 1rem 0.5rem;
            background: transparent;
            border-right: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px rgba(15, 23, 42, 0.06);
            z-index: 40;
            overflow-y: auto;
            overflow-x: hidden;
            height: calc(100% - 80px);
            transition: width 0.2s ease, padding 0.2s ease;
        }

        .main-with-sidebar {
            width: calc(100% - 5rem);
            margin-left: 5rem;
            min-width: 0;
            overflow-x: hidden;
            transition: width 0.2s ease, margin-left 0.2s ease;
        }

        .main-with-sidebar > div {
            min-width: 0;
        }

        .sidebar-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 34px;
            opacity: 0;
            transition: opacity 0.3s ease;
            pointer-events: none;
        }

        .sidebar:hover .sidebar-header {
            opacity: 1;
            pointer-events: auto;
        }

        .sidebar-logo {
            width: 44px;
            height: 44px;
            display: grid;
            place-items: center;
            border-radius: 16px;
            background: linear-gradient(135deg, #c8e6c9 0%, #a5d6a7 100%);
            box-shadow: 0 2px 8px rgba(76, 175, 80, 0.15);
            flex-shrink: 0;
        }

        .sidebar-title {
            font-size: 1.05rem;
            font-weight: 700;
            color: #111827;
            line-height: 1.2;
            white-space: nowrap;
        }

        .sidebar-subtitle {
            font-size: 0.82rem;
            color: #6b7280;
            margin-top: 2px;
            white-space: nowrap;
        }

        .sidebar-nav {
            display: grid;
            gap: 5px;
        }

        .sidebar-section-label {
            overflow: hidden;
            max-height: 0;
            margin: 0;
            padding: 0;
            opacity: 0;
            transition: opacity 0.15s ease, max-height 0.2s ease, margin 0.2s ease;
        }

        .sidebar-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 16px;
            color: #475569;
            font-weight: 600;
            font-size: 0.92rem;
            text-decoration: none;
            transition: all 0.3s ease;
            border: 1px solid transparent;
            justify-content: flex-start;
            position: relative;
            white-space: normal;
            overflow: visible;
        }

        .sidebar:hover .sidebar-item {
            padding: 10px 12px;
            justify-content: flex-start;
        }

        .sidebar .sidebar-item-text {
            display: inline-block;
            opacity: 0;
            max-width: 0;
            overflow: hidden;
            vertical-align: middle;
            transform: none;
            line-height: 1.25;
            white-space: nowrap;
            transition: opacity 0.15s ease, max-width 0.2s ease;
        }

        .dashboard-footer {
            width: calc(100% - 5rem);
            margin-left: 5rem;
            transition: width 0.2s ease, margin-left 0.2s ease;
        }

        .sidebar:hover {
            width: 16rem;
            padding: 1rem;
        }

        .sidebar:hover .sidebar-section-label {
            max-height: 2rem;
            margin-bottom: 0.75rem;
            opacity: 1;
        }

        .sidebar:hover .sidebar-item-text {
            max-width: 13rem;
            opacity: 1;
        }

        .sidebar-item:hover {
            background: linear-gradient(135deg, #f6fbf6, #f0f8f2);
            color: #111827;
            border-color: #c8e6c9;
        }

        .sidebar-item.active {
            background: #3d4a1e;
            color: #ffffff;
            border-color: #3d4a1e;
            box-shadow: 0 2px 8px rgba(61, 74, 30, 0.16);
        }

        .sidebar-item i {
            width: 30px;
            height: 30px;
            display: grid;
            place-items: center;
            border-radius: 14px;
            background: linear-gradient(135deg, #e8f5e9, #d4e9db);
            color: #2d5016;
            transition: all 0.3s ease;
            flex-shrink: 0;
        }

        .sidebar-item:hover i {
            background: linear-gradient(135deg, #c8e6c9, #a5d6a7);
            color: #1b5e20;
        }

        .dashboard-topbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding: 26px 0;
        }

        .dashboard-topbar-title {
            margin: 0;
            font-size: 2.5rem;
            font-weight: 800;
            color: #111827;
        }

        .dashboard-topbar-subtitle {
            margin: 0;
            color: #6b7280;
            font-size: 0.95rem;
        }

        .status-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 14px;
            border-radius: 999px;
            background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
            border: 1px solid #a5d6a7;
            color: #1b5e20;
            font-weight: 600;
            font-size: 0.9rem;
            box-shadow: 0 2px 8px rgba(76, 175, 80, 0.1);
        }

        .status-pill span {
            width: 10px;
            height: 10px;
            border-radius: 999px;
            background: linear-gradient(135deg, #66bb6a, #43a047);
            box-shadow: 0 0 6px rgba(76, 175, 80, 0.4);
        }

        .summary-card {
            background: linear-gradient(135deg, #ffffff 0%, #f9faf8 100%);
            border: 1px solid #e5e7eb;
            border-radius: 24px;
            padding: 24px;
            box-shadow: 0 2px 12px rgba(15, 23, 42, 0.06), 0 8px 24px rgba(15, 23, 42, 0.04);
            transition: all 0.3s ease;
        }

        .summary-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 4px 20px rgba(15, 23, 42, 0.12), 0 12px 32px rgba(15, 23, 42, 0.08);
            border-color: #d1fae5;
        }

        .summary-card-icon {
            width: 46px;
            height: 46px;
            display: grid;
            place-items: center;
            border-radius: 16px;
            background: linear-gradient(135deg, rgba(76, 175, 80, 0.12), rgba(56, 142, 60, 0.08));
            color: #2d5016;
            box-shadow: inset 0 1px 3px rgba(76, 175, 80, 0.1);
        }

        .summary-card-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 10px;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 700;
        }

        .summary-card-badge.today { background: #eff6ff; color: #2563eb; }
        .summary-card-badge.pending { background: #fffbeb; color: #92400e; }
        .summary-card-badge.stock { background: #ecfdf5; color: #166534; }
        .summary-card-badge.queue { background: #f5f3ff; color: #7c3aed; }
        .summary-card-badge.surveillance { background: #fefce8; color: #b45309; }

        .section-card {
            background: linear-gradient(135deg, #ffffff 0%, #fafbf8 100%);
            border: 1px solid #e5e7eb;
            border-radius: 20px;
            padding: 28px;
            box-shadow: 0 2px 16px rgba(15, 23, 42, 0.05), 0 8px 20px rgba(15, 23, 42, 0.03);
        }

        .section-card h3 {
            margin-top: 0;
            margin-bottom: 16px;
            font-size: 1.1rem;
            font-weight: 700;
            color: #111827;
        }

        .scan-card {
            background: linear-gradient(135deg, #f5f9f1 0%, #eef4e9 100%);
            border: 1px solid #d4e9db;
            border-radius: 20px;
            transition: all 0.3s ease;
        }

        .scan-card:hover {
            border-color: #a5d6a7;
            box-shadow: 0 4px 16px rgba(76, 175, 80, 0.1);
        }

        .manual-card {
            background: linear-gradient(135deg, #ffffff 0%, #f9faf8 100%);
            border: 1px solid #c8e6c9;
            border-radius: 20px;
            transition: all 0.3s ease;
        }

        .manual-card:hover {
            border-color: #81c784;
            box-shadow: 0 4px 16px rgba(76, 175, 80, 0.12);
        }

        .search-input {
            width: 100%;
            padding: 14px 16px;
            border-radius: 14px;
            border: 1px solid #d1d5db;
            font-size: 0.95rem;
            color: #111827;
            background: linear-gradient(to bottom, #ffffff, #f9faf8);
            transition: all 0.3s ease;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .search-input:focus {
            outline: none;
            border-color: #4f7726;
            box-shadow: 0 0 0 3px rgba(79, 119, 38, 0.1), 0 2px 8px rgba(79, 119, 38, 0.12);
        }

        .manual-search-dropdown {
            position: relative;
            width: 100%;
            z-index: 10;
        }

        .manual-search-dropdown .dropdown-panel {
            width: 100%;
            box-shadow: 0 12px 30px rgba(15, 23, 42, 0.12);
            border: 1px solid #d1d5db;
            background: #ffffff;
            border-radius: 20px;
            max-height: 360px;
            overflow-y: auto;
        }

        .manual-search-option {
            width: 100%;
            text-align: left;
            padding: 1rem 1rem;
            border-bottom: 1px solid #e5e7eb;
            background: #ffffff;
            border-radius: 16px;
            display: flex;
            flex-direction: column;
            gap: 0.35rem;
            transition: background 0.2s ease, transform 0.2s ease;
            cursor: pointer;
        }

        .manual-search-option:last-child {
            border-bottom: none;
        }

        .manual-search-option:hover {
            background: #f8fafc;
            transform: translateX(2px);
        }

        .manual-search-option .patient-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            font-size: 0.8rem;
            color: #64748b;
        }

        .manual-search-option .patient-meta span {
            background: #f1f5f9;
            padding: 0.25rem 0.5rem;
            border-radius: 999px;
        }

        .primary-button {
            background: linear-gradient(135deg, #4f7726 0%, #3d5a1d 100%);
            color: white;
            border-radius: 14px;
            padding: 14px 20px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(69, 75, 27, 0.2);
            border: none;
            cursor: pointer;
        }

        .primary-button:hover {
            transform: translateY(-2px);
            background: linear-gradient(135deg, #5a8a2e 0%, #475920 100%);
            box-shadow: 0 8px 20px rgba(69, 75, 27, 0.3);
        }

        .header-actions {
            margin-left: auto;
            display: flex;
            align-items: center;
            gap: 12px;
            flex-wrap: nowrap;
            min-width: 0;
        }

        .header-actions .text-right {
            min-width: 0;
            flex: 1 1 auto;
        }

        .header-actions .text-right > div {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .mobile-nav-toggle {
            display: none;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            border: 1px solid #d1d5db;
            border-radius: 18px;
            background: #ffffff;
            color: #1f2937;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .mobile-nav-toggle:hover,
        .mobile-nav-toggle.active {
            background: #f3f4f6;
            border-color: #cbd5e1;
        }

        .mobile-nav-icon {
            display: grid;
            gap: 4px;
        }

        .mobile-nav-icon span {
            display: block;
            width: 18px;
            height: 2px;
            background: #111827;
            border-radius: 999px;
        }

        @media (max-width: 1023px) {
            .mobile-nav-toggle {
                display: inline-flex;
                flex-shrink: 0;
                order: 0;
                margin-right: 0;
            }

            .header-actions {
                width: 100%;
                justify-content: space-between;
            }

            .header-actions .text-right {
                order: 1;
                flex: 1 1 auto;
                min-width: 0;
                text-align: right;
            }

            .header-actions .profile-dropdown-container {
                order: 2;
                flex-shrink: 0;
            }

            .sidebar {
                position: relative;
                top: 0;
                left: 0;
                width: 100%;
                height: auto;
                padding: 24px 18px;
                border-right: none;
                box-shadow: none;
                background: white;
                border-bottom: 1px solid #e5e7eb;
                display: none;
            }

            .sidebar.active {
                display: block;
            }

            .sidebar:hover {
                width: 100%;
                padding: 24px 18px;
            }

            .sidebar .sidebar-section-label,
            .sidebar:hover .sidebar-section-label {
                max-height: 2rem;
                margin-bottom: 0.75rem;
                opacity: 1;
            }

            .sidebar .sidebar-item-text,
            .sidebar:hover .sidebar-item-text {
                max-width: none;
                opacity: 1;
                white-space: normal;
            }

            .main-with-sidebar {
                width: 100%;
                margin-left: 0;
            }

            .dashboard-footer {
                width: 100%;
                margin-left: 0;
            }

            .dashboard-topbar {
                flex-direction: column;
                align-items: flex-start;
                gap: 14px;
                padding-bottom: 10px;
            }

            nav.border-b > div {
                flex-wrap: wrap;
                justify-content: space-between;
                gap: 12px;
                height: auto;
            }

            nav.border-b .text-right {
                min-width: 0;
                flex: 1 1 auto;
            }

            nav.border-b .profile-dropdown-container {
                flex-shrink: 0;
            }

            nav.border-b > div.h-20 {
                height: auto;
                min-height: auto;
                padding-top: 16px;
                padding-bottom: 16px;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                padding: 18px 14px;
            }

            .sidebar-nav {
                display: grid;
                gap: 10px;
            }

            .sidebar-item {
                padding: 12px 14px;
                font-size: 0.95rem;
                border-radius: 18px;
                min-height: auto;
                white-space: normal;
                justify-content: flex-start;
            }

            .sidebar-item i {
                width: 30px;
                height: 30px;
            }

            .dashboard-topbar-title {
                font-size: 1.85rem;
            }

            .dashboard-topbar-subtitle {
                font-size: 0.95rem;
            }
        }

        @media (max-width: 768px) {
            nav.border-b > div {
                flex-wrap: wrap;
                justify-content: space-between;
                align-items: center;
                gap: 10px;
            }

            nav.border-b .header-actions {
                justify-content: flex-end;
                flex-wrap: wrap;
            }

            nav.border-b .text-right {
                text-align: right;
            }

            .sidebar {
                padding: 18px 14px;
                background: #ffffff;
            }

            .sidebar-nav {
                gap: 10px;
            }

            .sidebar-item {
                gap: 10px;
                padding: 12px 14px;
                font-size: 0.95rem;
                border-radius: 18px;
                min-height: auto;
                white-space: normal;
                justify-content: flex-start;
            }

            .sidebar-item i {
                width: 30px;
                height: 30px;
            }

            .dashboard-topbar {
                width: 100%;
                padding: 16px 0;
                gap: 10px;
            }

            .dashboard-topbar-title {
                font-size: 1.85rem;
            }

            .dashboard-topbar-subtitle {
                font-size: 0.95rem;
            }

            .main-with-sidebar {
                padding-bottom: 20px;
            }

            .summary-card,
            .section-card,
            .scan-card {
                padding: 18px;
            }

            .hover\:scale-105:hover,
            .hover\:shadow-lg:hover {
                transform: none !important;
                box-shadow: none !important;
            }

            .group:hover .group-hover\:opacity-100 {
                opacity: 1 !important;
            }

            .dashboard-topbar .profile-dropdown-container {
                width: auto;
            }

            .dashboard-topbar .text-right {
                width: 100%;
                text-align: left;
            }

            nav.border-b > div {
                flex-wrap: wrap;
                justify-content: space-between;
                gap: 12px;
            }
        }

        @media (max-width: 600px) {
            .sidebar {
                padding: 14px 12px;
            }

            .sidebar-nav {
                gap: 8px;
            }

            .sidebar-item {
                gap: 10px;
                padding: 10px 12px;
                font-size: 0.92rem;
                border-radius: 16px;
            }

            .sidebar-item i {
                width: 28px;
                height: 28px;
            }

            .dashboard-topbar {
                padding: 14px 0;
            }

            .dashboard-topbar-title {
                font-size: 1.6rem;
            }

            .dashboard-topbar-subtitle {
                font-size: 0.9rem;
            }

            .main-with-sidebar {
                padding-bottom: 20px;
            }

            .summary-card,
            .section-card,
            .scan-card {
                padding: 16px;
            }

            .bg-white.border.border-slate-200.rounded-xl,
            .border.border-slate-200.rounded-\[28px\],
            .rounded-\[32px\] {
                border-radius: 18px !important;
            }

            .dashboard-topbar .profile-dropdown-container {
                width: auto;
            }
        }

        @media (max-width: 480px) {
            .dashboard-topbar-title {
                font-size: 1.35rem;
            }

            .dashboard-topbar-subtitle {
                font-size: 0.88rem;
            }

            .sidebar-item {
                font-size: 0.88rem;
                padding: 10px 10px;
            }

            .sidebar-item i {
                width: 26px;
                height: 26px;
            }

            .sidebar {
                padding: 12px 12px;
            }

            .sidebar-nav {
                gap: 6px;
            }

            .main-with-sidebar {
                padding-bottom: 16px;
            }

            .grid.grid-cols-1.sm\:grid-cols-2.md\:grid-cols-3.lg\:grid-cols-5 {
                gap: 14px;
            }

            .module-content > div {
                padding: 0;
            }

            .bg-white.border.border-slate-200.rounded-xl,
            .border.border-slate-200.rounded-\[28px\],
            .rounded-\[32px\] {
                border-radius: 14px !important;
            }

            .dashboard-topbar .text-right {
                width: 100%;
            }
        }

        /* Module Content Animations */
        .module-content {
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(4px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Sync Status Badge Animation */
        .sync-pulse {
            animation: syncPulse 2s infinite;
        }

        @keyframes syncPulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.6; }
        }

        /* Status Color Scheme */
        .status-scheduled { color: #2563eb; }
        .status-pending { color: #f59e0b; }
        .status-completed { color: #10b981; }
        .status-no-show { color: #ef4444; }
        .status-void { color: #6b7280; }

        /* ====================================================================
           QR SCANNER STYLES - html5-qrcode Integration
           ==================================================================== */
        #qrScannerContainer {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.95);
            z-index: 9999;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        #qrScannerContainer.active {
            display: flex;
        }

        .qr-scanner-box {
            background: white;
            border-radius: 16px;
            padding: 24px;
            max-width: 500px;
            width: 100%;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
        }

        .qr-scanner-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 16px;
            border-bottom: 2px solid #e2e8f0;
        }

        .qr-scanner-header h2 {
            margin: 0;
            font-size: 20px;
            font-weight: 700;
            color: #454B1B;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        .qr-scanner-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #64748b;
            transition: color 0.3s ease;
            padding: 0;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .qr-scanner-close:hover {
            color: #454B1B;
        }

        #html5-qrcode {
            width: 100% !important;
            border-radius: 12px;
            overflow: hidden;
            margin-bottom: 16px;
        }

        .qr-scanner-status {
            text-align: center;
            padding: 12px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 16px;
        }

        .qr-scanner-status.scanning {
            background-color: #dbeafe;
            color: #1e40af;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .qr-scanner-status.success {
            background-color: #dcfce7;
            color: #166534;
        }

        .qr-scanner-status.error {
            background-color: #fee2e2;
            color: #991b1b;
        }

        .qr-scanner-spinner {
            display: inline-block;
            width: 12px;
            height: 12px;
            border: 2px solid #1e40af;
            border-top-color: transparent;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .qr-scanner-instructions {
            text-align: center;
            color: #64748b;
            font-size: 13px;
            margin-bottom: 16px;
            line-height: 1.5;
        }

        .qr-scanner-buttons {
            display: flex;
            gap: 12px;
        }

        .qr-scanner-button {
            flex: 1;
            padding: 12px 16px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Inter', sans-serif;
        }

        .qr-scanner-button-primary {
            background: linear-gradient(135deg, #4f7726 0%, #3d5a1d 100%);
            color: white;
            box-shadow: 0 2px 8px rgba(69, 75, 27, 0.15);
        }

        .qr-scanner-button-primary:hover:not(:disabled) {
            background: linear-gradient(135deg, #5a8a2e 0%, #475920 100%);
            box-shadow: 0 6px 16px rgba(69, 75, 27, 0.25);
            transform: translateY(-1px);
        }

        .qr-scanner-button-secondary {
            background: linear-gradient(135deg, #e2e8f0, #d4d8e5);
            color: #334155;
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05);
        }

        .qr-scanner-button-secondary:hover {
            background: linear-gradient(135deg, #cbd5e1, #bfc4d6);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            transform: translateY(-1px);
        }

        .qr-scanner-button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Mobile responsiveness */
        @media (max-width: 600px) {
            .qr-scanner-box {
                padding: 16px;
            }

            .qr-scanner-header h2 {
                font-size: 18px;
            }
        }

        /* ====================================================================
           PROFILE PICTURE UPLOAD STYLES
           ==================================================================== */
        .profile-upload-input {
            display: none;
        }

        .profile-pic-navbar {
            position: relative;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #454B1B 0%, #6B7D28 100%);
            border: 2px solid white;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            overflow: hidden;
            flex-shrink: 0;
            transition: all 0.3s ease;
        }

        .profile-pic-navbar:hover {
            transform: scale(1.08);
            box-shadow: 0 2px 8px rgba(69, 75, 27, 0.3);
        }

        .profile-pic-navbar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .profile-pic-navbar-text {
            font-weight: 700;
            color: white;
            font-size: 14px;
            letter-spacing: 0.5px;
        }

        .profile-pic-overlay-navbar {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .profile-pic-navbar:hover .profile-pic-overlay-navbar {
            opacity: 1;
        }

        .profile-pic-overlay-navbar i {
            color: white;
            font-size: 16px;
        }

        .profile-upload-status {
            border-radius: 8px;
            padding: 12px 16px;
            font-weight: 500;
            display: none;
            animation: slideInRight 0.3s ease;
        }

        .profile-upload-status.success {
            background-color: #dcfce7;
            color: #166534;
            border: 1px solid #bbf7d0;
        }

        .profile-upload-status.error {
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        /* ====================================================================
           PROFILE DROPDOWN MENU STYLES
           ==================================================================== */
        .profile-dropdown-container {
            position: relative;
            display: inline-block;
        }

        .profile-dropdown-btn {
            position: relative;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid white;
            background: linear-gradient(135deg, #454B1B 0%, #2a2d0f 100%);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            flex-shrink: 0;
        }

        .profile-dropdown-btn:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .profile-dropdown-btn.active {
            box-shadow: 0 4px 12px rgba(69, 75, 27, 0.3);
        }

        .profile-dropdown-menu {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            min-width: 260px;
            z-index: 1000;
            border: 1px solid #e2e8f0;
            animation: slideDown 0.2s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .profile-dropdown-header {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 16px;
            border-bottom: 1px solid #e2e8f0;
        }

        .dropdown-profile-img,
        .dropdown-profile-initials {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: white;
            background: linear-gradient(135deg, #454B1B 0%, #2a2d0f 100%);
            flex-shrink: 0;
            font-size: 14px;
        }

        .dropdown-profile-img {
            object-fit: cover;
        }

        .dropdown-name {
            font-weight: 600;
            color: #1e293b;
            font-size: 14px;
        }

        .dropdown-role {
            font-size: 12px;
            color: #64748b;
            margin-top: 2px;
        }

        .profile-dropdown-divider {
            height: 1px;
            background-color: #e2e8f0;
            margin: 8px 0;
        }

        .dropdown-menu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: #1e293b;
            text-decoration: none;
            transition: all 0.2s ease;
            font-size: 14px;
            cursor: pointer;
            border: none;
            background: none;
            width: 100%;
            text-align: left;
        }

        .dropdown-menu-item:hover {
            background-color: #f8fafc;
            color: #454B1B;
        }

        .dropdown-menu-item i {
            width: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #454B1B;
        }

        .dropdown-menu-item.logout-item {
            color: #dc2626;
            border-top: 1px solid #e2e8f0;
            margin-top: 8px;
        }

        .dropdown-menu-item.logout-item:hover {
            background-color: #fee2e2;
        }

        .dropdown-menu-item.logout-item i {
            color: #dc2626;
        }

        @keyframes slideInRight {
            from {
                transform: translateX(400px);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        /* ================================================================
           DARK MODE - BHW DASHBOARD (COMPLETE FROM RESIDENT)
           ================================================================ */
        
        html,
        body {
            background-color: #f8fafc !important;
            color: #0f172a !important;
        }

        html.dark,
        html.dark body,
        body.dark-mode {
            background-color: #0d1310 !important;
            color: #f8fafc !important;
        }

        body.dark-mode h1,
        body.dark-mode h2,
        body.dark-mode h3,
        body.dark-mode h4,
        body.dark-mode h5,
        body.dark-mode h6,
        body.dark-mode p,
        body.dark-mode span,
        body.dark-mode label,
        body.dark-mode a,
        body.dark-mode button,
        body.dark-mode div {
            color: #cbd5e1 !important;
        }

        body.dark-mode nav {
            background: #0f172a !important;
            border-color: #334155 !important;
        }

        body.dark-mode .profile-dropdown-menu {
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%) !important;
            border: 1px solid #334155 !important;
        }

        body.dark-mode .profile-dropdown-header,
        body.dark-mode #settingsModal > div > div,
        body.dark-mode #bhwLogoutConfirmModal > div {
            background: #1e293b !important;
            border-color: #334155 !important;
        }

        body.dark-mode .dropdown-menu-item:hover {
            background-color: rgba(69, 75, 27, 0.15) !important;
            color: #454B1B !important;
        }

        body.dark-mode input,
        body.dark-mode select,
        body.dark-mode textarea {
            background: #0f172a !important;
            border-color: #334155 !important;
            color: #cbd5e1 !important;
        }

        body.dark-mode input[type="checkbox"],
        body.dark-mode input[type="radio"] {
            accent-color: #454B1B !important;
        }

        /* Dark theme dashboard polish */
        body.dark-mode nav {
            background: #020617 !important;
            border-color: #111827 !important;
        }

        body.dark-mode .sidebar {
            background: #020617 !important;
            border-color: #111827 !important;
        }

        body.dark-mode .sidebar-item {
            background: transparent !important;
            color: #cbd5e1 !important;
            border-color: transparent !important;
        }

        body.dark-mode .sidebar-item:hover {
            background: rgba(148, 163, 184, 0.08) !important;
            color: #ffffff !important;
            border-color: #334155 !important;
        }

        body.dark-mode .sidebar-item.active {
            background: rgba(56, 189, 248, 0.12) !important;
            color: #f8fafc !important;
            border-color: rgba(56, 189, 248, 0.32) !important;
            box-shadow: inset 0 0 0 1px rgba(148, 163, 184, 0.12) !important;
        }

        body.dark-mode .summary-card,
        body.dark-mode .section-card,
        body.dark-mode .scan-card,
        body.dark-mode .manual-card,
        body.dark-mode .bg-white,
        body.dark-mode .bg-slate-50,
        body.dark-mode .bg-slate-100,
        body.dark-mode .bg-blue-50,
        body.dark-mode .bg-emerald-50,
        body.dark-mode .bg-amber-50,
        body.dark-mode .bg-purple-50,
        body.dark-mode .bg-[#F8FAF6] {
            background-color: #0f172a !important;
            border-color: #111827 !important;
            color: #e2e8f0 !important;
        }

        body.dark-mode .summary-card:hover {
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.38) !important;
        }

        body.dark-mode .search-input {
            background: #0f172a !important;
            border-color: #334155 !important;
            color: #e2e8f0 !important;
        }

        body.dark-mode .search-input::placeholder {
            color: #94a3b8 !important;
        }

        body.dark-mode .primary-button {
            background-color: #38bdf8 !important;
            color: #0f172a !important;
        }

        body.dark-mode .primary-button:hover {
            background-color: #0ea5e9 !important;
        }

        body.dark-mode h1,
        body.dark-mode h2,
        body.dark-mode h3,
        body.dark-mode h4,
        body.dark-mode h5,
        body.dark-mode h6 {
            color: #cbd5e1 !important;
        }

        body.dark-mode p,
        body.dark-mode span,
        body.dark-mode label,
        body.dark-mode small {
            color: #cbd5e1 !important;
        }

        /* Tables - DARK MODE */
        body.dark-mode table {
            background-color: #1e293b !important;
            border-color: #334155 !important;
        }

        body.dark-mode thead {
            background-color: #0f172a !important;
            border-color: #334155 !important;
        }

        body.dark-mode thead th {
            background-color: #0f172a !important;
            color: #cbd5e1 !important;
            border-color: #334155 !important;
        }

        body.dark-mode tbody tr {
            background-color: #1e293b !important;
            border-color: #334155 !important;
        }

        body.dark-mode tbody tr:hover {
            background-color: rgba(69, 75, 27, 0.1) !important;
        }

        body.dark-mode tbody td {
            background-color: #1e293b !important;
            color: #cbd5e1 !important;
            border-color: #334155 !important;
        }

        body.dark-mode th,
        body.dark-mode td {
            color: #cbd5e1 !important;
            border-color: #334155 !important;
        }

        /* Override Tailwind classes for dark mode */
        body.dark-mode.bg-\[#F8FAF6\] {
            background-color: #0d1310 !important;
        }

        body.dark-mode {
            background-color: #0d1310 !important;
        }

        body.dark-mode [class*="bg-white"],
        body.dark-mode [class*="bg-slate"],
        body.dark-mode [class*="bg-gray"] {
            background-color: #1e293b !important;
        }

        body.dark-mode [class*="text-slate"],
        body.dark-mode [class*="text-gray"],
        body.dark-mode [class*="text-black"] {
            color: #cbd5e1 !important;
        }

        body.dark-mode .bg-white {
            background-color: #1e293b !important;
        }

        body.dark-mode .text-slate-800,
        body.dark-mode .text-gray-800,
        body.dark-mode .text-black {
            color: #cbd5e1 !important;
        }

        body.dark-mode .border-\[#454B1B\]\/10 {
            border-color: #334155 !important;
        }

        /* ACTION BUTTONS - Rendered, No Show, Follow-up */
        /* Rendered (Green) button */
        body.dark-mode button[onclick*="rendered"] {
            background: linear-gradient(to right, #10b981 0%, #059669 100%) !important;
            background-image: linear-gradient(to right, #10b981 0%, #059669 100%) !important;
            color: white !important;
        }

        body.dark-mode button[onclick*="rendered"]:hover {
            background: linear-gradient(to right, #34d399 0%, #10b981 100%) !important;
            background-image: linear-gradient(to right, #34d399 0%, #10b981 100%) !important;
        }

        /* No Show (Red) button */
        body.dark-mode button[onclick*="no-show"],
        body.dark-mode button[title="Mark as No Show"] {
            background: linear-gradient(to right, #ef4444 0%, #dc2626 100%) !important;
            background-image: linear-gradient(to right, #ef4444 0%, #dc2626 100%) !important;
            color: white !important;
        }

        body.dark-mode button[onclick*="no-show"]:hover,
        body.dark-mode button[title="Mark as No Show"]:hover {
            background: linear-gradient(to right, #f87171 0%, #ef4444 100%) !important;
            background-image: linear-gradient(to right, #f87171 0%, #ef4444 100%) !important;
        }

        /* Follow-up (Yellow) button */
        body.dark-mode button[onclick*="followup"],
        body.dark-mode button[title="Schedule Follow-up"] {
            background: linear-gradient(to right, #fbbf24 0%, #f59e0b 100%) !important;
            background-image: linear-gradient(to right, #fbbf24 0%, #f59e0b 100%) !important;
            color: #1f2937 !important;
        }

        body.dark-mode button[onclick*="followup"]:hover,
        body.dark-mode button[title="Schedule Follow-up"]:hover {
            background: linear-gradient(to right, #fcd34d 0%, #fbbf24 100%) !important;
            background-image: linear-gradient(to right, #fcd34d 0%, #fbbf24 100%) !important;
        }

        /* Other gradients in dark mode */
        body.dark-mode .bg-gradient-to-br,
        body.dark-mode .bg-gradient-to-b,
        body.dark-mode .bg-gradient-to-l {
            background-image: none !important;
            background: #1e293b !important;
        }

        body.dark-mode section[class*="bg-gradient"] {
            background: #1e293b !important;
        }

        body.dark-mode div[class*="bg-gradient"]:not([onclick*="rendered"]):not([onclick*="no-show"]):not([onclick*="followup"]):not([title*="Mark"]):not([title*="Schedule"]) {
            background: #1e293b !important;
        }

        /* Ensure all text labels are visible in dark mode */
        body.dark-mode .text-slate-400,
        body.dark-mode .text-slate-500,
        body.dark-mode .text-gray-400,
        body.dark-mode .text-gray-500,
        body.dark-mode .text-slate-300 {
            color: #cbd5e1 !important;
        }

        body.dark-mode .font-body,
        body.dark-mode .font-heading {
            color: #cbd5e1 !important;
        }

        body.dark-mode [class*="text-"] {
            color: #cbd5e1 !important;
        }

        /* Cards and their content in dark mode */
        body.dark-mode [class*="rounded-lg"],
        body.dark-mode [class*="rounded-md"],
        body.dark-mode [class*="rounded"] {
            background-color: #1e293b !important;
            color: #cbd5e1 !important;
        }

        /* Small labels and secondary text */
        body.dark-mode small,
        body.dark-mode .text-sm,
        body.dark-mode [class*="text-sm"] {
            color: #cbd5e1 !important;
        }

        /* Ensure inline elements are readable */
        body.dark-mode i {
            color: #cbd5e1 !important;
        }

        /* ================================================================
           COMPREHENSIVE DARK MODE ICON COLORS - ALL ICONS
           ================================================================ */
        
        /* Default icon color */
        body.dark-mode i,
        body.dark-mode .fa,
        body.dark-mode [class*="fa-"] {
            color: #cbd5e1 !important;
        }

        /* Calendar & Date Icons */
        body.dark-mode .fa-calendar,
        body.dark-mode .fa-calendar-check,
        body.dark-mode .fa-calendar-plus,
        body.dark-mode .fa-calendar-alt,
        body.dark-mode .fa-calendar-days {
            color: #fbbf24 !important;
        }

        /* Time & Clock Icons */
        body.dark-mode .fa-clock,
        body.dark-mode .fa-hourglass,
        body.dark-mode .fa-hourglass-end,
        body.dark-mode .fa-watch,
        body.dark-mode .fa-timer {
            color: #60a5fa !important;
        }

        /* User & Profile Icons */
        body.dark-mode .fa-user,
        body.dark-mode .fa-user-circle,
        body.dark-mode .fa-user-alt,
        body.dark-mode .fa-user-check,
        body.dark-mode .fa-user-md,
        body.dark-mode .fa-id-card,
        body.dark-mode .fa-address-card,
        body.dark-mode .fa-people,
        body.dark-mode .fa-users,
        body.dark-mode .fa-user-group {
            color: #a78bfa !important;
        }

        /* History & Records Icons */
        body.dark-mode .fa-history,
        body.dark-mode .fa-list,
        body.dark-mode .fa-list-check,
        body.dark-mode .fa-file,
        body.dark-mode .fa-file-medical,
        body.dark-mode .fa-book,
        body.dark-mode .fa-scroll,
        body.dark-mode .fa-archive,
        body.dark-mode .fa-database {
            color: #34d399 !important;
        }

        /* Success & Check Icons */
        body.dark-mode .fa-check,
        body.dark-mode .fa-check-circle,
        body.dark-mode .fa-check-double,
        body.dark-mode .fa-check-square,
        body.dark-mode .fa-circle-check,
        body.dark-mode .fa-thumbs-up,
        body.dark-mode .fa-checkmark {
            color: #4ade80 !important;
        }

        /* Error & Delete Icons */
        body.dark-mode .fa-times,
        body.dark-mode .fa-times-circle,
        body.dark-mode .fa-xmark,
        body.dark-mode .fa-x,
        body.dark-mode .fa-circle-xmark,
        body.dark-mode .fa-ban,
        body.dark-mode .fa-trash,
        body.dark-mode .fa-trash-alt,
        body.dark-mode .fa-delete,
        body.dark-mode .fa-close {
            color: #f87171 !important;
        }

        /* Notification & Bell Icons */
        body.dark-mode .fa-bell,
        body.dark-mode .fa-bell-alt,
        body.dark-mode .fa-bell-slash {
            color: #fbbf24 !important;
        }

        /* Security & Lock Icons */
        body.dark-mode .fa-lock,
        body.dark-mode .fa-lock-alt,
        body.dark-mode .fa-padlock,
        body.dark-mode .fa-key,
        body.dark-mode .fa-password,
        body.dark-mode .fa-shield,
        body.dark-mode .fa-shield-check {
            color: #60a5fa !important;
        }

        /* Settings & Configuration Icons */
        body.dark-mode .fa-cog,
        body.dark-mode .fa-gear,
        body.dark-mode .fa-sliders,
        body.dark-mode .fa-sliders-h,
        body.dark-mode .fa-wrench,
        body.dark-mode .fa-tools,
        body.dark-mode .fa-screwdriver {
            color: #34d399 !important;
        }

        /* Theme & Appearance Icons */
        body.dark-mode .fa-moon,
        body.dark-mode .fa-sun,
        body.dark-mode .fa-star,
        body.dark-mode .fa-palette {
            color: #fbbf24 !important;
        }

        /* Logout & Exit Icons */
        body.dark-mode .fa-sign-out,
        body.dark-mode .fa-sign-out-alt,
        body.dark-mode .fa-door-open,
        body.dark-mode .fa-right-from-bracket,
        body.dark-mode .fa-arrow-right-from-bracket {
            color: #f87171 !important;
        }

        /* Warning & Alert Icons */
        body.dark-mode .fa-exclamation,
        body.dark-mode .fa-exclamation-circle,
        body.dark-mode .fa-exclamation-triangle,
        body.dark-mode .fa-triangle-exclamation,
        body.dark-mode .fa-warning,
        body.dark-mode .fa-alert {
            color: #fbbf24 !important;
        }

        /* Medical & Health Icons */
        body.dark-mode .fa-stethoscope,
        body.dark-mode .fa-heart,
        body.dark-mode .fa-heart-pulse,
        body.dark-mode .fa-pulse,
        body.dark-mode .fa-hospital,
        body.dark-mode .fa-hospital-alt,
        body.dark-mode .fa-clinic-medical,
        body.dark-mode .fa-pills,
        body.dark-mode .fa-capsules,
        body.dark-mode .fa-prescription,
        body.dark-mode .fa-medicine,
        body.dark-mode .fa-bottle,
        body.dark-mode .fa-syringe,
        body.dark-mode .fa-bandage,
        body.dark-mode .fa-microscope,
        body.dark-mode .fa-dna {
            color: #ef4444 !important;
        }

        /* Action & Navigation Icons */
        body.dark-mode .fa-arrow-right,
        body.dark-mode .fa-arrow-left,
        body.dark-mode .fa-arrow-up,
        body.dark-mode .fa-arrow-down,
        body.dark-mode .fa-arrow-right-long,
        body.dark-mode .fa-arrow-left-long,
        body.dark-mode .fa-chevron-right,
        body.dark-mode .fa-chevron-left,
        body.dark-mode .fa-chevron-down,
        body.dark-mode .fa-chevron-up,
        body.dark-mode .fa-angles-right,
        body.dark-mode .fa-angles-left,
        body.dark-mode .fa-play,
        body.dark-mode .fa-pause,
        body.dark-mode .fa-next {
            color: #60a5fa !important;
        }

        /* Plus & Add Icons */
        body.dark-mode .fa-plus,
        body.dark-mode .fa-plus-circle,
        body.dark-mode .fa-circle-plus,
        body.dark-mode .fa-add {
            color: #4ade80 !important;
        }

        /* Minus & Remove Icons */
        body.dark-mode .fa-minus,
        body.dark-mode .fa-minus-circle,
        body.dark-mode .fa-circle-minus {
            color: #f87171 !important;
        }

        /* Search & Find Icons */
        body.dark-mode .fa-search,
        body.dark-mode .fa-magnifying-glass,
        body.dark-mode .fa-zoom-in,
        body.dark-mode .fa-binoculars {
            color: #a78bfa !important;
        }

        /* Download & Upload Icons */
        body.dark-mode .fa-download,
        body.dark-mode .fa-upload,
        body.dark-mode .fa-cloud-download,
        body.dark-mode .fa-cloud-upload {
            color: #60a5fa !important;
        }

        /* Edit & Edit Icons */
        body.dark-mode .fa-edit,
        body.dark-mode .fa-pencil,
        body.dark-mode .fa-pencil-alt,
        body.dark-mode .fa-pen,
        body.dark-mode .fa-pen-to-square {
            color: #fbbf24 !important;
        }

        /* Copy & Duplicate Icons */
        body.dark-mode .fa-copy,
        body.dark-mode .fa-clone,
        body.dark-mode .fa-duplicate {
            color: #34d399 !important;
        }

        /* Filter & Sort Icons */
        body.dark-mode .fa-filter,
        body.dark-mode .fa-funnel,
        body.dark-mode .fa-sort,
        body.dark-mode .fa-sort-down,
        body.dark-mode .fa-sort-up {
            color: #a78bfa !important;
        }

        /* Print & Save Icons */
        body.dark-mode .fa-print,
        body.dark-mode .fa-save,
        body.dark-mode .fa-floppy-disk,
        body.dark-mode .fa-download {
            color: #60a5fa !important;
        }

        /* Phone & Communication Icons */
        body.dark-mode .fa-phone,
        body.dark-mode .fa-phone-alt,
        body.dark-mode .fa-mobile,
        body.dark-mode .fa-mobile-alt,
        body.dark-mode .fa-phone-square,
        body.dark-mode .fa-envelope,
        body.dark-mode .fa-envelope-open,
        body.dark-mode .fa-envelope-square,
        body.dark-mode .fa-mail,
        body.dark-mode .fa-sms,
        body.dark-mode .fa-message {
            color: #4ade80 !important;
        }

        /* Location & Map Icons */
        body.dark-mode .fa-location,
        body.dark-mode .fa-location-dot,
        body.dark-mode .fa-map,
        body.dark-mode .fa-map-location,
        body.dark-mode .fa-compass,
        body.dark-mode .fa-location-pin {
            color: #ef4444 !important;
        }

        /* Document & Clipboard Icons */
        body.dark-mode .fa-clipboard,
        body.dark-mode .fa-clipboard-check,
        body.dark-mode .fa-clipboard-list,
        body.dark-mode .fa-document,
        body.dark-mode .fa-file-text {
            color: #a78bfa !important;
        }

        /* Barcode & QR Icons */
        body.dark-mode .fa-barcode,
        body.dark-mode .fa-qrcode,
        body.dark-mode .fa-barcode-read,
        body.dark-mode .fa-scanner {
            color: #4ade80 !important;
        }

        /* Dashboard & View Icons */
        body.dark-mode .fa-chart,
        body.dark-mode .fa-chart-bar,
        body.dark-mode .fa-chart-line,
        body.dark-mode .fa-chart-pie,
        body.dark-mode .fa-dashboard,
        body.dark-mode .fa-eye,
        body.dark-mode .fa-eye-alt {
            color: #60a5fa !important;
        }

        /* ================================================================
           LOGOUT BUTTON - DARK MODE STYLING
           ================================================================ */
        
        /* Logout button with border in dark mode */
        body.dark-mode button[onclick="confirmBHWLogout()"],
        body.dark-mode button[onclick*="confirmBHWLogout"] {
            border: 2px solid #f87171 !important;
            background-color: #dc2626 !important;
            color: white !important;
        }

        body.dark-mode button[onclick="confirmBHWLogout()"]:hover,
        body.dark-mode button[onclick*="confirmBHWLogout"]:hover {
            border-color: #fca5a5 !important;
            background-color: #b91c1c !important;
        }

        /* Modal background in dark mode */
        body.dark-mode #bhwLogoutConfirmModal {
            background-color: rgba(0, 0, 0, 0.7) !important;
        }

        /* Modal dialog in dark mode */
        body.dark-mode #bhwLogoutConfirmModal .bg-white {
            background-color: #1e293b !important;
            border-color: #334155 !important;
        }

        /* Modal header border in dark mode */
        body.dark-mode #bhwLogoutConfirmModal [class*="border-b"] {
            border-color: #334155 !important;
        }

        /* Modal content text in dark mode */
        body.dark-mode #bhwLogoutConfirmModal .text-slate-900 {
            color: #f1f5f9 !important;
        }

        body.dark-mode #bhwLogoutConfirmModal .text-slate-600 {
            color: #cbd5e1 !important;
        }

        /* Cancel button in dark mode */
        body.dark-mode button[onclick="closeBHWLogoutConfirmModal()"] {
            background-color: #334155 !important;
            color: #e2e8f0 !important;
            border-color: #475569 !important;
        }

        body.dark-mode button[onclick="closeBHWLogoutConfirmModal()"]:hover {
            background-color: #475569 !important;
            color: #f1f5f9 !important;
        }

        /* ================================================================
           SETTINGS MODAL BUTTONS - DARK MODE STYLING
           ================================================================ */
        
        /* Settings modal background in dark mode */
        body.dark-mode #settingsModal {
            background-color: rgba(0, 0, 0, 0.7) !important;
        }

        /* Settings modal dialog in dark mode */
        body.dark-mode #settingsModal .bg-white {
            background-color: #1e293b !important;
        }

        /* Settings modal header in dark mode */
        body.dark-mode #settingsModal [class*="border-b"] {
            border-color: #334155 !important;
        }

        body.dark-mode #settingsModal .text-slate-900 {
            color: #f1f5f9 !important;
        }

        body.dark-mode #settingsModal .text-slate-500 {
            color: #cbd5e1 !important;
        }

        body.dark-mode #settingsModal .text-slate-700 {
            color: #e2e8f0 !important;
        }

        /* Settings modal section headings in dark mode */
        body.dark-mode #settingsModal h4 {
            color: #f1f5f9 !important;
        }

        /* Close button in settings modal (dark mode) */
        body.dark-mode button[onclick="closeSettingsModal()"] {
            background-color: #334155 !important;
            color: #cbd5e1 !important;
            border-color: #475569 !important;
        }

        body.dark-mode button[onclick="closeSettingsModal()"]:hover {
            background-color: #475569 !important;
            color: #f1f5f9 !important;
        }

        /* Save Settings button in settings modal (dark mode) */
        body.dark-mode button[onclick="saveSettings()"] {
            background-color: #454B1B !important;
            color: white !important;
            border: 2px solid #6b7c2f !important;
        }

        body.dark-mode button[onclick="saveSettings()"]:hover {
            background-color: #5a6324 !important;
            border-color: #8ba83f !important;
        }

        /* Change Password button in settings modal (dark mode) */
        body.dark-mode button[onclick="changePassword()"] {
            background-color: #3b82f6 !important;
            color: white !important;
            border: 1px solid #60a5fa !important;
        }

        body.dark-mode button[onclick="changePassword()"]:hover {
            background-color: #2563eb !important;
            border-color: #93c5fd !important;
        }

        /* Settings modal footer border in dark mode */
        body.dark-mode #settingsModal [class*="border-t"] {
            border-color: #334155 !important;
        }

        /* Bright colored icons in dark mode */
        body.dark-mode .fa-calendar {
            color: #fbbf24 !important;
        }

        body.dark-mode .fa-clock {
            color: #60a5fa !important;
        }

        body.dark-mode .fa-user,
        body.dark-mode .fa-user-circle {
            color: #a78bfa !important;
        }

        body.dark-mode .fa-history {
            color: #34d399 !important;
        }

        body.dark-mode .fa-check {
            color: #4ade80 !important;
        }

        body.dark-mode .fa-times {
            color: #f87171 !important;
        }

        body.dark-mode .fa-bell {
            color: #fbbf24 !important;
        }

        body.dark-mode .fa-lock {
            color: #a78bfa !important;
        }

        body.dark-mode .fa-moon {
            color: #fbbf24 !important;
        }

        body.dark-mode .fa-key {
            color: #60a5fa !important;
        }

        body.dark-mode .fa-cog,
        body.dark-mode .fa-gear {
            color: #34d399 !important;
        }

        body.dark-mode .fa-sign-out-alt {
            color: #f87171 !important;
        }

        body.dark-mode .fa-exclamation-circle {
            color: #fbbf24 !important;
        }

        /* Light color text for all labels - admin panel style */
        body.dark-mode label,
        body.dark-mode span,
        body.dark-mode .text-sm,
        body.dark-mode [class*="text-sm"],
        body.dark-mode small,
        body.dark-mode h2,
        body.dark-mode h3,
        body.dark-mode h4 {
            color: #cbd5e1 !important;
        }

        /* Stat cards with gradient backgrounds in dark mode */
        body.dark-mode .bg-blue-50 {
            background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 100%) !important;
        }

        body.dark-mode .bg-green-50 {
            background: linear-gradient(135deg, #15803d 0%, #16a34a 100%) !important;
        }

        body.dark-mode .bg-orange-50 {
            background: linear-gradient(135deg, #92400e 0%, #b45309 100%) !important;
        }

        body.dark-mode .bg-red-50 {
            background: linear-gradient(135deg, #7f1d1d 0%, #991b1b 100%) !important;
        }

        body.dark-mode .bg-purple-50 {
            background: linear-gradient(135deg, #5b21b6 0%, #7c3aed 100%) !important;
        }

        /* Ensure text is visible on gradient backgrounds */
        body.dark-mode .text-blue-700 {
            color: #bfdbfe !important;
        }

        body.dark-mode .text-green-700 {
            color: #86efac !important;
        }

        body.dark-mode .text-orange-700 {
            color: #fed7aa !important;
        }

        body.dark-mode .text-red-700 {
            color: #fca5a5 !important;
        }

        body.dark-mode .text-purple-700 {
            color: #d8b4fe !important;
        }

        /* Secondary text colors */
        body.dark-mode .text-blue-600 {
            color: #93c5fd !important;
        }

        body.dark-mode .text-green-600 {
            color: #6ee7b7 !important;
        }

        body.dark-mode .text-orange-600 {
            color: #fdba74 !important;
        }

        body.dark-mode .text-red-600 {
            color: #f87171 !important;
        }

        body.dark-mode .text-purple-600 {
            color: #c084fc !important;
        }

        /* Dashboard navy layout theme */
        html.dark main,
        body.dark-mode main,
        html.dark .main-content,
        body.dark-mode .main-content,
        html.dark .dashboard-container,
        body.dark-mode .dashboard-container {
            background-color: #0b1329 !important;
        }

        html.dark > body,
        body.dark-mode {
            background-color: #0b1329 !important;
        }

        html.dark body > nav,
        body.dark-mode > nav,
        html.dark nav.border-b,
        body.dark-mode nav.border-b {
            background-color: #111a36 !important;
            border-color: rgba(51, 65, 85, 0.5) !important;
        }

        html.dark .sidebar,
        body.dark-mode .sidebar,
        html.dark .sidebar-nav,
        body.dark-mode .sidebar-nav {
            background-color: #111a36 !important;
            border-color: rgba(51, 65, 85, 0.5) !important;
        }

        html.dark main .summary-card,
        body.dark-mode main .summary-card,
        html.dark main .section-card,
        body.dark-mode main .section-card,
        html.dark main .scan-card,
        body.dark-mode main .scan-card,
        html.dark main .manual-card,
        body.dark-mode main .manual-card,
        html.dark main [class*="rounded-2xl"][class*="bg-white"],
        body.dark-mode main [class*="rounded-2xl"][class*="bg-white"],
        html.dark main [class*="rounded-[28px]"],
        body.dark-mode main [class*="rounded-[28px]"] {
            background: #1a254b !important;
            border-color: rgba(51, 65, 85, 0.5) !important;
        }

        html.dark .sidebar-item.active,
        body.dark-mode .sidebar-item.active,
        html.dark main button[class*="bg-[#3D4A1E]"],
        body.dark-mode main button[class*="bg-[#3D4A1E]"] {
            background: linear-gradient(to right, #10b981, #0d9488) !important;
            border-color: rgba(16, 185, 129, 0.65) !important;
            box-shadow: 0 0 18px rgba(16, 185, 129, 0.18) !important;
        }

        html.dark main .border-slate-200,
        body.dark-mode main .border-slate-200,
        html.dark main [class*="border-slate-200"],
        body.dark-mode main [class*="border-slate-200"] {
            border-color: rgba(51, 65, 85, 0.5) !important;
        }
    </style>

    <!-- ====================================================================
         HTML5-QRCODE LIBRARY - Live Webcam QR Scanning
         Source: https://unpkg.com/html5-qrcode
         ==================================================================== -->
    <script src="https://unpkg.com/html5-qrcode"></script>
</head>
<body class="min-h-screen bg-[#f8faf6] font-body text-slate-800 antialiased selection:bg-[#3D4A1E] selection:text-white dark:bg-[#0b1329] dark:text-slate-100">

    <!-- ========================================================================
         HEADER & NAVIGATION BAR (included from components/header_bhw.php)
         ======================================================================== -->
    <?php
    // Provide $profile_picture if available from earlier logic
    if (!isset($profile_picture) && function_exists('getCurrentWorkerProfilePicture')) {
        $profile_picture = getCurrentWorkerProfilePicture();
    }
    include __DIR__ . '/components/header_bhw_new.php';
    ?>

    <?php include __DIR__ . '/components/approval_poll.php'; ?>

    <aside class="sidebar !top-20 !bottom-0 !overflow-y-auto !overflow-x-hidden !bg-transparent !shadow-none dark:!border-transparent dark:!bg-transparent lg:block">
        <nav id="mobileSidebarNav" class="sidebar-nav" aria-label="Main navigation">
            <p class="sidebar-section-label px-3 text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">Workspace</p>
            <a href="?module=identify-patient" class="sidebar-item <?php echo isModuleActive('identify-patient') ? 'active !bg-[#3D4A1E] !text-white' : 'dark:!text-slate-300'; ?>">
                <i class="fas fa-user-check"></i> <span class="sidebar-item-text">Identify Patient</span>
            </a>
            <a href="?module=consultation" class="sidebar-item <?php echo isModuleActive('consultation') ? 'active !bg-[#3D4A1E] !text-white' : 'dark:!text-slate-300'; ?>">
                <i class="fas fa-stethoscope"></i> <span class="sidebar-item-text">Consultations</span>
            </a>
            <a href="?module=inventory" class="sidebar-item <?php echo isModuleActive('inventory') ? 'active !bg-[#3D4A1E] !text-white' : 'dark:!text-slate-300'; ?>">
                <i class="fas fa-pills"></i> <span class="sidebar-item-text">Medicine Inventory</span>
            </a>
            <a href="?module=surveillance" class="sidebar-item <?php echo isModuleActive('surveillance') ? 'active !bg-[#3D4A1E] !text-white' : 'dark:!text-slate-300'; ?>">
                <i class="fas fa-shield-virus"></i> <span class="sidebar-item-text">Surveillance</span>
            </a>
            <p class="sidebar-section-label mt-8 px-3 text-xs font-semibold uppercase tracking-wider text-slate-400 dark:text-slate-500">Operations</p>
            <a href="?module=appointments" class="sidebar-item <?php echo isModuleActive('appointments') ? 'active !bg-[#3D4A1E] !text-white' : 'dark:!text-slate-300'; ?>">
                <i class="fas fa-calendar-alt"></i> <span class="sidebar-item-text">Appointments</span>
            </a>
            <a href="?module=sms" class="sidebar-item <?php echo isModuleActive('sms') ? 'active !bg-[#3D4A1E] !text-white' : 'dark:!text-slate-300'; ?>">
                <i class="fas fa-sms"></i> <span class="sidebar-item-text">SMS Communications</span>
            </a>
            <a href="?module=announcements" class="sidebar-item <?php echo isModuleActive('announcements') ? 'active !bg-[#3D4A1E] !text-white' : 'dark:!text-slate-300'; ?>">
                <i class="fas fa-bullhorn"></i> <span class="sidebar-item-text">Announcements</span>
            </a>
        </nav>
    </aside>

    <!-- ========================================================================
         MAIN DASHBOARD CONTAINER
         ======================================================================== -->
    <main class="bg-dark-grid main-with-sidebar bg-[#f8fafc] dark:bg-[#0b1329] flex-1">
        <div class="mx-auto w-full max-w-7xl px-4 pb-12 pt-8 sm:px-6 lg:px-8">

            <section class="mb-8">
                <div class="mb-5 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
                    <div>
                        <p class="mb-2 text-sm font-semibold uppercase tracking-[0.18em] text-[#3D4A1E] dark:text-emerald-300">BHW workspace</p>
                        <h1 class="font-heading text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white">Good day, <?php echo htmlspecialchars($worker_name); ?></h1>
                        <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">Manage community care from one focused dashboard.</p>
                    </div>
                    <div class="inline-flex items-center gap-2 self-start rounded-full border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs font-semibold text-emerald-700 dark:border-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300 sm:self-auto">
                        <span class="h-2 w-2 rounded-full bg-emerald-500"></span> System online
                    </div>
                </div>
                <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
                    <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
                        <div class="mb-4 flex items-center justify-between"><span class="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-900/30 dark:text-blue-300"><i class="fas fa-calendar-check"></i></span><span class="text-xs font-semibold text-slate-400">Today</span></div>
                        <p class="text-sm font-medium text-slate-500 dark:text-slate-400">Total Appointments</p><p class="mt-1 text-3xl font-bold text-slate-900 dark:text-white"><?php echo intval($total_appointments); ?></p>
                    </div>
                    <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
                        <div class="mb-4 flex items-center justify-between"><span class="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-50 text-amber-600 dark:bg-amber-900/30 dark:text-amber-300"><i class="fas fa-clock"></i></span><span class="text-xs font-semibold text-slate-400">Queue</span></div>
                        <p class="text-sm font-medium text-slate-500 dark:text-slate-400">Pending Consultations</p><p class="mt-1 text-3xl font-bold text-slate-900 dark:text-white"><?php echo intval($pending_consultations); ?></p>
                    </div>
                    <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
                        <div class="mb-4 flex items-center justify-between"><span class="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-300"><i class="fas fa-pills"></i></span><span class="text-xs font-semibold text-slate-400">In stock</span></div>
                        <p class="text-sm font-medium text-slate-500 dark:text-slate-400">Available Medicine</p><p class="mt-1 text-3xl font-bold text-slate-900 dark:text-white"><?php echo intval($medicine_available); ?></p>
                    </div>
                    <div class="rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-800">
                        <div class="mb-4 flex items-center justify-between"><span class="flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-slate-600 dark:bg-slate-700 dark:text-slate-200"><i class="fas fa-boxes-stacked"></i></span><span class="text-xs font-semibold text-slate-400">Catalog</span></div>
                        <p class="text-sm font-medium text-slate-500 dark:text-slate-400">Total Items</p><p class="mt-1 text-3xl font-bold text-slate-900 dark:text-white"><?php echo intval($medicine_count); ?></p>
                    </div>
                </div>
            </section>

            <!-- ====================================================================
                 TABBED MODULE NAVIGATION
                 ==================================================================== -->
            <div class="mb-8 overflow-hidden rounded-2xl border border-slate-200/80 bg-white shadow-sm dark:border-slate-700 dark:bg-slate-800">
                <?php if (isModuleActive('identify-patient')): ?>
                <div class="flex items-center gap-3 border-b border-slate-200 px-6 py-4 dark:border-slate-700">
                    <div class="flex h-11 w-11 items-center justify-center rounded-2xl bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-200">
                        <i class="fas fa-user-plus text-lg"></i>
                    </div>
                    <div>
                        <p class="text-sm uppercase tracking-[0.3em] text-slate-400 mb-1">ScanCare</p>
                        <h2 class="m-0 text-xl font-heading font-bold text-slate-900 dark:text-white">Identify Patient</h2>
                    </div>
                </div>
                <?php endif; ?>

                <!-- MODULE CONTENT AREA -->
                <div class="p-4 module-content">

                    <!-- ============================================================
                         MODULE: IDENTIFY PATIENT
                         ============================================================ -->
                    <?php if (isModuleActive('identify-patient')): ?>
                    <div>
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
                            <!-- QR Code Scan Option -->
                            <div class="border border-slate-200 rounded-[28px] p-5 text-center bg-slate-50 shadow-sm">
                                <div class="w-16 h-16 bg-slate-900/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                                    <i class="fas fa-qrcode text-3xl text-slate-900"></i>
                                </div>
                                <h3 class="text-lg font-heading font-bold text-slate-900 mb-2">Scan Patient QR Code</h3>
                                <p class="text-sm text-slate-600 mb-6">Point your camera at the patient's QR ID card for instant identification.</p>
                                <button onclick="initiateCameraCapture()" class="w-full rounded-2xl bg-[#3D4A1E] px-4 py-3 text-sm font-semibold text-white transition-all hover:bg-[#303a18] inline-flex items-center justify-center gap-2">
                                    <i class="fas fa-camera"></i> Start QR Scanner
                                </button>
                            </div>

                            <!-- ====================================================================
                                 QR SCANNER CONTAINER - Hidden by default, shown on button click
                                 ==================================================================== -->
                            <div id="qrScannerContainer">
                                <div class="qr-scanner-box">
                                    <!-- Header -->
                                    <div class="qr-scanner-header">
                                        <h2>Patient QR Scanner</h2>
                                        <button class="qr-scanner-close" onclick="stopQRScanner()">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>

                                    <!-- Camera Feed Container (html5-qrcode will inject here) -->
                                    <div id="html5-qrcode" style="width: 100%; height: 300px;"></div>

                                    <!-- Status Message -->
                                    <div id="qrScannerStatus" class="qr-scanner-status scanning">
                                        <div class="qr-scanner-spinner"></div>
                                        <span>Initializing camera...</span>
                                    </div>

                                    <!-- Instructions -->
                                    <div class="qr-scanner-instructions">
                                        <i class="fas fa-phone-alt" style="color: #454B1B; margin-right: 8px;"></i>
                                        Point your phone's camera at the patient's QR code
                                    </div>

                                    <!-- Action Buttons -->
                                    <div class="qr-scanner-buttons">
                                        <!-- Fallback: upload QR image when camera unavailable -->
                                        <input type="file" id="qrImageFile" accept="image/*" style="display:none" />
                                        <button type="button" onclick="document.getElementById('qrImageFile').click()" class="qr-scanner-button qr-scanner-button-secondary" style="margin-right:8px;">
                                            <i class="fas fa-upload" style="margin-right:6px;"></i> Upload QR Image
                                        </button>
                                        <button type="button" onclick="testCamera()" class="qr-scanner-button qr-scanner-button-primary" style="margin-right:8px; background:#2b6a30; color:#fff;">
                                            <i class="fas fa-video" style="margin-right:6px;"></i> Test Camera
                                        </button>
                                        <button onclick="stopQRScanner()" class="qr-scanner-button qr-scanner-button-secondary">
                                            <i class="fas fa-times" style="margin-right: 6px;"></i> Cancel
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Manual Entry Option -->
                            <div class="border border-emerald-200 rounded-[28px] p-6 bg-emerald-50 shadow-sm">
                                <div class="flex items-center gap-2 mb-4">
                                    <div class="w-16 h-16 bg-emerald-100 rounded-2xl flex items-center justify-center">
                                        <i class="fas fa-keyboard text-3xl text-emerald-600"></i>
                                    </div>
                                    <span class="inline-block px-3 py-1 bg-emerald-200 text-emerald-800 text-xs font-bold rounded-full">No QR Available</span>
                                </div>
                                <h3 class="text-lg font-heading font-bold text-slate-900 mb-2">Manual Entry</h3>
                                <p class="text-sm text-slate-600 mb-6">Search by name, email, phone number, or resident ID</p>
                                
                                <!-- Error Banner -->
                                <div id="manualSearchErrorBanner" style="display: none;" class="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                                    <div class="flex-shrink-0 mt-0.5">
                                        <i class="fas fa-exclamation-circle text-red-600 text-lg"></i>
                                    </div>
                                    <div class="flex-1">
                                        <p id="manualSearchErrorText" class="text-sm font-semibold text-red-800">Error message will appear here</p>
                                    </div>
                                    <button type="button" onclick="closeManualSearchError()" class="flex-shrink-0 text-red-400 hover:text-red-600 transition-colors">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                                
                                <!-- Search Form -->
                                <form id="manualEntryForm" class="space-y-4">
                                    <div>
                                        <label class="block text-sm font-semibold text-slate-700 mb-1">Search Patient</label>
                                        <input type="text" name="search_term" placeholder="e.g., Maria, maria@email.com, 09171234567, or ID 27" class="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B]" required autocomplete="off" oninput="handleManualSearchInput(event)">
                                        <p class="text-xs text-slate-500 mt-1">Name • Email • Phone • ID</p>
                                    </div>
                                    <button type="submit" class="w-full rounded-2xl bg-[#3D4A1E] px-4 py-3 text-sm font-semibold text-white transition-all hover:bg-[#303a18] inline-flex items-center justify-center gap-2">
                                        <i class="fas fa-search"></i> Search Patient
                                    </button>
                                </form>

                                <div id="manualSearchResults" class="mt-4 hidden manual-search-dropdown">
                                    <div class="dropdown-panel">
                                        <div class="rounded-2xl bg-white p-4">
                                            <div class="mb-3 flex items-center justify-between">
                                                <div>
                                                    <h4 class="text-sm font-semibold text-slate-800">Select a matching patient</h4>
                                                    <p class="text-xs text-slate-500">Choose the correct person from the list below.</p>
                                                </div>
                                                <button type="button" onclick="clearManualSearchResults()" class="text-slate-400 hover:text-slate-600 text-sm">Clear</button>
                                            </div>
                                        </div>
                                        <div id="manualSearchResultsList" class="space-y-2 p-4"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- ============================================================
                         MODULE: PATIENT PROFILE VIEW
                         ============================================================ -->
                    <?php if (isModuleActive('patient-profile')): ?>
                    <div>
                        <h2 class="text-2xl font-heading font-bold text-slate-900 mb-6">Patient Profile</h2>
                        
                        <?php if ($patient_identified && $patient_data): ?>
                            <!-- PATIENT PROFILE LOADED - Display Full Profile -->
                            <div class="space-y-6">
                                <!-- Complete Profile Card -->
                                <div class="bg-white border border-slate-200 rounded-xl p-8">
                                    <h3 class="text-lg font-heading font-bold text-slate-900 mb-6 flex items-center gap-2">
                                        <i class="fas fa-user text-[#454B1B]"></i> Complete Profile
                                    </h3>
                                    
                                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                                        <!-- Full Name -->
                                        <div class="space-y-2">
                                            <p class="text-xs font-bold text-slate-500 uppercase tracking-wider">Full Name</p>
                                            <p class="text-lg font-semibold text-slate-900"><?php echo htmlspecialchars($patient_data['full_name'] ?? 'N/A'); ?></p>
                                        </div>
                                        
                                        <!-- Email -->
                                        <div class="space-y-2">
                                            <p class="text-xs font-bold text-slate-500 uppercase tracking-wider">Email Address</p>
                                            <p class="text-slate-900"><a href="mailto:<?php echo htmlspecialchars($patient_data['email'] ?? ''); ?>" class="text-[#454B1B] hover:underline"><?php echo htmlspecialchars($patient_data['email'] ?? 'N/A'); ?></a></p>
                                        </div>
                                        
                                        <!-- Phone -->
                                        <div class="space-y-2">
                                            <p class="text-xs font-bold text-slate-500 uppercase tracking-wider">Phone Number</p>
                                            <p class="text-slate-900"><a href="tel:<?php echo htmlspecialchars($patient_data['contact_number'] ?? ''); ?>" class="text-[#454B1B] hover:underline"><?php echo htmlspecialchars($patient_data['contact_number'] ?? 'N/A'); ?></a></p>
                                        </div>
                                        
                                        <!-- Resident ID -->
                                        <div class="space-y-2">
                                            <p class="text-xs font-bold text-slate-500 uppercase tracking-wider">Resident ID</p>
                                            <p class="text-slate-900 font-mono text-lg"><?php echo htmlspecialchars($patient_data['patient_code'] ?? str_pad((string)($patient_data['resident_id'] ?? 0), 6, '0', STR_PAD_LEFT)); ?></p>
                                        </div>
                                        
                                        <!-- Sex -->
                                        <div class="space-y-2">
                                            <p class="text-xs font-bold text-slate-500 uppercase tracking-wider">Sex</p>
                                            <p class="text-slate-900"><?php echo htmlspecialchars($patient_data['sex'] ?? 'N/A'); ?></p>
                                        </div>
                                        
                                        <!-- Date of Birth -->
                                        <div class="space-y-2">
                                            <p class="text-xs font-bold text-slate-500 uppercase tracking-wider">Date of Birth</p>
                                            <p class="text-slate-900">
                                                <?php 
                                                if (!empty($patient_data['date_of_birth'])) {
                                                    echo date('M d, Y', strtotime($patient_data['date_of_birth']));
                                                } else {
                                                    echo 'N/A';
                                                }
                                                ?>
                                            </p>
                                        </div>
                                    </div>
                                    
                                    <!-- Address Section -->
                                    <div class="mt-8 pt-8 border-t border-slate-200">
                                        <p class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">Address</p>
                                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <?php 
                                                // Parse address string if separate fields don't exist
                                                $street_address = $patient_data['address'] ?? 'N/A';
                                                $barangay = $patient_data['barangay'] ?? 'N/A';
                                                $city = $patient_data['city'] ?? 'N/A';
                                                $province_postal = ($patient_data['province'] ?? '') . ' ' . ($patient_data['postal_code'] ?? '');
                                                
                                                // If all separate fields are N/A, try to parse from single address string
                                                if (($patient_data['address'] ?? '') && $barangay === 'N/A' && $city === 'N/A') {
                                                    $address_parts = array_map('trim', explode(',', $patient_data['address']));
                                                    $street_address = $address_parts[0] ?? 'N/A';
                                                    $barangay = $address_parts[1] ?? 'N/A';
                                                    $city = $address_parts[2] ?? 'N/A';
                                                    $province_postal = $address_parts[3] ?? 'N/A';
                                                }
                                            ?>
                                            <div>
                                                <p class="text-sm text-slate-600 mb-1">Street Address</p>
                                                <p class="font-semibold text-slate-900"><?php echo htmlspecialchars($street_address); ?></p>
                                            </div>
                                            <div>
                                                <p class="text-sm text-slate-600 mb-1">Barangay</p>
                                                <p class="font-semibold text-slate-900"><?php echo htmlspecialchars($barangay); ?></p>
                                            </div>
                                            <div>
                                                <p class="text-sm text-slate-600 mb-1">City</p>
                                                <p class="font-semibold text-slate-900"><?php echo htmlspecialchars($city); ?></p>
                                            </div>
                                            <div>
                                                <p class="text-sm text-slate-600 mb-1">Province / Postal Code</p>
                                                <p class="font-semibold text-slate-900"><?php echo htmlspecialchars(trim($province_postal)); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Medical History Card -->
                                <div class="bg-emerald-50 border border-emerald-200 rounded-xl p-8">
                                    <div class="flex items-center justify-between mb-6">
                                        <h3 class="text-lg font-heading font-bold text-emerald-900 flex items-center gap-2">
                                            <i class="fas fa-file-medical text-emerald-600"></i> Medical Visit History
                                        </h3>
                                        <?php if (!empty($patient_data['medical_history']) && count($patient_data['medical_history']) > 0): ?>
                                            <button type="button" id="clearHistoryBtn_<?php echo $patient_id; ?>" onclick="clearMedicalHistory(<?php echo $patient_id; ?>, event)" class="px-3 py-1 bg-red-100 text-red-700 text-xs font-semibold rounded-lg hover:bg-red-200 transition-colors duration-200 flex items-center gap-1">
                                                <i class="fas fa-trash-alt"></i> Clear History
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if (!empty($patient_data['medical_history']) && count($patient_data['medical_history']) > 0): ?>
                                        <div class="mb-4 p-3 bg-emerald-100 border border-emerald-300 rounded-lg text-sm text-emerald-800">
                                            <i class="fas fa-info-circle mr-2"></i>
                                            <strong><?php echo count($patient_data['medical_history']); ?></strong> medical record(s) found
                                        </div>
                                        <div class="space-y-4 max-h-96 overflow-y-auto">
                                            <?php foreach ($patient_data['medical_history'] as $record): ?>
                                                <div class="bg-white border-l-4 border-emerald-500 rounded-lg p-4">
                                                    <div class="flex items-start justify-between mb-2">
                                                        <div>
                                                            <span class="inline-block px-2 py-1 bg-emerald-100 text-emerald-800 text-xs font-semibold rounded mb-2">Medical Visit</span>
                                                            <h4 class="font-semibold text-slate-900"><?php echo htmlspecialchars($record['diagnosis'] ?? 'N/A'); ?></h4>
                                                        </div>
                                                        <span class="text-xs text-slate-500">
                                                            <?php echo date('M d, Y', strtotime($record['created_at'] ?? '')); ?>
                                                        </span>
                                                    </div>
                                                    <p class="text-sm text-slate-700 mb-2">
                                                        <strong>Treatment:</strong> <?php echo htmlspecialchars($record['treatment'] ?? 'N/A'); ?>
                                                    </p>
                                                    <?php if (!empty($record['notes'])): ?>
                                                        <p class="text-xs text-slate-600 italic">
                                                            <strong>Notes:</strong> <?php echo htmlspecialchars($record['notes']); ?>
                                                        </p>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center py-8">
                                            <i class="fas fa-inbox text-4xl text-emerald-200 mb-3 block"></i>
                                            <p class="text-emerald-800">No medical visit records found for this patient.</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Follow-Up Check-Up Card -->
                                <div class="bg-blue-50 border border-blue-200 rounded-xl p-8">
                                    <div class="flex items-center justify-between mb-6">
                                        <h3 class="text-lg font-heading font-bold text-blue-900 flex items-center gap-2">
                                            <i class="fas fa-calendar-check text-blue-600"></i> Follow Up Check Up
                                        </h3>
                                        <?php if (!empty($patient_data['followup_checkups']) && count($patient_data['followup_checkups']) > 0): ?>
                                            <button type="button" onclick="clearFollowupCheckups(<?php echo $patient_id; ?>)" class="px-3 py-1 bg-red-100 text-red-700 text-xs font-semibold rounded-lg hover:bg-red-200 transition-colors duration-200 flex items-center gap-1">
                                                <i class="fas fa-trash-alt"></i> Clear Followups
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if (!empty($patient_data['followup_checkups']) && count($patient_data['followup_checkups']) > 0): ?>
                                        <div class="mb-4 p-3 bg-blue-100 border border-blue-300 rounded-lg text-sm text-blue-800">
                                            <i class="fas fa-info-circle mr-2"></i>
                                            <strong><?php echo count($patient_data['followup_checkups']); ?></strong> follow-up check-up(s) scheduled
                                        </div>
                                        <div class="space-y-4 max-h-96 overflow-y-auto">
                                            <?php foreach ($patient_data['followup_checkups'] as $followup): ?>
                                                <div class="bg-white border-l-4 border-blue-500 rounded-lg p-4">
                                                    <div class="flex items-start justify-between mb-3">
                                                        <div>
                                                            <span class="inline-block px-2 py-1 bg-blue-100 text-blue-800 text-xs font-semibold rounded mb-2">Follow Up Check Up</span>
                                                            <p class="font-semibold text-slate-900"><?php echo htmlspecialchars($followup['purpose'] ?? 'Follow-up Consultation'); ?></p>
                                                            <p class="text-sm text-slate-600 mt-1">
                                                                <i class="fas fa-calendar-alt mr-2"></i>
                                                                <?php echo date('M d, Y', strtotime($followup['appointment_date'])); ?> @ 
                                                                <?php echo htmlspecialchars($followup['appointment_time']); ?>
                                                            </p>
                                                        </div>
                                                        <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap bg-blue-100 text-blue-800">
                                                            <i class="fas fa-circle text-xs"></i> Scheduled
                                                        </span>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center py-8">
                                            <i class="fas fa-check-circle text-4xl text-blue-200 mb-3 block"></i>
                                            <p class="text-blue-800">No follow-up check-ups scheduled for this patient.</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Appointment Details Card -->
                                <div class="bg-indigo-50 border border-indigo-200 rounded-xl p-8">
                                    <div class="flex items-center justify-between mb-6">
                                        <h3 class="text-lg font-heading font-bold text-indigo-900 flex items-center gap-2">
                                            <i class="fas fa-calendar-check text-indigo-600"></i> Appointment Details
                                        </h3>
                                        <?php if (!empty($patient_data['appointments']) && count($patient_data['appointments']) > 0): ?>
                                            <button type="button" id="clearAppointmentDetailsBtn_<?php echo $patient_id; ?>" onclick="clearAppointmentDetails(<?php echo $patient_id; ?>, event)" class="px-3 py-1 bg-red-100 text-red-700 text-xs font-semibold rounded-lg hover:bg-red-200 transition-colors duration-200 flex items-center gap-1">
                                                <i class="fas fa-trash-alt"></i> Clear All
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if (!empty($patient_data['appointments']) && count($patient_data['appointments']) > 0): ?>
                                        <div class="space-y-4 max-h-96 overflow-y-auto" id="appointmentsList_<?php echo $patient_id; ?>">
                                            <?php foreach ($patient_data['appointments'] as $apt): ?>
                                                <div class="bg-white border-l-4 border-indigo-500 rounded-lg p-4">
                                                    <div class="flex items-start justify-between mb-3">
                                                        <div>
                                                            <h4 class="font-semibold text-slate-900"><?php echo htmlspecialchars($apt['purpose'] ?? 'General Appointment'); ?></h4>
                                                            <p class="text-sm text-slate-600 mt-1">
                                                                <i class="fas fa-calendar-alt mr-2"></i>
                                                                <?php echo date('M d, Y', strtotime($apt['appointment_date'])); ?> @ 
                                                                <?php echo htmlspecialchars($apt['appointment_time']); ?>
                                                            </p>
                                                        </div>
                                                        <span class="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap
                                                            <?php 
                                                            $status = strtolower($apt['status'] ?? '');
                                                            if ($status === 'approved' || $status === 'completed') {
                                                                echo 'bg-emerald-100 text-emerald-800';
                                                            } elseif ($status === 'pending' || $status === 'scheduled') {
                                                                echo 'bg-amber-100 text-amber-800';
                                                            } else {
                                                                echo 'bg-slate-100 text-slate-800';
                                                            }
                                                            ?>
                                                        ">
                                                            <?php echo htmlspecialchars(ucfirst($status)); ?>
                                                        </span>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center py-8">
                                            <i class="fas fa-calendar-times text-4xl text-blue-200 mb-3 block"></i>
                                            <p class="text-blue-800">No appointment records found for this patient.</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Action Buttons -->
                                <div class="flex flex-col sm:flex-row gap-4">
                                    <a href="?module=identify-patient" class="rounded-lg bg-[#3D4A1E] px-6 py-3 text-sm font-semibold text-white transition-all hover:bg-[#303a18] inline-flex items-center justify-center gap-2">
                                        <i class="fas fa-arrow-left"></i> Back to Identify Patient
                                    </a>
                                    <a href="?module=consultation" class="rounded-lg bg-[#3D4A1E] px-6 py-3 text-sm font-semibold text-white transition-all hover:bg-[#303a18] inline-flex items-center justify-center gap-2">
                                        <i class="fas fa-stethoscope"></i> Record Consultation
                                    </a>
                                </div>
                            </div>
                        <?php else: ?>
                            <!-- NO PATIENT LOADED - Show Placeholder -->
                            <div class="border-2 border-dashed border-slate-300 rounded-xl p-12 text-center bg-slate-50">
                                <div class="w-16 h-16 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <i class="fas fa-user-circle text-4xl text-slate-400"></i>
                                </div>
                                <h3 class="text-lg font-heading font-semibold text-slate-700 mb-2">Load Patient Profile</h3>
                                <p class="text-slate-600 max-w-md mx-auto mb-6">
                                    Identify a patient using the <strong>QR Scanner</strong> or <strong>Manual Entry</strong> to view their complete profile, medical history, and appointment details.
                                </p>
                                <a href="?module=identify-patient" class="rounded-lg bg-[#3D4A1E] px-6 py-2 text-sm font-semibold text-white transition-all hover:bg-[#303a18] inline-flex items-center gap-2">
                                    <i class="fas fa-arrow-left"></i> Back to Identify Patient
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <!-- ============================================================
                         MODULE: CONSULTATION LOG & MEDICINE DISPENSING
                         ============================================================ -->
                    <?php if (isModuleActive('consultation')): ?>
                    <div>
                        <h2 class="text-2xl font-heading font-bold text-slate-900 mb-6">Record Consultation</h2>
                        
                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            <!-- Consultation Form -->
                            <div class="lg:col-span-2">
                                <div class="bg-white border border-slate-200 rounded-xl p-6">
                                    <h3 class="text-lg font-heading font-bold text-slate-900 mb-6 flex items-center gap-2">
                                        <i class="fas fa-stethoscope text-[#454B1B]"></i> Consultation Notes & Diagnosis
                                    </h3>

                                    <form id="consultationForm" onsubmit="handleConsultationSubmit(event)" class="space-y-6">
                                        <!-- DYNAMIC APPROVED PATIENT DROPDOWN -->
                                        <div>
                                            <label class="block text-sm font-semibold text-slate-700 mb-2">
                                                Select Approved Patient <span class="text-red-500">*</span>
                                            </label>
                                            <select id="patientDropdown" onchange="handlePatientSelection()" 
                                                    class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent" 
                                                    required>
                                                <option value="">-- Choose an approved patient --</option>
                                                <?php foreach ($approved_patients as $patient): ?>
                                                <option value="<?php echo $patient['appointment_id']; ?>" 
                                                        data-resident-id="<?php echo $patient['resident_id']; ?>"
                                                        data-patient-name="<?php echo htmlspecialchars($patient['patient_name']); ?>"
                                                        data-dob="<?php echo $patient['date_of_birth']; ?>"
                                                        data-sex="<?php echo $patient['sex']; ?>"
                                                        data-contact="<?php echo htmlspecialchars($patient['contact_number']); ?>"
                                                        data-email="<?php echo htmlspecialchars($patient['email']); ?>"
                                                        data-appointment-date="<?php echo $patient['appointment_date']; ?>"
                                                        data-appointment-time="<?php echo $patient['appointment_time']; ?>"
                                                        data-purpose="<?php echo htmlspecialchars($patient['purpose']); ?>">
                                                    <?php echo htmlspecialchars($patient['patient_name']) . ' (' . date('M d, Y h:i A', strtotime($patient['appointment_date'] . ' ' . $patient['appointment_time'])) . ')'; ?>
                                                </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>

                                        <!-- PATIENT DETAILS (Auto-filled) -->
                                        <div id="patientDetailsPanel" class="bg-slate-50 border border-slate-200 rounded-lg p-4" style="display: none;">
                                            <h3 class="font-semibold text-slate-900 mb-3">Patient Information</h3>
                                            <div class="grid grid-cols-2 gap-4 text-sm">
                                                <div>
                                                    <p class="text-slate-600 font-medium">Full Name</p>
                                                    <p id="patientName" class="text-slate-900 font-semibold"></p>
                                                </div>
                                                <div>
                                                    <p class="text-slate-600 font-medium">Date of Birth</p>
                                                    <p id="patientDOB" class="text-slate-900 font-semibold"></p>
                                                </div>
                                                <div>
                                                    <p class="text-slate-600 font-medium">Sex</p>
                                                    <p id="patientSex" class="text-slate-900 font-semibold"></p>
                                                </div>
                                                <div>
                                                    <p class="text-slate-600 font-medium">Contact</p>
                                                    <p id="patientContact" class="text-slate-900 font-semibold"></p>
                                                </div>
                                            </div>
                                        </div>

                                        <div>
                                            <label class="block text-sm font-semibold text-slate-700 mb-2">Diagnosis <span class="text-red-500">*</span></label>
                                            <textarea id="diagnosisField"
                                                placeholder="Enter clinical findings and diagnosis..." 
                                                rows="4"
                                                class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent resize-none disabled:bg-slate-100 disabled:cursor-not-allowed"
                                                disabled
                                                required></textarea>
                                            <p class="text-xs text-slate-500 mt-1">Include symptoms, examination findings, and diagnostic conclusion</p>
                                        </div>

                                        <div>
                                            <label class="block text-sm font-semibold text-slate-700 mb-2">Treatment Plan <span class="text-red-500">*</span></label>
                                            <textarea id="treatmentField"
                                                placeholder="Prescribed treatment and medication..." 
                                                rows="4"
                                                class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent resize-none disabled:bg-slate-100 disabled:cursor-not-allowed"
                                                disabled
                                                required></textarea>
                                            <p class="text-xs text-slate-500 mt-1">Include medications, dosages, frequency, and duration</p>
                                        </div>

                                        <div>
                                            <label class="block text-sm font-semibold text-slate-700 mb-2">Clinical Notes</label>
                                            <textarea id="notesField"
                                                placeholder="Additional observations or follow-up instructions..." 
                                                rows="3"
                                                class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent resize-none disabled:bg-slate-100 disabled:cursor-not-allowed"
                                                disabled></textarea>
                                        </div>

                                        <div class="border-t border-slate-200 pt-6">
                                            <button type="submit" id="consultationSubmitBtn" class="w-full rounded-lg bg-[#3D4A1E] px-6 py-3 font-semibold text-white transition-all hover:bg-[#303a18] disabled:cursor-not-allowed disabled:opacity-50">
                                                <i class="fas fa-save mr-2"></i> Save Consultation Record
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <!-- Medicine Dispensing Panel -->
                            <div class="lg:col-span-1">
                                <div class="bg-emerald-50 border border-emerald-200 rounded-xl p-6">
                                    <h3 class="text-lg font-heading font-bold text-emerald-900 mb-6 flex items-center gap-2">
                                        <i class="fas fa-pills text-emerald-600"></i> Dispense Free Medicine
                                    </h3>

                                    <div class="space-y-4">
                                        <div>
                                            <label class="block text-sm font-semibold text-emerald-900 mb-2">Select Medicine</label>
                                            <select class="w-full px-4 py-2 border border-emerald-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500">
                                                <option value="">-- Choose Medicine --</option>
                                                <option value="paracetamol">Paracetamol 500mg</option>
                                                <option value="amoxicillin">Amoxicillin 500mg</option>
                                                <option value="ibuprofen">Ibuprofen 400mg</option>
                                            </select>
                                        </div>

                                        <div>
                                            <label class="block text-sm font-semibold text-emerald-900 mb-2">Quantity</label>
                                            <input type="number" min="1" max="100" value="1" class="w-full px-4 py-2 border border-emerald-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500">
                                        </div>

                                        <button onclick="dispenseMedicine()" class="w-full rounded-lg bg-[#3D4A1E] px-4 py-2 text-sm font-semibold text-white transition-all hover:bg-[#303a18]">
                                            <i class="fas fa-plus mr-2"></i> Add to Dispensing
                                        </button>

                                        <div class="border-t border-emerald-200 pt-4 mt-4">
                                            <p class="text-xs font-bold text-emerald-700 uppercase tracking-wider mb-3">Medicines to Dispense</p>
                                            <div class="space-y-2">
                                                <div class="flex items-center justify-between bg-white p-3 rounded-lg border border-emerald-200">
                                                    <span class="text-sm font-medium text-emerald-900">Paracetamol 500mg × 10</span>
                                                    <button onclick="this.parentElement.remove()" class="text-emerald-600 hover:text-emerald-800">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- ============================================================
                         MODULE: MEDICINE INVENTORY MANAGEMENT
                         ============================================================ -->
                    <?php if (isModuleActive('inventory')): ?>
                    <div>
                        <h2 class="text-2xl font-heading font-bold text-slate-900 mb-6">Medicine Inventory Management</h2>
                        
                        <div class="bg-white border border-slate-200 rounded-xl overflow-hidden">
                            <div class="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
                                <div>
                                    <h3 class="font-heading font-bold text-slate-900 flex items-center gap-2">
                                        <i class="fas fa-flask-vial text-[#454B1B]"></i> Available Medicines
                                    </h3>
                                    <p class="text-sm text-slate-600 mt-1">Track inventory and dispensing history</p>
                                </div>
                                <button onclick="showAddMedicineForm()" class="rounded-lg bg-[#3D4A1E] px-4 py-2 text-sm font-semibold text-white transition-all hover:bg-[#303a18]">
                                    <i class="fas fa-plus mr-2"></i> Add Medicine
                                </button>
                            </div>

                            <div class="overflow-x-auto">
                                <table class="w-full text-sm">
                                    <thead class="bg-slate-50 border-b border-slate-200">
                                        <tr>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Medicine Name</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Dosage</th>
                                            <th class="px-6 py-3 text-center font-semibold text-slate-700">Total Stock</th>
                                            <th class="px-6 py-3 text-center font-semibold text-slate-700">Available</th>
                                            <th class="px-6 py-3 text-center font-semibold text-slate-700">Dispensed</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Status</th>
                                            <th class="px-6 py-3 text-center font-semibold text-slate-700">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-200">
                                        <?php if (empty($medicine_list)): ?>
                                        <tr class="hover:bg-slate-50 transition-colors">
                                            <td colspan="7" class="px-6 py-12 text-center text-slate-500">
                                                <i class="fas fa-inbox text-4xl text-slate-300 mb-3 block"></i>
                                                No medicines in inventory
                                            </td>
                                        </tr>
                                        <?php else: ?>
                                        <?php foreach ($medicine_list as $medicine): ?>
                                        <tr class="hover:bg-slate-50 transition-colors" data-medicine-id="<?php echo $medicine['medicine_id']; ?>">
                                            <td class="px-6 py-4 font-medium text-slate-900"><?php echo htmlspecialchars($medicine['name']); ?></td>
                                            <td class="px-6 py-4 text-slate-600 font-medium"><?php echo htmlspecialchars($medicine['dosage']); ?></td>
                                            <td class="px-6 py-4 text-center"><span class="font-bold text-slate-900"><?php echo intval($medicine['stock_quantity']); ?></span></td>
                                            <td class="px-6 py-4 text-center"><span class="font-bold text-emerald-600"><?php echo intval($medicine['available']); ?></span></td>
                                            <td class="px-6 py-4 text-center"><span class="text-slate-600 font-medium"><?php echo intval($medicine['dispensed']); ?></span></td>
                                            <td class="px-6 py-4">
                                                <?php 
                                                $status_class = 'text-slate-700 bg-slate-100';
                                                $status_text = 'Out of Stock';
                                                $status_value = strtolower($medicine['status']);
                                                
                                                if ($status_value === 'available') {
                                                    $status_class = 'text-green-700 bg-green-50';
                                                    $status_text = 'Available';
                                                } elseif ($status_value === 'low stock') {
                                                    $status_class = 'text-orange-700 bg-orange-50';
                                                    $status_text = 'Low Stock';
                                                } elseif ($status_value === 'out of stock') {
                                                    $status_class = 'text-slate-700 bg-slate-100';
                                                    $status_text = 'Out of Stock';
                                                }
                                                ?>
                                                <span class="inline-flex items-center gap-1 px-2 py-1 <?php echo $status_class; ?> text-xs font-bold rounded-full">
                                                    <span class="w-1.5 h-1.5 rounded-full <?php echo str_replace('text-', 'bg-', str_replace(' ', ' bg-', substr($status_class, 5))); ?>"></span> <?php echo htmlspecialchars($medicine['status']); ?>
                                                </span>
                                            </td>
                                            <td class="px-6 py-4 text-center">
                                                <button onclick="editMedicine(this)" class="text-[#454B1B] hover:opacity-70 text-sm font-semibold">Edit</button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="px-6 py-4 bg-slate-50 border-t border-slate-200 text-sm text-slate-600">
                                <strong>Note:</strong> Inventory data is loaded from the database. Click "Edit" to update stock quantities.
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- ============================================================
                         MODULE: APPOINTMENT MANAGEMENT
                         ============================================================ -->
                    <?php if (isModuleActive('appointments')): ?>
                    <div>
                        <h2 class="text-2xl font-heading font-bold text-slate-900 mb-6">Manage Appointment Schedule</h2>
                        
                        <!-- Appointments Sub-Tab Navigation -->
                        <div class="flex items-center gap-1 border-b border-slate-200 px-6 py-3 overflow-x-auto bg-white mb-4 rounded-t-xl">
                            <a href="?module=appointments&sub=today" class="tab-button <?php echo (($_GET['sub'] ?? 'today') === 'today') ? 'active' : ''; ?>" style="font-size: 0.875rem;">
                                <i class="fas fa-calendar-check mr-1"></i>Today's Queue
                            </a>
                            <a href="?module=appointments&sub=followup" class="tab-button <?php echo (($_GET['sub'] ?? 'today') === 'followup') ? 'active' : ''; ?>" style="font-size: 0.875rem;">
                                <i class="fas fa-stethoscope mr-1"></i>Follow-up Check-up
                            </a>
                            <a href="?module=appointments&sub=history" class="tab-button <?php echo (($_GET['sub'] ?? 'today') === 'history') ? 'active' : ''; ?>" style="font-size: 0.875rem;">
                                <i class="fas fa-history mr-1"></i>Appointment History
                            </a>
                        </div>

                        <!-- TODAY'S QUEUE TAB -->
                        <?php if (!isset($_GET['sub']) || $_GET['sub'] === 'today'): ?>
                        <div class="bg-white border border-slate-200 rounded-xl overflow-hidden">
                            <div class="px-6 py-4 border-b border-slate-200">
                                <h3 class="font-heading font-bold text-slate-900 flex items-center gap-2 mb-4">
                                    <i class="fas fa-calendar-check text-[#454B1B]"></i> Upcoming Appointments Queue
                                </h3>
                            </div>

                            <div class="overflow-x-auto">
                                <table class="w-full text-sm">
                                    <thead class="bg-slate-50 border-b border-slate-200">
                                        <tr>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Resident Name</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Date</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Time</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Purpose</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Status</th>
                                            <th class="px-6 py-3 text-center font-semibold text-slate-700">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-200">
                                   <?php 
                                        // Show ALL upcoming appointments (today and future), sorted by date
                                        // These are appointments waiting for BHW processing or already approved
                                        $today_apts = array_filter($upcoming_appointments, function($apt) {
                                            $status = strtolower($apt['status']);
                                            return in_array($status, ['scheduled', 'pending', 'approved']);
                                        });
                                        // Sort by appointment date and time
                                        usort($today_apts, function($a, $b) {
                                            $cmp = strtotime($a['appointment_date']) - strtotime($b['appointment_date']);
                                            if ($cmp === 0) {
                                                return strtotime($a['appointment_time']) - strtotime($b['appointment_time']);
                                            }
                                            return $cmp;
                                        });
                                        if (empty($today_apts)): 
                                        ?>
                                        <tr class="hover:bg-slate-50 transition-colors">
                                            <td colspan="6" class="px-6 py-12 text-center">
                                                <div class="flex flex-col items-center gap-3">
                                                    <i class="fas fa-inbox text-4xl text-slate-300"></i>
                                                    <p class="text-slate-600 font-medium">No upcoming appointments in the queue</p>
                                                    <p class="text-xs text-slate-500">Patients waiting to be processed will appear here</p>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php else: ?>
                                        <?php foreach ($today_apts as $apt): ?>
                                        <tr class="hover:bg-slate-50 transition-colors">
                                            <td class="px-6 py-4 font-medium text-slate-900"><?php echo htmlspecialchars($apt['resident_name'] ?? 'Unknown'); ?></td>
                                            <td class="px-6 py-4 text-slate-600"><?php echo date('M d, Y', strtotime($apt['appointment_date'])); ?></td>
                                            <td class="px-6 py-4 text-slate-600"><?php echo htmlspecialchars($apt['appointment_time'] ?? 'N/A'); ?></td>
                                            <td class="px-6 py-4 text-slate-600"><?php echo htmlspecialchars($apt['purpose'] ?? 'General Consultation'); ?></td>
                                            <td class="px-6 py-4">
                                                <?php 
                                                $status = strtolower($apt['status']);
                                                if ($status === 'scheduled') {
                                                    echo '<span class="inline-flex items-center gap-1 px-2 py-1 bg-blue-50 rounded-full text-xs font-bold text-blue-700"><span class="w-1.5 h-1.5 rounded-full bg-blue-500"></span> Scheduled</span>';
                                                } elseif ($status === 'pending') {
                                                    echo '<span class="inline-flex items-center gap-1 px-2 py-1 bg-yellow-50 rounded-full text-xs font-bold text-yellow-700"><span class="w-1.5 h-1.5 rounded-full bg-yellow-500"></span> Pending</span>';
                                                } elseif ($status === 'approved') {
                                                    echo '<span class="inline-flex items-center gap-1 px-2 py-1 bg-purple-50 rounded-full text-xs font-bold text-purple-700"><span class="w-1.5 h-1.5 rounded-full bg-purple-500"></span> Approved</span>';
                                                }
                                                ?>
                                            </td>
                                            <td class="px-6 py-4 text-center">
                                                <?php 
                                                $apt_id = intval($apt['appointment_id'] ?? 0);
                                                $res_id = intval($apt['resident_id'] ?? 0);
                                                ?>
                                                <button onclick="changeAppointmentStatus(this, 'rendered', <?php echo $apt_id; ?>)" data-appointment-id="<?php echo $apt_id; ?>" data-resident-id="<?php echo $res_id; ?>" class="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-3 py-1.5 rounded text-xs font-medium transition-all" title="Mark as Rendered">
                                                    <i class="fas fa-check"></i> Rendered
                                                </button>
                                                <button onclick="changeAppointmentStatus(this, 'no-show', <?php echo $apt_id; ?>)" class="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-3 py-1.5 rounded text-xs font-medium transition-all ml-1" title="Mark as No Show">
                                                    <i class="fas fa-times"></i> No Show
                                                </button>
                                                <button onclick="showFollowupScheduleModal(<?php echo $res_id; ?>, '<?php echo htmlspecialchars($apt['resident_name']); ?>', <?php echo $apt_id; ?>)" class="bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-slate-900 px-3 py-1.5 rounded text-xs font-medium transition-all ml-1" title="Schedule Follow-up">
                                                    <i class="fas fa-plus"></i> Follow-up
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- FOLLOW-UP CHECK-UP TAB -->
                        <?php if (isset($_GET['sub']) && $_GET['sub'] === 'followup'): ?>
                        <div class="bg-white border border-slate-200 rounded-xl overflow-hidden">
                            <div class="px-6 py-4 border-b border-slate-200">
                                <h3 class="font-heading font-bold text-slate-900 flex items-center gap-2 mb-4">
                                    <i class="fas fa-stethoscope text-[#454B1B]"></i> Flagged Patients for Follow-up Check-up
                                </h3>
                            </div>

                            <div class="overflow-x-auto">
                                <table class="w-full text-sm">
                                    <thead class="bg-slate-50 border-b border-slate-200">
                                        <tr>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Resident Name</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Last Visit Date</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Schedule Follow-up Date</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Schedule Follow-up Time</th>
                                            <th class="px-6 py-3 text-center font-semibold text-slate-700">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-200">
                                        <?php 
                                        $today = date('Y-m-d');
                                        $followup_apts = array_filter($upcoming_appointments, function($apt) use ($today) {
                                            $apt_date = date('Y-m-d', strtotime($apt['appointment_date']));
                                            $status = strtolower($apt['status']);
                                            // Follow-up Check-up: ONLY show appointments explicitly flagged for follow-up (status='flagged')
                                            // These are patients the BHW clicked the yellow 'Follow-up Check-up' button for
                                            return $status === 'flagged';
                                        });
                                        if (empty($followup_apts)): 
                                        ?>
                                        <tr class="hover:bg-slate-50 transition-colors">
                                            <td colspan="5" class="px-6 py-12 text-center">
                                                <div class="flex flex-col items-center gap-3">
                                                    <i class="fas fa-calendar-times text-4xl text-slate-300"></i>
                                                    <p class="text-slate-600 font-medium">No follow-up appointments flagged</p>
                                                    <p class="text-xs text-slate-500">Use the yellow "Follow-up Check-up" button in Today's Queue to schedule returns</p>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php else: ?>
                                        <?php foreach ($followup_apts as $apt): ?>
                                        <tr class="hover:bg-slate-50 transition-colors">
                                            <td class="px-6 py-4 font-medium text-slate-900"><?php echo htmlspecialchars($apt['resident_name'] ?? 'Unknown'); ?></td>
                                            <td class="px-6 py-4 text-slate-600"><?php echo date('M d, Y', strtotime($apt['appointment_date'])); ?></td>
                                            <td class="px-6 py-4">
                                                <input type="date" class="px-2 py-1 border border-slate-300 rounded text-xs" value="<?php echo date('Y-m-d', strtotime($apt['appointment_date'] . ' +7 days')); ?>" onchange="updateFollowupDate(<?php echo $apt['appointment_id']; ?>, this.value)">
                                            </td>
                                            <td class="px-6 py-4">
                                                <select class="px-2 py-1 border border-slate-300 rounded text-xs" onchange="updateFollowupTime(<?php echo $apt['appointment_id']; ?>, this.value)">
                                                    <option value="09:00">9:00 AM</option>
                                                    <option value="10:00">10:00 AM</option>
                                                    <option value="11:00">11:00 AM</option>
                                                    <option value="14:00">2:00 PM</option>
                                                    <option value="15:00">3:00 PM</option>
                                                    <option value="16:00">4:00 PM</option>
                                                </select>
                                            </td>
                                            <td class="px-6 py-4 text-center">
                                                <?php 
                                                $apt_id = intval($apt['appointment_id'] ?? 0);
                                                $res_id = intval($apt['resident_id'] ?? 0);
                                                ?>
                                                <button onclick="changeAppointmentStatus(this, 'rendered', <?php echo $apt_id; ?>)" data-appointment-id="<?php echo $apt_id; ?>" data-resident-id="<?php echo $res_id; ?>" class="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-3 py-1.5 rounded text-xs font-medium transition-all" title="Mark as Rendered">
                                                    <i class="fas fa-check"></i> Rendered
                                                </button>
                                                <button onclick="changeAppointmentStatus(this, 'no-show', <?php echo $apt_id; ?>)" data-appointment-id="<?php echo $apt_id; ?>" data-resident-id="<?php echo $res_id; ?>" class="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-3 py-1.5 rounded text-xs font-medium transition-all ml-1" title="Mark as No Show">
                                                    <i class="fas fa-times"></i> No Show
                                                </button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- APPOINTMENT HISTORY TAB -->
                        <?php if (isset($_GET['sub']) && $_GET['sub'] === 'history'): ?>
                        <div class="bg-white border border-slate-200 rounded-xl overflow-hidden">
                            <div class="px-6 py-4 border-b border-slate-200">
                                <h3 class="font-heading font-bold text-slate-900 flex items-center gap-2 mb-4">
                                    <i class="fas fa-history text-[#454B1B]"></i> Appointment History (Completed Records)
                                </h3>
                            </div>

                            <div class="overflow-x-auto">
                                <table class="w-full text-sm">
                                    <thead class="bg-slate-50 border-b border-slate-200">
                                        <tr>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Resident Name</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Date</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Time</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Purpose</th>
                                            <th class="px-6 py-3 text-left font-semibold text-slate-700">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-200">
                                        <?php 
                                        // Appointment History: Show completed and no-show appointments (finalized records)
                                        // This includes appointments the BHW already processed
                                        $history_apts = array_filter($upcoming_appointments, function($apt) {
                                            $status = strtolower($apt['status']);
                                            return in_array($status, ['completed', 'no_show']);
                                        });
                                        usort($history_apts, function($a, $b) {
                                            return strtotime($b['appointment_date']) - strtotime($a['appointment_date']);
                                        });
                                        if (empty($history_apts)): 
                                        ?>
                                        <tr class="hover:bg-slate-50 transition-colors">
                                            <td colspan="5" class="px-6 py-12 text-center">
                                                <div class="flex flex-col items-center gap-3">
                                                    <i class="fas fa-archive text-4xl text-slate-300"></i>
                                                    <p class="text-slate-600 font-medium">No completed appointments yet</p>
                                                    <p class="text-xs text-slate-500">Historical records will appear here after appointments are marked as rendered</p>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php else: ?>
                                        <?php foreach ($history_apts as $apt): ?>
                                        <tr class="hover:bg-slate-50 transition-colors">
                                            <td class="px-6 py-4 font-medium text-slate-900"><?php echo htmlspecialchars($apt['resident_name'] ?? 'Unknown'); ?></td>
                                            <td class="px-6 py-4 text-slate-600"><?php echo date('M d, Y', strtotime($apt['appointment_date'])); ?></td>
                                            <td class="px-6 py-4 text-slate-600"><?php echo htmlspecialchars($apt['appointment_time'] ?? 'N/A'); ?></td>
                                            <td class="px-6 py-4 text-slate-600"><?php echo htmlspecialchars($apt['purpose'] ?? 'Consultation'); ?></td>
                                            <td class="px-6 py-4">
                                                <?php 
                                                $status = strtolower($apt['status'] ?? '');
                                                if ($status === 'completed') {
                                                    echo '<span class="inline-flex items-center gap-1 px-2 py-1 bg-green-50 rounded-full text-xs font-bold text-green-700"><span class="w-1.5 h-1.5 rounded-full bg-green-500"></span> Rendered</span>';
                                                } elseif ($status === 'no_show') {
                                                    echo '<span class="inline-flex items-center gap-1 px-2 py-1 bg-red-50 rounded-full text-xs font-bold text-red-700"><span class="w-1.5 h-1.5 rounded-full bg-red-500"></span> No Show</span>';
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php endif; ?>

                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- ============================================================
                         MODULE: SURVEILLANCE MANAGEMENT
                         ============================================================ -->
                    <?php if (isModuleActive('surveillance')): ?>
                    <div>
                        <h2 class="text-2xl font-heading font-bold text-slate-900 mb-6">Surveillance Management</h2>
                        <p class="text-sm text-slate-600 mb-8">Update the Barangay health surveillance metrics and publish a live resident preview within the BHW dashboard.</p>

                        <div class="space-y-6">
                            <div class="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm dark:bg-slate-800 dark:border-slate-700">
                                <div class="flex items-center justify-between mb-6">
                                    <div>
                                        <h3 class="text-lg font-heading font-bold text-slate-900">BHW Metrics Editor</h3>
                                        <p class="text-sm text-slate-500">Enter the latest surveillance figures and community observations.</p>
                                    </div>
                                </div>

                                <form id="surveillanceMetricsForm" method="POST" class="grid grid-cols-1 md:grid-cols-6 gap-4 items-end" onsubmit="handleSurveillanceSubmit(event)" novalidate>
                                    <input type="hidden" name="action" value="save_surveillance_metrics" />
                                    <div class="md:col-span-2"><label for="input_disease_name" class="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-600 dark:text-slate-300">Target Disease Name</label><input id="input_disease_name" name="disease_name" type="text" placeholder="Dengue" class="w-full rounded-lg border border-slate-300 px-3 py-3 text-sm dark:border-slate-600 dark:bg-slate-900 dark:text-white"></div>
                                    <div><label for="input_quantity_count" class="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-600 dark:text-slate-300">Quantity / Cases</label><input id="input_quantity_count" name="case_count" type="number" min="0" placeholder="0" required class="w-full rounded-lg border border-slate-300 px-3 py-3 text-sm dark:border-slate-600 dark:bg-slate-900 dark:text-white"></div>
                                    <div><label for="reportingPeriod" class="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-600 dark:text-slate-300">Reporting Period</label><input id="reportingPeriod" name="reporting_period" type="text" placeholder="Current 4 Weeks" class="w-full rounded-lg border border-slate-300 px-3 py-3 text-sm dark:border-slate-600 dark:bg-slate-900 dark:text-white"></div>
                                    <div><label for="input_trend_status" class="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-600 dark:text-slate-300">Trend Status</label><select id="input_trend_status" name="trend_status" class="w-full rounded-lg border border-slate-300 px-3 py-3 text-sm dark:border-slate-600 dark:bg-slate-900 dark:text-white"><option>Baseline</option><option>Increasing</option><option>Decreasing</option><option>Alert Phase</option></select></div>
                                    <div class="md:col-span-3"><label for="input_disease_meta" class="mb-2 block text-xs font-semibold uppercase tracking-wide text-slate-600 dark:text-slate-300">Surveillance Metadata / Notes</label><input id="input_disease_meta" name="meta_notes" type="text" placeholder="Add a short community observation" class="w-full rounded-lg border border-slate-300 px-3 py-3 text-sm dark:border-slate-600 dark:bg-slate-900 dark:text-white"></div>
                                    <div class="md:col-span-2"><button id="saveSurveillanceBtn" name="publish_updates" type="submit" class="w-full rounded-lg bg-[#3D4A1E] px-6 py-3 font-semibold text-white transition-all hover:bg-[#303a18] disabled:cursor-not-allowed disabled:opacity-60"><i class="fas fa-upload mr-2"></i> Save Updates</button></div>
                                    <div id="survSaveMessage" class="hidden self-center text-sm font-semibold text-emerald-700 dark:text-emerald-300"><i class="fas fa-check-circle mr-1"></i> Metrics saved successfully</div>
                                </form>
                            </div>

                            <section class="rounded-2xl border border-[#3D4A1E]/20 bg-[#3D4A1E] p-6 text-white shadow-sm"><p class="text-xs font-semibold uppercase tracking-[0.2em] text-lime-200">Highest Incidence</p><div class="mt-2 flex flex-wrap items-end justify-between gap-3"><h3 id="highest-incidence-name" class="text-2xl font-heading font-bold"><?php echo htmlspecialchars($highest_surveillance_metric['disease_name'] ?? 'None', ENT_QUOTES, 'UTF-8'); ?></h3><p><span id="highest-incidence-count" class="text-4xl font-bold"><?php echo intval($highest_surveillance_metric['case_count'] ?? 0); ?></span> <span class="text-sm text-lime-100">total cases</span></p></div></section>

                            <div class="surveillance-preview-panel rounded-2xl border border-slate-200 bg-slate-50 p-6 shadow-sm dark:border-slate-700 dark:bg-slate-900"><div class="mb-5 flex flex-wrap items-end justify-between gap-2"><div><h3 class="text-lg font-heading font-bold text-slate-900 dark:text-white">Surveillance Preview</h3><p class="text-sm text-slate-600 dark:text-slate-400">All recorded disease entries.</p></div><p id="survReportingPeriod" class="text-sm text-slate-500 dark:text-slate-400">Reporting Period: Current 4 Weeks</p></div><div id="surveillanceRecordsList" class="grid grid-cols-1 gap-4 md:grid-cols-3"></div></div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- ============================================================
                         MODULE: SMS COMMUNICATIONS
                         ============================================================ -->
                    <?php if (isModuleActive('sms')): ?>
                    <div>
                        <h2 class="text-2xl font-heading font-bold text-slate-900 mb-6">Send SMS Reminders to Residents</h2>
                        
                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            <!-- SMS Composition Form -->
                            <div class="lg:col-span-2">
                                <div class="bg-white border border-slate-200 rounded-xl p-6">
                                    <h3 class="text-lg font-heading font-bold text-slate-900 mb-6 flex items-center gap-2">
                                        <i class="fas fa-sms text-[#454B1B]"></i> Compose Message
                                    </h3>

                                    <form id="smsForm" onsubmit="handleSMSSubmit(event)" class="space-y-6">
                                        <div>
                                            <label class="block text-sm font-semibold text-slate-700 mb-2">Recipient Type</label>
                                            <div class="space-y-2">
                                                <label class="flex items-center gap-2 cursor-pointer">
                                                    <input type="radio" name="recipient_type" value="all" checked onchange="toggleCustomNumbers()" class="w-4 h-4">
                                                    <span class="text-sm font-medium text-slate-700">All Residents</span>
                                                </label>
                                                <label class="flex items-center gap-2 cursor-pointer">
                                                    <input type="radio" name="recipient_type" value="appointment" onchange="toggleCustomNumbers()" class="w-4 h-4">
                                                    <span class="text-sm font-medium text-slate-700">Upcoming Appointment Reminders</span>
                                                </label>
                                                <label class="flex items-center gap-2 cursor-pointer">
                                                    <input type="radio" name="recipient_type" value="custom" onchange="toggleCustomNumbers()" class="w-4 h-4">
                                                    <span class="text-sm font-medium text-slate-700">Custom Contact List</span>
                                                </label>
                                            </div>
                                        </div>

                                        <div id="customNumbersSection" class="hidden">
                                            <label class="block text-sm font-semibold text-slate-700 mb-2">Phone Numbers <span class="text-red-500">*</span></label>
                                            <textarea 
                                                id="customNumbers"
                                                placeholder="Enter phone numbers separated by commas&#10;Example: +639927174709, 09123456789, 639123456789" 
                                                rows="3"
                                                class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent resize-none font-mono text-sm"></textarea>
                                            <p class="text-xs text-slate-500 mt-2">Comma-separated phone numbers (supports multiple formats)</p>
                                        </div>

                                        <div>
                                            <label class="block text-sm font-semibold text-slate-700 mb-2">Message Content <span class="text-red-500">*</span></label>
                                            <textarea 
                                                id="smsContent"
                                                placeholder="Type your SMS message (max 160 characters)..." 
                                                rows="4"
                                                maxlength="160"
                                                class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent resize-none font-mono text-sm"
                                                required
                                                oninput="updateCharCount()"></textarea>
                                            <div class="flex items-center justify-between mt-2">
                                                <p class="text-xs text-slate-500">Recommended for SMS delivery</p>
                                                <p class="text-xs font-semibold text-slate-700"><span id="charCount">0</span>/160 characters</p>
                                            </div>
                                        </div>

                                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                                            <p class="text-xs font-bold text-blue-700 uppercase tracking-wider mb-2">Message Preview</p>
                                            <p id="smsPreview" class="text-sm text-blue-900 font-medium">Your message will appear here...</p>
                                        </div>

                                        <div class="border-t border-slate-200 pt-6">
                                            <button type="submit" class="w-full rounded-lg bg-[#3D4A1E] px-6 py-3 font-semibold text-white transition-all hover:bg-[#303a18]">
                                                <i class="fas fa-paper-plane mr-2"></i> Send SMS Reminders
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <!-- SMS Templates & Stats -->
                            <div class="space-y-6">
                                <div class="bg-white border border-slate-200 rounded-xl p-6">
                                    <h3 class="text-lg font-heading font-bold text-slate-900 mb-4 flex items-center gap-2">
                                        <i class="fas fa-bookmark text-[#454B1B]"></i> Quick Templates
                                    </h3>
                                    <div class="space-y-2">
                                        <button onclick="insertTemplate('Your appointment is tomorrow at 9:00 AM. Please arrive 10 minutes early. ScanCare')" class="w-full text-left px-4 py-3 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors font-medium text-sm text-slate-900">
                                            <i class="fas fa-calendar-check text-[#454B1B] mr-2"></i> Appointment Reminder
                                        </button>
                                        <button onclick="insertTemplate('The Rural Health Unit will open tomorrow. Visit us for free checkup and vaccination services. ScanCare')" class="w-full text-left px-4 py-3 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors font-medium text-sm text-slate-900">
                                            <i class="fas fa-hospital text-[#454B1B] mr-2"></i> Clinic Announcement
                                        </button>
                                        <button onclick="insertTemplate('Follow-up medication reminder. Take as prescribed. For concerns, visit the RHU. ScanCare')" class="w-full text-left px-4 py-3 border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors font-medium text-sm text-slate-900">
                                            <i class="fas fa-pills text-[#454B1B] mr-2"></i> Medication Reminder
                                        </button>
                                    </div>
                                </div>

                                <div class="bg-emerald-50 border border-emerald-200 rounded-xl p-6">
                                    <h3 class="text-lg font-heading font-bold text-emerald-900 mb-4 flex items-center gap-2">
                                        <i class="fas fa-chart-bar text-emerald-600"></i> SMS Statistics
                                    </h3>
                                    <div class="space-y-3">
                                        <div class="flex items-center justify-between">
                                            <span class="text-sm text-emerald-800 font-medium">Sent Today</span>
                                            <span class="text-2xl font-bold text-emerald-700">0</span>
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <span class="text-sm text-emerald-800 font-medium">Pending</span>
                                            <span class="text-2xl font-bold text-emerald-700"><?php echo $pending_reminders; ?></span>
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <span class="text-sm text-emerald-800 font-medium">Failed</span>
                                            <span class="text-2xl font-bold text-emerald-700">0</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- ============================================================
                         MODULE: COMMUNITY ANNOUNCEMENTS
                         ============================================================ -->
                    <?php if (isModuleActive('announcements')): ?>
                    <div>
                        <h2 class="text-2xl font-heading font-bold text-slate-900 mb-2">Community Announcements</h2>
                        <p class="text-sm text-slate-600 mb-8">Create and manage health updates for residents to see on their dashboard.</p>

                        <?php if ($announcementStatus === 'published'): ?>
                            <div id="announcementStatusToast" class="mb-6 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-800">Announcement published and visible to residents.</div>
                        <?php elseif ($announcementStatus === 'missing'): ?>
                            <div class="mb-6 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-semibold text-amber-800">Title and message are required.</div>
                        <?php elseif ($announcementStatus === 'error'): ?>
                            <div class="mb-6 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-800">The announcement could not be published.</div>
                        <?php elseif ($announcementStatus === 'updated'): ?>
                            <div id="announcementStatusToast" class="mb-6 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-semibold text-emerald-800">Announcement updated successfully.</div>
                        <?php endif; ?>

                        <div class="mb-6 flex flex-wrap gap-2 border-b border-slate-200 pb-3">
                            <a href="?module=announcements&announcement_tab=create" data-announcement-tab-link data-announcement-primary-tab data-announcement-mode="create" class="rounded-lg px-4 py-2 text-sm font-semibold <?php echo $announcementTab === 'create' ? 'bg-[#3D4A1E] text-white' : 'text-slate-600 hover:bg-slate-100'; ?>">Create Announcement</a>
                            <a href="?module=announcements&announcement_tab=manage&announcement_state=<?php echo htmlspecialchars($announcementState); ?>" data-announcement-tab-link data-announcement-primary-tab data-announcement-mode="manage" class="rounded-lg px-4 py-2 text-sm font-semibold <?php echo $announcementTab === 'manage' ? 'bg-[#3D4A1E] text-white' : 'text-slate-600 hover:bg-slate-100'; ?>">Manage Announcement</a>
                        </div>

                        <div data-announcement-panel="create" <?php echo $announcementTab === 'create' ? '' : 'hidden'; ?>>
                            <div class="max-w-3xl rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                                <form method="POST" class="space-y-5">
                                    <input type="hidden" name="action" value="create_announcement">
                                    <div>
                                        <label for="announcementTitle" class="mb-2 block text-sm font-semibold text-slate-700">Title</label>
                                        <input id="announcementTitle" name="title" type="text" maxlength="150" required placeholder="Free blood pressure check-up" class="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-[#3D4A1E] focus:outline-none focus:ring-2 focus:ring-[#3D4A1E]/20">
                                    </div>
                                    <div>
                                        <label for="announcementCreatedDate" class="mb-2 block text-sm font-semibold text-slate-700">Date created</label>
                                        <input id="announcementCreatedDate" type="text" value="<?php echo date('M d, Y'); ?>" readonly class="w-full rounded-lg border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-500">
                                    </div>
                                    <div>
                                        <label for="announcementMessage" class="mb-2 block text-sm font-semibold text-slate-700">Body</label>
                                        <textarea id="announcementMessage" name="message" rows="5" required placeholder="Tell residents what is available and who can attend." class="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-[#3D4A1E] focus:outline-none focus:ring-2 focus:ring-[#3D4A1E]/20"></textarea>
                                    </div>
                                    <div class="grid grid-cols-1 gap-5 sm:grid-cols-2">
                                        <div>
                                            <label for="announcementState" class="mb-2 block text-sm font-semibold text-slate-700">State</label>
                                            <select id="announcementState" name="state" class="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-[#3D4A1E] focus:outline-none focus:ring-2 focus:ring-[#3D4A1E]/20">
                                                <option value="upcoming">Upcoming</option>
                                                <option value="now">Now</option>
                                                <option value="done">Done</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label for="announcementDate" class="mb-2 block text-sm font-semibold text-slate-700">Service date <span class="font-normal text-slate-400">(optional)</span></label>
                                            <input id="announcementDate" name="service_date" type="date" class="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-[#3D4A1E] focus:outline-none focus:ring-2 focus:ring-[#3D4A1E]/20">
                                        </div>
                                    </div>
                                    <div>
                                        <label for="announcementLocation" class="mb-2 block text-sm font-semibold text-slate-700">Location <span class="font-normal text-slate-400">(optional)</span></label>
                                        <input id="announcementLocation" name="location" type="text" maxlength="150" placeholder="RHU II - Gutad" class="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-[#3D4A1E] focus:outline-none focus:ring-2 focus:ring-[#3D4A1E]/20">
                                    </div>
                                    <button type="submit" class="rounded-lg bg-[#3D4A1E] px-5 py-3 font-semibold text-white transition hover:bg-[#303a18]"><i class="fas fa-bullhorn mr-2"></i> Create Announcement</button>
                                </form>
                            </div>
                        </div>

                        <div data-announcement-panel="manage" <?php echo $announcementTab === 'manage' ? '' : 'hidden'; ?>>
                            <div class="mb-5 flex flex-wrap gap-2">
                                <?php foreach (['upcoming' => 'Upcoming', 'now' => 'Now', 'done' => 'Done'] as $stateKey => $stateLabel): ?>
                                    <a href="?module=announcements&announcement_tab=manage&announcement_state=<?php echo $stateKey; ?>" data-announcement-tab-link data-announcement-mode="manage" data-announcement-state-tab="<?php echo $stateKey; ?>" class="rounded-full border px-4 py-2 text-sm font-semibold <?php echo $announcementState === $stateKey ? 'border-[#3D4A1E] bg-[#3D4A1E] text-white' : 'border-slate-200 bg-white text-slate-600 hover:border-[#3D4A1E]'; ?>"><?php echo $stateLabel; ?></a>
                                <?php endforeach; ?>
                            </div>
                            <div class="space-y-5">
                                <?php foreach ($managedAnnouncements as $announcement): ?>
                                        <form method="POST" data-announcement-item="<?php echo htmlspecialchars($announcement['state']); ?>" class="rounded-2xl border border-slate-200 bg-slate-50 p-6 shadow-sm" <?php echo $announcement['state'] === $announcementState ? '' : 'hidden'; ?> >
                                            <input type="hidden" name="action" value="update_announcement">
                                            <input type="hidden" name="announcement_id" value="<?php echo intval($announcement['announcement_id']); ?>">
                                            <div class="mb-5 flex flex-wrap items-center justify-between gap-3">
                                                <span class="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold uppercase tracking-wide text-slate-600"><?php echo htmlspecialchars($announcement['state']); ?></span>
                                                <span class="text-xs text-slate-400">Created <?php echo date('M d, Y', strtotime($announcement['created_at'])); ?></span>
                                            </div>
                                            <div class="grid gap-4 md:grid-cols-2">
                                                <div class="md:col-span-2">
                                                    <label class="mb-2 block text-sm font-semibold text-slate-700">Title</label>
                                                    <input name="title" type="text" maxlength="150" required value="<?php echo htmlspecialchars($announcement['title']); ?>" class="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-[#3D4A1E] focus:outline-none focus:ring-2 focus:ring-[#3D4A1E]/20">
                                                </div>
                                                <div class="md:col-span-2">
                                                    <label class="mb-2 block text-sm font-semibold text-slate-700">Body</label>
                                                    <textarea name="message" rows="4" required class="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-[#3D4A1E] focus:outline-none focus:ring-2 focus:ring-[#3D4A1E]/20"><?php echo htmlspecialchars($announcement['message']); ?></textarea>
                                                </div>
                                                <div>
                                                    <label class="mb-2 block text-sm font-semibold text-slate-700">State</label>
                                                    <select name="state" class="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-[#3D4A1E] focus:outline-none focus:ring-2 focus:ring-[#3D4A1E]/20">
                                                        <?php foreach (['upcoming' => 'Upcoming', 'now' => 'Now', 'done' => 'Done'] as $stateKey => $stateLabel): ?>
                                                            <option value="<?php echo $stateKey; ?>" <?php echo $announcement['state'] === $stateKey ? 'selected' : ''; ?>><?php echo $stateLabel; ?></option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </div>
                                                <div>
                                                    <label class="mb-2 block text-sm font-semibold text-slate-700">Service date</label>
                                                    <input name="service_date" type="date" value="<?php echo htmlspecialchars($announcement['service_date'] ?? ''); ?>" class="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-[#3D4A1E] focus:outline-none focus:ring-2 focus:ring-[#3D4A1E]/20">
                                                </div>
                                                <div class="md:col-span-2">
                                                    <label class="mb-2 block text-sm font-semibold text-slate-700">Location</label>
                                                    <input name="location" type="text" maxlength="150" value="<?php echo htmlspecialchars($announcement['location'] ?? ''); ?>" class="w-full rounded-lg border border-slate-300 px-4 py-3 text-sm focus:border-[#3D4A1E] focus:outline-none focus:ring-2 focus:ring-[#3D4A1E]/20">
                                                </div>
                                            </div>
                                            <button type="submit" class="mt-5 rounded-lg bg-[#3D4A1E] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#303a18]"><i class="fas fa-save mr-2"></i> Save Changes</button>
                                        </form>
                                <?php endforeach; ?>
                                <?php foreach (['upcoming', 'now', 'done'] as $emptyState): ?>
                                    <div data-announcement-empty="<?php echo $emptyState; ?>" class="rounded-2xl border border-dashed border-slate-300 bg-white p-10 text-center text-sm text-slate-500" <?php echo $emptyState === $announcementState && $announcementCounts[$emptyState] === 0 ? '' : 'hidden'; ?>>No <?php echo $emptyState; ?> announcements yet.</div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>
            </div>

        </div>
    </main>

    <!-- ========================================================================
         FOOTER
         ======================================================================== -->
    <footer class="dashboard-footer bg-slate-900 text-white py-12 border-t border-slate-800">
        <div class="max-w-7xl mx-auto px-6 lg:px-12">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
                <div><h3 class="font-heading font-bold text-lg mb-4">ScanCare</h3><p class="text-slate-400 text-sm">Healthcare made simple for Barangay Gutad</p></div>
                <div><h4 class="font-semibold mb-4">Services</h4><ul class="space-y-2 text-sm text-slate-400"><li><a href="appointments.php" class="hover:text-white transition">Appointments</a></li><li><a href="system-goals.php" class="hover:text-white transition">System Goals</a></li><li><a href="service-areas.php" class="hover:text-white transition">Service Areas</a></li></ul></div>
                <div><h4 class="font-semibold mb-4">Legal</h4><ul class="space-y-2 text-sm text-slate-400"><li><a href="compliance.php" class="hover:text-white transition">Compliance</a></li><li><a href="#" class="hover:text-white transition">Privacy Policy</a></li><li><a href="#" class="hover:text-white transition">Terms of Service</a></li></ul></div>
                <div><h4 class="font-semibold mb-4">Contact</h4><p class="text-slate-400 text-sm">Floridablanca RHU II - GUTAD<br>Email: floridablancarhu2@gmail.com<br>Contact: 0948 056 6872</p></div>
            </div>
            <div class="border-t border-slate-800 pt-8 text-center text-slate-400 text-sm"><p>&copy; 2026 ScanCare. All rights reserved. Your data is encrypted and secure.</p></div>
        </div>
    </footer>

    <!-- ========================================================================
         JAVASCRIPT HANDLERS
         ======================================================================== -->
    <script>
        // ====================================================================
        // SIDEBAR EXPAND/COLLAPSE ON HOVER
        // ====================================================================
        const sidebar = document.querySelector('.sidebar');
        const mainWithSidebar = document.querySelector('.main-with-sidebar');
        const dashboardFooter = document.querySelector('.dashboard-footer');

        if (sidebar && mainWithSidebar && window.matchMedia('(min-width: 1024px)').matches) {
            sidebar.addEventListener('mouseenter', function() {
                mainWithSidebar.style.width = 'calc(100% - 16rem)';
                mainWithSidebar.style.marginLeft = '16rem';
                if (dashboardFooter) {
                    dashboardFooter.style.width = 'calc(100% - 16rem)';
                    dashboardFooter.style.marginLeft = '16rem';
                }
            });

            sidebar.addEventListener('mouseleave', function() {
                mainWithSidebar.style.width = 'calc(100% - 5rem)';
                mainWithSidebar.style.marginLeft = '5rem';
                if (dashboardFooter) {
                    dashboardFooter.style.width = 'calc(100% - 5rem)';
                    dashboardFooter.style.marginLeft = '5rem';
                }
            });
        }

        // ====================================================================
        // QR SCANNER STATE MANAGEMENT
        // ====================================================================
        let html5QrcodeScanner = null;
        let isScannerActive = false;

        // ====================================================================
        // QR SCANNER INITIALIZATION - Start camera and begin scanning
        // ====================================================================
        async function initiateCameraCapture() {
            const container = document.getElementById('qrScannerContainer');
            container.classList.add('active');
            isScannerActive = true;
            document.body.style.overflow = 'hidden';
            updateScannerStatus('scanning', 'Requesting camera permission...');

            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                updateScannerStatus('error', 'Your browser does not support camera access. Use a modern browser.');
                return;
            }

            try {
                const testStream = await navigator.mediaDevices.getUserMedia({ video: true });
                testStream.getTracks().forEach(track => track.stop());
            } catch (err) {
                console.error('Camera permission error:', err);
                let message = 'Unable to access camera. Please check permissions.';
                if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
                    message = 'Camera permission denied. Allow access and try again.';
                } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
                    message = 'No camera found. Please connect a camera and retry.';
                } else if (!window.isSecureContext && !['localhost', '127.0.0.1'].includes(location.hostname)) {
                    message = 'Camera access requires HTTPS or localhost. Open this app on a secure origin.';
                }
                updateScannerStatus('error', message);
                return;
            }

            if (html5QrcodeScanner) {
                try {
                    await html5QrcodeScanner.clear();
                } catch (ignored) {}
                html5QrcodeScanner = null;
            }

            html5QrcodeScanner = new Html5Qrcode(
                "html5-qrcode",
                {
                    fps: 10,
                    qrbox: { width: 250, height: 250 },
                    supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA],
                    experimentalFeatures: { useBarCodeDetectorIfAvailable: true }
                }
            );

            Html5Qrcode.getCameras()
                .then(devices => {
                    if (!devices || devices.length === 0) {
                        updateScannerStatus('error', 'No camera found. Please check permissions.');
                        return;
                    }

                    let rearCamera = devices[0];
                    const rearCameraId = devices.find(device =>
                        device.label.toLowerCase().includes('back') ||
                        device.label.toLowerCase().includes('rear') ||
                        device.label.toLowerCase().includes('environment')
                    )?.id;

                    if (rearCameraId) {
                        rearCamera = devices.find(device => device.id === rearCameraId) || rearCamera;
                    }

                    updateScannerStatus('scanning', 'Point camera at QR code');

                    html5QrcodeScanner.start(
                        rearCamera.id,
                        {
                            fps: 10,
                            qrbox: { width: 250, height: 250 }
                        },
                        onQRCodeDetected,
                        onQRCodeError
                    ).catch(err => {
                        console.error('Camera start error:', err);
                        updateScannerStatus('error', 'Failed to start camera. Check permissions.');
                    });
                })
                .catch(err => {
                    console.error('Camera detection error:', err);
                    updateScannerStatus('error', 'Unable to access camera.');
                });
        }

        // ====================================================================
        // QR CODE DETECTION HANDLER - Called when QR code is successfully scanned
        // ====================================================================
        function onQRCodeDetected(decodedText, decodedResult) {
            // Verify the QR code contains a URL pointing to view_record.php
            if (decodedText.includes('view_record.php?id=') || decodedText.includes('view_record.php?code=')) {
                console.log('QR Code detected:', decodedText);
                updateScannerStatus('success', 'QR Code detected! Redirecting...');

                // Stop the scanner
                stopQRScanner();

                // Navigate to the URL encoded in the QR code
                setTimeout(() => {
                    window.location.href = decodedText;
                }, 500);  // Brief delay for user feedback
            } else {
                console.log('QR code detected but invalid format:', decodedText);
                updateScannerStatus('error', 'Invalid QR code. Please scan a patient QR code.');
            }
        }

        // ====================================================================
        // QR CODE ERROR HANDLER - Called continuously while scanning
        // ====================================================================
        function onQRCodeError(errorMessage) {
            // Silently ignore scanning errors - this is normal during active scanning
            // Only log if scanner is stopped unexpectedly
            if (!isScannerActive) {
                console.log('Scanning stopped');
            }
        }

        // ====================================================================
        // SCANNER STATUS UPDATE HELPER
        // ====================================================================
        function updateScannerStatus(type, message) {
            const statusElement = document.getElementById('qrScannerStatus');
            if (statusElement) {
                statusElement.className = `qr-scanner-status ${type}`;
                const icon = type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'circle-dot';
                if (type === 'scanning') {
                    statusElement.innerHTML = `<div class="qr-scanner-spinner"></div><span>${message}</span>`;
                } else {
                    statusElement.innerHTML = `<i class="fas fa-${icon}" style="margin-right: 8px;"></i>${message}`;
                }
            }
        }

        // ====================================================================
        // STOP SCANNER - Clean up camera and hide container
        // ====================================================================
        function stopQRScanner() {
            isScannerActive = false;

            const container = document.getElementById('qrScannerContainer');
            container.classList.remove('active');
            document.body.style.overflow = 'auto';
            updateScannerStatus('ready', 'Scanner closed. Click Start QR Scanner again to reopen.');

            if (html5QrcodeScanner) {
                html5QrcodeScanner.stop()
                    .then(() => html5QrcodeScanner.clear())
                    .then(() => {
                        console.log('QR Scanner stopped successfully');
                        html5QrcodeScanner = null;
                    })
                    .catch(err => {
                        console.error('Error stopping scanner:', err);
                        html5QrcodeScanner = null;
                    });
            }
        }

        // ====================================================================
        // FALLBACK: Scan uploaded image file containing QR code
        // Uses Html5Qrcode.scanFile if available (minimal change)
        // ====================================================================
        (function registerFileFallback() {
            const fileInput = document.getElementById('qrImageFile');
            if (!fileInput) return;
            fileInput.addEventListener('change', async function(e) {
                const file = e.target.files && e.target.files[0];
                if (!file) return;
                updateScannerStatus('scanning', 'Decoding image...');
                try {
                    if (typeof Html5Qrcode !== 'undefined' && typeof Html5Qrcode.scanFile === 'function') {
                        const decoded = await Html5Qrcode.scanFile(file, true);
                        if (decoded) {
                            onQRCodeDetected(decoded.decodedText || decoded);
                            return;
                        }
                    }

                    // If Html5Qrcode.scanFile is not available or didn't return, try instance decodeFromImage (if present)
                    if (html5QrcodeScanner && typeof html5QrcodeScanner.scanFile === 'function') {
                        const decoded2 = await html5QrcodeScanner.scanFile(file, true);
                        if (decoded2) {
                            onQRCodeDetected(decoded2.decodedText || decoded2);
                            return;
                        }
                    }

                    updateScannerStatus('error', 'Unable to decode QR from image. Try a clearer photo.');
                } catch (err) {
                    console.error('Image decode error:', err);
                    updateScannerStatus('error', 'Failed to decode image. Make sure it contains a QR code.');
                } finally {
                    // clear selection so same file can be re-uploaded
                    fileInput.value = '';
                }
            });
        })();

        // ====================================================================
        // Test camera permissions/devices and surface helpful messages
        // If successful, stop temporary stream and start Html5Qrcode scanner
        // ====================================================================
        async function testCamera() {
            updateScannerStatus('scanning', 'Requesting camera permission...');

            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                updateScannerStatus('error', 'Camera API not supported in this browser. Use a modern browser (Chrome/Edge/Firefox).');
                return;
            }

            // Warn about insecure origin
            if (!window.isSecureContext && !['localhost', '127.0.0.1'].includes(location.hostname)) {
                updateScannerStatus('error', 'Camera access requires HTTPS or localhost. Open the app using https:// or http://localhost.');
                return;
            }

            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
                // If we get a stream, immediately stop and proceed to start scanner normally
                stream.getTracks().forEach(t => t.stop());
                updateScannerStatus('scanning', 'Camera available — starting scanner...');
                // small delay so user sees update
                setTimeout(() => {
                    initiateCameraCapture();
                }, 300);
            } catch (err) {
                console.error('Test camera error:', err);
                if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
                    updateScannerStatus('error', 'Camera permission denied. Allow camera access and retry.');
                } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
                    updateScannerStatus('error', 'No camera found. Connect a webcam and retry.');
                } else if (err.name === 'NotReadableError') {
                    updateScannerStatus('error', 'Camera is busy or cannot be opened. Close other apps using the camera and retry.');
                } else {
                    updateScannerStatus('error', 'Camera error: ' + (err.message || err.name));
                }
            }
        }

        // ====================================================================
        // ESCAPE KEY HANDLER - Close scanner on Escape key
        // ====================================================================
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && isScannerActive) {
                stopQRScanner();
            }
        });

        // ====================================================================
        // ERROR BANNER HELPERS
        // ====================================================================
        function showManualSearchError(message) {
            const banner = document.getElementById('manualSearchErrorBanner');
            const text = document.getElementById('manualSearchErrorText');
            if (banner && text) {
                text.textContent = message;
                banner.style.display = 'block';
                // Auto-hide after 8 seconds
                setTimeout(() => {
                    banner.style.display = 'none';
                }, 8000);
            }
        }
        
        function closeManualSearchError() {
            const banner = document.getElementById('manualSearchErrorBanner');
            if (banner) {
                banner.style.display = 'none';
            }
        }

        // ====================================================================
        // MANUAL PATIENT ENTRY HANDLER - Enhanced Multi-Field Search
        // ====================================================================
        function handleManualEntry(event) {
            if (event && typeof event.preventDefault === 'function') {
                event.preventDefault();
            }

            const formData = new FormData(document.getElementById('manualEntryForm'));
            const searchTerm = formData.get('search_term').trim();

            if (!searchTerm) {
                showManualSearchError('Please enter a search term (name, email, phone, or ID).');
                clearManualSearchResults();
                return false;
            }

            if (searchTerm.length > 100) {
                showManualSearchError('Search term is too long. Please enter a shorter query.');
                return false;
            }

            performManualSearch(searchTerm, { fromSubmit: true });
            return false;
        }

        document.addEventListener('DOMContentLoaded', function () {
            const manualEntryForm = document.getElementById('manualEntryForm');
            if (manualEntryForm) {
                manualEntryForm.addEventListener('submit', handleManualEntry);
            }
        });

        function handleManualSearchInput(event) {
            const searchTerm = event.target.value.trim();
            closeManualSearchError();

            if (!searchTerm) {
                clearManualSearchResults();
            }
        }

        function performManualSearch(searchTerm, { fromSubmit = false } = {}) {
            closeManualSearchError();
            const submitButton = document.querySelector('#manualEntryForm button[type="submit"]') || document.querySelector('#manualEntryForm button');
            const originalText = submitButton ? submitButton.innerHTML : 'Searching...';
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Searching...';
            }

            console.log('🔍 Searching patient accounts for:', searchTerm);

            const manualSearchToken = <?php echo json_encode($manual_search_token); ?>;

            fetch(window.location.href, {
                method: 'POST',
                credentials: 'same-origin',
                cache: 'no-store',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json',
                },
                body: 'action=search_patient&search_term=' + encodeURIComponent(searchTerm) + '&search=' + encodeURIComponent(searchTerm)
            })
            .then(async response => {
                const text = await response.text();
                let data = null;
                try {
                    data = text ? JSON.parse(text) : null;
                } catch (err) {
                    // Not JSON — include raw text in the error for debugging
                    throw new Error('Invalid server response: ' + text);
                }

                if (!response.ok) {
                    if (response.status === 401) {
                        throw new Error('Your BHW session could not be verified. Please refresh your login session and try again.');
                    }
                    const errMsg = (data && data.message) ? data.message : ('Server returned HTTP ' + response.status + ': ' + text);
                    throw new Error(errMsg);
                }

                return data;
            })
            .then(data => {
                if (!data) {
                    return;
                }

                submitButton.disabled = false;
                submitButton.innerHTML = originalText;

                if (!data.success) {
                    clearManualSearchResults();
                    const errorMsg = data.message || 'An error occurred while searching.';
                    if (fromSubmit) {
                        showManualSearchError(errorMsg);
                    }
                    return;
                }

                if (data.patients && data.patients.length > 0) {
                    renderManualSearchResults(data.patients);
                    return;
                }

                clearManualSearchResults();
                if (fromSubmit) {
                    showManualSearchError(data.message || 'No matching patient accounts were found.');
                }
            })
            .catch(error => {
                submitButton.disabled = false;
                submitButton.innerHTML = originalText;
                clearManualSearchResults();
                showManualSearchError(error.message || 'Search failed. Please try again.');
            });
        }

        function renderManualSearchResults(patients) {
            const resultsPanel = document.getElementById('manualSearchResults');
            const resultsList = document.getElementById('manualSearchResultsList');

            if (!resultsPanel || !resultsList) {
                return;
            }

            resultsList.innerHTML = '';

            if (!patients || patients.length === 0) {
                const emptyRow = document.createElement('div');
                emptyRow.className = 'manual-search-option';
                emptyRow.innerHTML = '<div class="font-semibold text-slate-700">No matching patients found.</div>';
                resultsList.appendChild(emptyRow);
            } else {
                patients.forEach(patient => {
                    const button = document.createElement('button');
                    button.type = 'button';
                    button.className = 'manual-search-option';
                    button.innerHTML = `
                        <div>
                            <p class="font-semibold text-slate-900">${patient.name}</p>
                            <div class="patient-meta">
                                <span>ID: ${patient.patient_code || String(patient.id).padStart(6, '0')}</span>
                                <span>${patient.email}</span>
                                <span>${patient.phone}</span>
                                <span>${patient.dob}</span>
                            </div>
                        </div>
                        <div class="text-xs font-semibold text-[#454B1B]">Select</div>
                    `;
                    button.addEventListener('click', () => {
                        window.location.href = '?module=patient-profile&patient_id=' + encodeURIComponent(patient.id);
                    });
                    resultsList.appendChild(button);
                });
            }

            resultsPanel.classList.remove('hidden');
            resultsPanel.style.display = 'block';
        }

        function clearManualSearchResults() {
            const resultsPanel = document.getElementById('manualSearchResults');
            const resultsList = document.getElementById('manualSearchResultsList');
            if (resultsList) {
                resultsList.innerHTML = '';
            }
            if (resultsPanel) {
                resultsPanel.classList.add('hidden');
                resultsPanel.style.display = 'none';
            }
        }

        // ====================================================================
        // LOAD PATIENT PROFILE DATA AND DISPLAY
        // ====================================================================
        // ====================================================================
        // CONSULTATION FORM HANDLER
        // ====================================================================
        function handleConsultationSubmit(event) {
            event.preventDefault();
            alert('Consultation saved. In production, this will INSERT into PATIENT_RECORD table.');
            // TODO: Implement backend consultation save
        }

        // ====================================================================
        // PATIENT DROPDOWN SELECTION HANDLER
        // ====================================================================
        function handlePatientSelection() {
            const dropdown = document.getElementById('patientDropdown');
            const selectedOption = dropdown.options[dropdown.selectedIndex];
            const detailsPanel = document.getElementById('patientDetailsPanel');
            
            if (!selectedOption.value) {
                detailsPanel.style.display = 'none';
                disableConsultationFields();
                return;
            }

            const patientData = {
                name: selectedOption.dataset.patientName,
                dob: selectedOption.dataset.dob,
                sex: selectedOption.dataset.sex,
                contact: selectedOption.dataset.contact
            };

            document.getElementById('patientName').textContent = patientData.name;
            document.getElementById('patientDOB').textContent = patientData.dob ? new Date(patientData.dob).toLocaleDateString() : 'N/A';
            document.getElementById('patientSex').textContent = patientData.sex || 'N/A';
            document.getElementById('patientContact').textContent = patientData.contact;
            
            detailsPanel.style.display = 'block';
            enableConsultationFields();
        }

        /**
         * Refresh patient dropdown from backend
         * Called after appointment approval to show newly approved patients
         */
        function refreshPatientDropdown() {
            fetch('get_approved_patients.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.patients) {
                        const dropdown = document.getElementById('patientDropdown');
                        const currentValue = dropdown.value;
                        
                        // Clear dropdown except for placeholder
                        while (dropdown.options.length > 1) {
                            dropdown.remove(1);
                        }
                        
                        // Add patients from server
                        data.patients.forEach(patient => {
                            const option = document.createElement('option');
                            option.value = patient.appointment_id;
                            option.dataset.residentId = patient.resident_id;
                            option.dataset.patientName = patient.patient_name;
                            option.dataset.dob = patient.date_of_birth;
                            option.dataset.sex = patient.sex;
                            option.dataset.contact = patient.contact_number;
                            option.dataset.email = patient.email;
                            option.dataset.appointmentDate = patient.appointment_date;
                            option.dataset.appointmentTime = patient.appointment_time;
                            option.dataset.purpose = patient.purpose;
                            option.text = patient.patient_name + ' (' + new Date(patient.appointment_date + ' ' + patient.appointment_time).toLocaleDateString() + ' ' + patient.appointment_time + ')';
                            dropdown.appendChild(option);
                        });
                        
                        // Reset selection
                        dropdown.value = '';
                        document.getElementById('patientDetailsPanel').style.display = 'none';
                        disableConsultationFields();
                        
                        console.log('Dropdown refreshed with ' + data.patients.length + ' approved patients');
                    }
                })
                .catch(error => console.error('Error refreshing dropdown:', error));
        }

        function enableConsultationFields() {
            document.getElementById('diagnosisField').disabled = false;
            document.getElementById('treatmentField').disabled = false;
            document.getElementById('notesField').disabled = false;
            document.getElementById('consultationSubmitBtn').disabled = false;
        }

        function disableConsultationFields() {
            document.getElementById('diagnosisField').disabled = true;
            document.getElementById('treatmentField').disabled = true;
            document.getElementById('notesField').disabled = true;
            document.getElementById('consultationSubmitBtn').disabled = true;
        }

        // ====================================================================
        // MEDICINE DISPENSING HANDLER
        // ====================================================================
        function dispenseMedicine() {
            alert('Medicine added to dispensing queue. In production, this will update inventory counts.');
            // TODO: Implement backend medicine dispensing logic
        }

        // ====================================================================
        // MEDICINE INVENTORY FUNCTIONS
        // ====================================================================
        
        // Refresh medicine table - reload page to show new medicines
        function refreshMedicineTable() {
            console.log('Refreshing medicine table...');
            // Simple reliable refresh: reload the page
            location.reload();
        }
        
        // ====================================================================
        // MEDICINE INVENTORY - HELPER FUNCTIONS FOR STATUS CALCULATION
        // ====================================================================
        /**
         * Calculate medicine status based on stock quantity
         * @param {number} quantity - Current stock quantity
         * @returns {object} - {status: string, color: string, icon: string, display: string}
         */
        function calculateMedicineStatus(quantity) {
            const qty = parseInt(quantity) || 0;
            if (qty > 5) {
                return {
                    status: 'Available',
                    color: 'green',
                    display: '<span class="inline-flex items-center gap-1 px-3 py-1 bg-green-50 text-green-700 rounded-full font-medium text-xs"><i class="fas fa-circle text-xs"></i> Available</span>'
                };
            } else if (qty > 0 && qty <= 5) {
                return {
                    status: 'Low Stock',
                    color: 'orange',
                    display: '<span class="inline-flex items-center gap-1 px-3 py-1 bg-orange-50 text-orange-700 rounded-full font-medium text-xs"><i class="fas fa-exclamation-triangle text-xs mr-1"></i> Low Stock</span>'
                };
            } else {
                return {
                    status: 'Out of Stock',
                    color: 'slate',
                    display: '<span class="inline-flex items-center gap-1 px-3 py-1 bg-slate-100 text-slate-700 rounded-full font-medium text-xs"><i class="fas fa-circle text-xs"></i> Out of Stock</span>'
                };
            }
        }
        
        /**
         * Auto-sync available stock with total stock when total is changed
         */
        function autoSyncAvailableStock() {
            const totalStockInput = document.getElementById('addMedicineTotalStock');
            const availableStockInput = document.getElementById('addMedicineAvailableStock');
            
            if (totalStockInput && availableStockInput) {
                const totalValue = parseInt(totalStockInput.value) || 0;
                availableStockInput.value = totalValue;
                
                // Update status preview
                const statusDiv = document.getElementById('addMedicineStatusPreview');
                if (statusDiv) {
                    const statusInfo = calculateMedicineStatus(totalValue);
                    statusDiv.innerHTML = statusInfo.display;
                }
            }
        }
        
        /**
         * Update status preview in edit modal
         */
        function updateEditMedicineStatus() {
            const stockInput = document.getElementById('editMedicineStock');
            const availableInput = document.getElementById('editMedicineAvailable');
            const statusDiv = document.getElementById('editMedicineStatusPreview');
            
            if (stockInput && statusDiv) {
                const stockValue = parseInt(stockInput.value) || 0;
                const statusInfo = calculateMedicineStatus(stockValue);
                statusDiv.innerHTML = statusInfo.display;
                
                // Validate available doesn't exceed stock
                if (availableInput) {
                    const availValue = parseInt(availableInput.value) || 0;
                    if (availValue > stockValue) {
                        availableInput.value = stockValue;
                    }
                }
            }
        }
        
        // ====================================================================
        // SHOW ADD MEDICINE MODAL - Enhanced Version
        // ====================================================================
        function showAddMedicineForm() {
            const modal = document.getElementById('addMedicineModal');
            if (!modal) {
                console.error('Add Medicine modal not found');
                alert('Error: Modal not found. Please refresh the page.');
                return;
            }
            
            // Reset form
            const form = document.getElementById('addMedicineForm');
            if (form) {
                form.reset();
            }
            
            // Clear all input fields
            document.getElementById('addMedicineName').value = '';
            document.getElementById('addMedicineDosage').value = '';
            document.getElementById('addMedicineTotalStock').value = '0';
            document.getElementById('addMedicineAvailableStock').value = '0';
            
            // Reset status preview
            const statusPreview = document.getElementById('addMedicineStatusPreview');
            if (statusPreview) {
                statusPreview.innerHTML = '<span class="inline-flex items-center gap-1 px-3 py-1 bg-slate-100 text-slate-700 rounded-full font-medium text-xs"><i class="fas fa-circle text-xs"></i> Out of Stock</span>';
            }
            
            // Enable submit button
            const submitBtn = document.getElementById('addMedicineSubmitBtn');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-plus-circle"></i> Add Medicine';
            }
            
            // Show modal with animation
            modal.style.display = 'flex';
            
            // Focus on first input
            setTimeout(() => {
                document.getElementById('addMedicineName').focus();
            }, 100);
            
            console.log('Add Medicine modal opened');
        }

        function closeAddMedicineModal() {
            const modal = document.getElementById('addMedicineModal');
            if (modal) {
                modal.style.display = 'none';
                console.log('Add Medicine modal closed');
            }
        }

        // ====================================================================
        // PATIENT SELECTION MODAL FUNCTIONS
        // ====================================================================
        // ====================================================================
        // PATIENT SELECTION MODAL - REMOVED (Using Auto-Redirect with First Match)
        // ====================================================================

        /**
         * Handle Add Medicine Form Submission
         * Validates input and sends to backend via AJAX
         */
        function handleAddMedicineSubmit(event) {
            event.preventDefault();
            
            // Get form values
            const medicineName = document.getElementById('addMedicineName').value.trim();
            const dosage = document.getElementById('addMedicineDosage').value.trim();
            const totalStock = document.getElementById('addMedicineTotalStock').value.trim();
            const availableStock = document.getElementById('addMedicineAvailableStock').value.trim();
            
            // Client-side validation
            if (!medicineName) {
                alert('❌ Error: Medicine name is required');
                document.getElementById('addMedicineName').focus();
                return;
            }
            
            if (!totalStock || parseInt(totalStock) < 0) {
                alert('❌ Error: Please enter a valid stock quantity');
                document.getElementById('addMedicineTotalStock').focus();
                return;
            }
            
            // Show loading state
            const submitBtn = document.getElementById('addMedicineSubmitBtn');
            const originalHTML = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adding...';
            
            console.log('📋 Submitting Add Medicine form:', {
                name: medicineName,
                dosage: dosage,
                totalStock: totalStock,
                availableStock: availableStock
            });
            
            // Prepare form data for backend
            const formData = new FormData();
            formData.append('action', 'add_medicine');
            formData.append('medicine_name', medicineName);
            formData.append('dosage', dosage);
            formData.append('quantity', String(parseInt(totalStock, 10)));
            formData.append('available_stock', String(parseInt(availableStock || totalStock, 10)));
            
            // Submit via AJAX to current page (dashboard_bhw.php)
            fetch(window.location.href, {
                method: 'POST',
                credentials: 'same-origin',
                body: formData
            })
            .then(async response => {
                console.log('📨 Server response status:', response.status);
                const responseText = await response.text();
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (parseError) {
                    throw new Error(`Server returned HTTP ${response.status}: ${responseText.slice(0, 500)}`);
                }
                if (!response.ok) {
                    throw new Error(data.message || data.error || `Server returned HTTP ${response.status}`);
                }
                return data;
            })
            .then(data => {
                console.log('✅ Server response:', data);
                
                // Restore button
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalHTML;
                
                if (data.success) {
                    // Show success message
                    alert('✅ Medicine added successfully!\n\nMedicine Name: ' + medicineName + '\nStock: ' + totalStock);
                    
                    // Close modal
                    closeAddMedicineModal();
                    
                    // Refresh page to show updated inventory
                    console.log('🔄 Reloading page to show new medicine...');
                    setTimeout(() => {
                        location.reload();
                    }, 500);
                } else {
                    // Show error message
                    const errorMsg = data.message || data.error || 'Unknown error occurred';
                    alert('❌ Error adding medicine:\n\n' + errorMsg);
                    console.error('Server error:', data.error || data.message, data);
                }
            })
            .catch(error => {
                console.error('🔴 Network/Fetch error:', error.message, error);
                
                // Restore button
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalHTML;
                
                alert('❌ Error adding medicine:\n\n' + (error.message || 'Unknown request error') + '\n\nPlease check the browser console and server log for details.');
            });
        }

        /**
         * Edit Medicine - Extract data from table row and populate modal
         * Enhanced version with better data extraction and validation
         */
        function editMedicine(button) {
            // Get the table row
            const row = button.closest('tr');
            if (!row) {
                console.error('Could not find table row');
                alert('Error: Could not identify medicine row');
                return;
            }
            
            // Extract data from table cells
            // Table columns: Medicine Name | Dosage | Total Stock | Available | Dispensed | Status | Actions
            const cells = row.cells;
            
            const medicineName = cells[0] ? cells[0].textContent.trim() : '';
            const dosage = cells[1] ? cells[1].textContent.trim() : '';
            const totalStock = cells[2] ? cells[2].textContent.trim() : '0';
            const available = cells[3] ? cells[3].textContent.trim() : '0';
            const dispensed = cells[4] ? cells[4].textContent.trim() : '0';
            const medicineId = row.getAttribute('data-medicine-id');
            
            console.log('📋 Editing medicine:', {
                id: medicineId,
                name: medicineName,
                dosage: dosage,
                totalStock: totalStock,
                available: available,
                dispensed: dispensed
            });
            
            // Get modal and form
            const modal = document.getElementById('editMedicineModal');
            const form = document.getElementById('editMedicineForm');
            
            if (!modal || !form) {
                console.error('Edit Medicine modal or form not found');
                alert('Error: Modal not found. Please refresh the page.');
                return;
            }
            
            // Populate form fields with extracted data
            document.getElementById('editMedicineId').value = medicineId || '';
            document.getElementById('editMedicineName').value = medicineName || '';
            document.getElementById('editMedicineDosage').value = dosage || '';
            document.getElementById('editMedicineStock').value = totalStock || '0';
            document.getElementById('editMedicineAvailable').value = available || '0';
            document.getElementById('editMedicineDispensed').value = dispensed || '0';
            
            // Update status preview
            updateEditMedicineStatus();
            
            // Enable submit button
            const submitBtn = document.getElementById('editMedicineSubmitBtn');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-save"></i> Update Medicine';
            }
            
            // Show modal
            modal.style.display = 'flex';
            
            // Focus on first editable field
            setTimeout(() => {
                document.getElementById('editMedicineName').focus();
            }, 100);
            
            console.log('✏️ Edit modal opened');
        }

        function closeEditMedicineModal() {
            const modal = document.getElementById('editMedicineModal');
            if (modal) {
                modal.style.display = 'none';
                console.log('Edit Medicine modal closed');
            }
        }

        /**
         * Handle Edit Medicine Form Submission
         * Validates input and sends to backend via AJAX
         */
        function handleEditMedicineSubmit(event) {
            event.preventDefault();
            
            // Get form values
            const medicineId = document.getElementById('editMedicineId').value;
            const medicineName = document.getElementById('editMedicineName').value.trim();
            const dosage = document.getElementById('editMedicineDosage').value.trim();
            const stock = document.getElementById('editMedicineStock').value.trim();
            const available = document.getElementById('editMedicineAvailable').value.trim();
            const dispensed = document.getElementById('editMedicineDispensed').value.trim();
            
            // Client-side validation
            if (!medicineId) {
                alert('❌ Error: Medicine ID is missing');
                return;
            }
            
            if (!medicineName) {
                alert('❌ Error: Medicine name is required');
                document.getElementById('editMedicineName').focus();
                return;
            }
            
            if (!stock || parseInt(stock) < 0) {
                alert('❌ Error: Please enter a valid total stock quantity');
                document.getElementById('editMedicineStock').focus();
                return;
            }
            
            // Validate available doesn't exceed stock
            const availableQty = parseInt(available) || 0;
            const stockQty = parseInt(stock) || 0;
            if (availableQty > stockQty) {
                alert('❌ Error: Available quantity cannot exceed total stock\n\nAvailable: ' + availableQty + '\nTotal Stock: ' + stockQty);
                document.getElementById('editMedicineAvailable').focus();
                return;
            }
            
            // Show loading state
            const submitBtn = document.getElementById('editMedicineSubmitBtn');
            const originalHTML = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Updating...';
            
            console.log('📋 Submitting Edit Medicine form:', {
                id: medicineId,
                name: medicineName,
                dosage: dosage,
                stock: stock,
                available: available,
                dispensed: dispensed
            });
            
            // Prepare form data for backend
            const formData = new FormData();
            formData.append('action', 'update_medicine');
            formData.append('medicine_id', medicineId);
            formData.append('medicine_name', medicineName);
            formData.append('dosage', dosage);
            formData.append('stock', stock);
            formData.append('available', available);
            formData.append('dispensed', dispensed);
            
            // Submit via AJAX
            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => {
                console.log('📨 Server response status:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('✅ Server response:', data);
                
                // Restore button
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalHTML;
                
                if (data.success) {
                    // Show success message
                    const oldStatus = calculateMedicineStatus(stock).status;
                    alert('✅ Medicine updated successfully!\n\nMedicine: ' + medicineName + '\nStock: ' + stock + '\nAvailable: ' + available + '\nStatus: ' + oldStatus);
                    
                    // Close modal
                    closeEditMedicineModal();
                    
                    // Refresh page to show updated inventory
                    console.log('🔄 Reloading page to show updated medicine...');
                    setTimeout(() => {
                        location.reload();
                    }, 500);
                } else {
                    // Show error message
                    const errorMsg = data.message || 'Unknown error occurred';
                    alert('❌ Error updating medicine:\n\n' + errorMsg);
                    console.error('Server error:', data);
                }
            })
            .catch(error => {
                console.error('🔴 Network/Fetch error:', error);
                
                // Restore button
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalHTML;
                
                alert('❌ Error updating medicine:\n\n' + error.message + '\n\nPlease check your connection and try again.');
            });
        }

        function handleDeleteMedicine(event) {
            const medicineId = document.getElementById('editMedicineId').value;
            const medicineName = document.getElementById('editMedicineName').value.trim();
            const deleteButton = event?.currentTarget;

            if (!medicineId) {
                alert('❌ Error: Medicine ID is missing. Cannot delete.');
                return;
            }

            if (!confirm(`Delete this medicine from inventory?\n\nMedicine: ${medicineName || 'Unknown'}\nThis action cannot be undone.`)) {
                return;
            }

            const originalHTML = deleteButton ? deleteButton.innerHTML : 'Deleting...';
            if (deleteButton) {
                deleteButton.disabled = true;
                deleteButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Deleting...';
            }

            const formData = new FormData();
            formData.append('action', 'delete_medicine');
            formData.append('medicine_id', medicineId);

            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (deleteButton) {
                    deleteButton.disabled = false;
                    deleteButton.innerHTML = originalHTML;
                }

                if (data.success) {
                    alert('✅ Medicine deleted successfully.');
                    closeEditMedicineModal();
                    console.log('🔄 Reloading page to remove deleted medicine...');
                    setTimeout(() => location.reload(), 500);
                } else {
                    alert('❌ Error deleting medicine:\n\n' + (data.message || 'Unknown error occurred'));
                    console.error('Delete medicine failed:', data);
                }
            })
            .catch(error => {
                if (deleteButton) {
                    deleteButton.disabled = false;
                    deleteButton.innerHTML = originalHTML;
                }

                console.error('🔴 Network/Fetch error while deleting medicine:', error);
                alert('❌ Error deleting medicine:\n\n' + error.message + '\n\nPlease try again.');
            });
        }

        // ====================================================================
        // APPOINTMENT MANAGEMENT FUNCTIONS
        // ====================================================================
        function changeAppointmentStatus(button, status, appointmentId) {
            // Prevent multiple submissions
            if (button.disabled) {
                return;
            }
            
            // ================================================================
            // HANDLE RENDERED STATUS - Patient completed visit normally
            // ================================================================
            if (status === 'rendered') {
                if (confirm(`Mark this appointment as "Rendered" (completed)?\n\nThis will create a medical visit record for the resident.`)) {
                    button.disabled = true;
                    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                    
                    // Get resident_id from button data attribute
                    const residentId = button.getAttribute('data-resident-id');
                    
                    // AJAX call to update appointment status to 'completed' AND CREATE MEDICAL RECORD
                    fetch('', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'action=update_appointment_status&appointment_id=' + appointmentId + '&resident_id=' + residentId + '&status=completed'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert(`✓ Appointment marked as Rendered\n✓ Medical visit record created\n\nThe resident can now see this visit in their Medical Visit History.`);
                            location.reload();
                        } else {
                            alert('Error: ' + (data.message || 'Failed to update appointment'));
                            button.disabled = false;
                            button.innerHTML = '<i class="fas fa-check"></i> Rendered';
                        }
                    })
                    .catch(err => {
                        console.error(err);
                        alert('Error updating appointment');
                        button.disabled = false;
                        button.innerHTML = '<i class="fas fa-check"></i> Rendered';
                    });
                }
            }
            // ================================================================
            // HANDLE NO-SHOW STATUS - Patient missed appointment
            // ================================================================
            else if (status === 'no-show') {
                if (confirm(`Mark this appointment as "No Show"?`)) {
                    button.disabled = true;
                    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
                    
                    // AJAX call to update appointment status to 'no_show' in database
                    fetch('', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'action=update_appointment_status&appointment_id=' + appointmentId + '&status=no_show'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert(`✗ Appointment marked as No Show\n\nThe appointment will move to the Appointment History tab.`);
                            location.reload();
                        } else {
                            alert('Error: ' + (data.message || 'Failed to update appointment'));
                            button.disabled = false;
                        }
                    })
                    .catch(err => {
                        console.error(err);
                        alert('Error updating appointment');
                        button.disabled = false;
                    });
                }
            }
            // ================================================================
            // HANDLE APPROVED STATUS - BHW approves appointment for today
            // ================================================================
            else if (status === 'approved') {
                if (confirm(`Approve this appointment for today?`)) {
                    button.disabled = true;
                    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Approving...';
                    
                    // AJAX call to update appointment status to 'approved' in database
                    fetch('', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                        body: 'action=update_appointment_status&appointment_id=' + appointmentId + '&status=approved'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert(`✓ Appointment approved\n\nThe appointment is now confirmed for today's queue.`);
                            location.reload();
                        } else {
                            alert('Error: ' + (data.message || 'Failed to update appointment'));
                            button.disabled = false;
                        }
                    })
                    .catch(err => {
                        console.error(err);
                        alert('Error updating appointment');
                        button.disabled = false;
                    });
                }
            }
            // ================================================================
            // If called with other status, use generic update
            // ================================================================
            else {
                console.log('Appointment status update called with status:', status);
            }
        }

        // ====================================================================
        // APPOINTMENT APPROVAL HANDLER
        // ====================================================================
        // When BHW clicks Approve:
        // 1. Updates appointment status to 'Approved'
        // 2. Creates medical_history record for resident
        // 3. Refreshes UI to show success
        // ====================================================================
        function handleAppointmentApproval(button, appointmentId, newStatus) {
            console.log('Approving appointment ID:', appointmentId);
            
            if (!appointmentId || appointmentId <= 0) {
                alert('❌ Error: Invalid appointment ID');
                return;
            }
            
            // Show loading state
            button.disabled = true;
            const originalHTML = button.innerHTML;
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Approving...';
            
            // Get optional diagnosis and treatment if provided in forms
            const diagnosis = document.getElementById('appointmentDiagnosis')?.value || '';
            const treatmentPlan = document.getElementById('appointmentTreatment')?.value || '';
            
            // Prepare form data
            const formData = new FormData();
            formData.append('appointment_id', appointmentId);
            if (diagnosis) formData.append('diagnosis', diagnosis);
            if (treatmentPlan) formData.append('treatment_plan', treatmentPlan);
            
            console.log('Sending approval request:', {
                appointment_id: appointmentId,
                diagnosis: diagnosis,
                treatment_plan: treatmentPlan
            });
            
            // Make AJAX request to backend handler
            fetch('approve_appointment_handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                console.log('Server response:', data);
                
                if (data.success) {
                    // ============================================================
                    // SUCCESS - Appointment approved & medical history created
                    // ============================================================
                    console.log('Approval successful:', data.data);
                    
                    // Show success message
                    alert(`✅ ${data.message}\n\n📋 Medical History Record Created\nResident ID: ${data.data.resident_id}\nVisit Date: ${data.data.visit_date}\nVisit Type: ${data.data.visit_type}`);
                    
                    // Update button appearance
                    button.innerHTML = '<i class="fas fa-check-circle"></i> Approved';
                    button.style.backgroundColor = '#10b981';
                    button.style.opacity = '0.7';
                    button.disabled = true;
                    
                    // Highlight the row to show it was processed
                    const row = button.closest('tr');
                    if (row) {
                        row.style.backgroundColor = '#f0fdf4';
                    }
                    
                    // Refresh patient dropdown with newly approved patient
                    refreshPatientDropdown();
                    
                    // Show success
                    setTimeout(() => {
                        alert('✅ Patient is now available in the consultation dropdown!');
                    }, 500);
                    
                } else {
                    // ============================================================
                    // ERROR - Approval failed
                    // ============================================================
                    console.error('Approval failed:', data.message);
                    alert(`❌ ${data.message}`);
                    
                    // Restore button
                    button.disabled = false;
                    button.innerHTML = originalHTML;
                }
            })
            .catch(error => {
                // ============================================================
                // NETWORK ERROR
                // ============================================================
                console.error('Network error:', error);
                alert(`❌ Network error: ${error.message}`);
                
                // Restore button
                button.disabled = false;
                button.innerHTML = originalHTML;
            });
        }

        // ====================================================================
        // SMS COMMUNICATION FUNCTIONS
        // ====================================================================
        function updateCharCount() {
            const smsContent = document.getElementById('smsContent').value;
            document.getElementById('charCount').textContent = smsContent.length;
            document.getElementById('smsPreview').textContent = smsContent || 'Your message will appear here...';
        }

        function insertTemplate(template) {
            document.getElementById('smsContent').value = template;
            updateCharCount();
        }

        function toggleCustomNumbers() {
            const recipientType = document.querySelector('input[name="recipient_type"]:checked').value;
            const customNumbersSection = document.getElementById('customNumbersSection');
            
            if (recipientType === 'custom') {
                customNumbersSection.classList.remove('hidden');
            } else {
                customNumbersSection.classList.add('hidden');
            }
        }

        function handleSMSSubmit(event) {
            event.preventDefault();
            
            // Get form data
            const recipientType = document.querySelector('input[name="recipient_type"]:checked').value;
            const messageText = document.getElementById('smsContent').value.trim();
            const customNumbers = document.getElementById('customNumbers')?.value || '';
            
            // Validate message
            if (!messageText) {
                alert('Please enter a message');
                return;
            }
            
            if (messageText.length > 160) {
                alert('Message exceeds 160 character limit');
                return;
            }
            
            // Show loading state
            const submitBtn = event.target.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Sending...';
            
            // Prepare form data
            const formData = new FormData();
            formData.append('action', 'send_sms');
            formData.append('recipient_type', recipientType);
            formData.append('message', messageText);
            if (customNumbers) {
                formData.append('custom_numbers', customNumbers);
            }
            
            console.log('Sending SMS:', { recipientType, messageLength: messageText.length, customNumbers: !!customNumbers });
            
            // Send to backend handler
            fetch('send_sms_handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                console.log('Response status:', response.status);
                const contentType = response.headers.get('content-type');
                console.log('Content-Type:', contentType);
                return response.text().then(text => {
                    console.log('Raw response text:', text);
                    try {
                        return JSON.parse(text);
                    } catch (e) {
                        console.error('Failed to parse JSON:', e);
                        throw new Error('Server returned invalid JSON: ' + text.substring(0, 100));
                    }
                });
            })
            .then(data => {
                // Restore button state
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
                
                console.log('Parsed data:', data);
                
                if (data.success) {
                    alert(`✅ SMS sent successfully!\n\nSent: ${data.sent}\nFailed: ${data.failed}\nTotal Recipients: ${data.total}`);
                    
                    // Clear form
                    document.getElementById('smsForm').reset();
                    document.getElementById('charCount').textContent = '0';
                    document.getElementById('smsPreview').textContent = 'Your message will appear here...';
                } else {
                    alert(`❌ SMS sending failed:\n${data.message}`);
                }
            })
            .catch(error => {
                // Restore button state
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
                
                console.error('SMS Error:', error);
                alert('❌ An error occurred while sending SMS.\n\n' + error.message + '\n\nCheck browser console for details.');
            });
        }

        // ====================================================================
        // DATA SAVE & SYNC HANDLER
        // ====================================================================
        function triggerDataSave() {
            const syncStatus = document.getElementById('syncStatus');
            syncStatus.innerHTML = '<span class="w-3 h-3 rounded-full bg-blue-500 animate-spin"></span><span class="text-sm text-blue-600 font-semibold">Saving data...</span>';
            
            // Simulate save operation
            setTimeout(() => {
                syncStatus.innerHTML = '<span class="w-3 h-3 rounded-full bg-emerald-500"></span><span class="text-sm text-emerald-600 font-semibold">All data saved successfully</span>';
            }, 2000);

            // TODO: Implement actual backend data save
            console.log('Data save triggered. In production, this will:');
            console.log('1. POST consultation records to backend');
            console.log('2. POST medicine dispensing records to backend');
            console.log('3. POST appointment status updates to backend');
            console.log('4. POST SMS records to backend');
            console.log('5. Sync with cloud or save locally if offline');
        }

        // ====================================================================
        // INTERACTIVE STAT CARDS NAVIGATION
        // ====================================================================
        /**
         * Navigate to module when stat card is clicked
         * Updates URL with module parameter to show corresponding tab
         */
        function navigateToModule(moduleName) {
            // Build new URL with module parameter
            const baseUrl = window.location.href.split('?')[0];
            const newUrl = baseUrl + '?module=' + encodeURIComponent(moduleName);
            
            // Navigate to new URL (page will reload showing the selected module)
            window.location.href = newUrl;
        }

        const deletedSurveillanceMetricIds = new Set();
        const savedSurveillanceMetricsFromDb = normalizeSurveillanceMetrics(<?php echo json_encode($surveillance_metrics); ?>);
        let surveillanceData = savedSurveillanceMetricsFromDb;

        function normalizeSurveillanceMetrics(rawMetrics) {
            const values = Array.isArray(rawMetrics) ? rawMetrics : (rawMetrics && typeof rawMetrics === 'object' && ('disease_name' in rawMetrics) ? [rawMetrics] : []);
            return values.filter(record => {
                if (record.id && deletedSurveillanceMetricIds.has(String(record.id))) return false;
                const diseaseName = String(record.disease_name ?? record.diseaseName ?? '').trim();
                const caseCount = Number(record.case_count ?? record.caseCount ?? 0);
                return diseaseName !== '' && diseaseName.toLowerCase() !== 'record entry' && caseCount > 0;
            }).map(record => ({
                id: record.id || null,
                reportingPeriod: record.reporting_period || record.reportingPeriod || 'Current 4 Weeks',
                diseaseName: String(record.disease_name ?? record.diseaseName ?? '').trim(),
                caseCount: Number(record.case_count ?? record.caseCount ?? 0),
                trendStatus: record.trend_status || record.trendStatus || 'Baseline',
                metaNotes: record.meta_notes || record.metaNotes || 'No notes recorded.',
                createdAt: record.created_at || record.createdAt || ''
            }));
        }

        function getSavedSurveillanceMetrics() {
            return surveillanceData;
        }

        function getSeverityLabelByCount(count) {
            const value = Number(count || 0);
            if (value <= 10) return { label: 'Baseline', color: 'text-amber-600' };
            if (value <= 20) return { label: 'Low', color: 'text-emerald-600' };
            if (value <= 30) return { label: 'Moderate', color: 'text-sky-600' };
            return { label: 'High', color: 'text-red-600' };
        }

        function safeSurveillanceText(value, fallback) {
            if (value === null || value === undefined || String(value).trim() === '') {
                return fallback;
            }
            return String(value).trim();
        }

        function getDiseaseKey(name) {
            const normalized = safeSurveillanceText(name, 'dengue').toLowerCase();
            if (normalized.includes('rabies')) return 'rabies';
            if (normalized.includes('respiratory')) return 'respiratory';
            if (normalized.includes('nutrition')) return 'nutrition';
            return 'dengue';
        }

        function renderSurveillancePreview(metrics) {
            const records = (Array.isArray(metrics) ? metrics : []).slice().sort((a, b) => b.caseCount - a.caseCount);
            const latest = records[0] || { diseaseName: 'None', caseCount: 0, trendStatus: 'Baseline', metaNotes: 'No notes recorded.', reportingPeriod: 'Current 4 Weeks' };
            const escapeHtml = value => String(value).replace(/[&<>'"]/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[character]));
            document.getElementById('survReportingPeriod').textContent = `Reporting Period: ${latest.reportingPeriod}`;
            const container = document.getElementById('surveillanceRecordsList');
            container.innerHTML = '';
            container.innerHTML = records.length ? records.map((record, index) => `<article id="disease-card-${record.id}" data-id="${record.id}" data-disease-name="${escapeHtml(record.diseaseName)}" data-case-count="${record.caseCount}" class="surveillance-preview-card rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-700 dark:bg-slate-800"><p class="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">${index === 0 ? 'Latest Entry' : 'Recorded Entry'}</p><p ${index === 0 ? 'id="previewDiseaseName"' : ''} class="mt-3 text-xl font-bold text-slate-900 dark:text-white">${escapeHtml(record.diseaseName)}</p><p ${index === 0 ? 'id="previewDiseaseMeta"' : ''} class="mt-1 text-sm text-slate-600 dark:text-slate-400">${escapeHtml(record.metaNotes)}</p><p id="${index === 0 ? 'previewQuantityCount' : 'disease-count-' + record.id}" class="mt-4 text-3xl font-bold text-slate-900 dark:text-white">${record.caseCount}</p><p ${index === 0 ? 'id="previewTrend"' : ''} class="mt-1 text-sm font-semibold text-[#3D4A1E] dark:text-lime-300">${escapeHtml(record.trendStatus)}</p><div class="mt-4 flex gap-2"><button type="button" data-edit-quantity data-metric-id="${record.id}" data-disease-name="${escapeHtml(record.diseaseName)}" data-current-qty="${record.caseCount}" class="rounded-lg border border-[#3D4A1E] px-3 py-2 text-xs font-semibold text-[#3D4A1E] transition hover:bg-[#3D4A1E] hover:text-white dark:text-lime-300">Edit Qty</button><button type="button" data-delete-disease data-id="${record.id}" data-disease-id="${record.id}" data-disease-name="${escapeHtml(record.diseaseName)}" class="rounded-lg border border-red-200 px-3 py-2 text-xs font-semibold text-red-600 transition hover:bg-red-600 hover:text-white dark:border-red-800 dark:text-red-300" aria-label="Delete ${escapeHtml(record.diseaseName)}"><i class="fas fa-trash-alt"></i></button></div></article>`).join('') : '<p class="col-span-full rounded-xl border border-dashed border-slate-300 p-8 text-center text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">No disease entries recorded yet.</p>';
            document.querySelectorAll('[id^="disease-card-"]').forEach(card => {
                const diseaseMeta = card.querySelector('#previewDiseaseMeta') || card.querySelectorAll('p')[2];
                if (diseaseMeta) diseaseMeta.remove();
            });
            document.querySelectorAll('[id^="disease-card-"]').forEach(card => {
                const countDisplay = card.querySelector('#previewQuantityCount, [id^="disease-count-"]');
                if (!countDisplay || card.querySelector('.disease-quantity-input')) return;
                countDisplay.classList.add('case-count-display');
                const input = document.createElement('input');
                input.type = 'number';
                input.min = '0';
                input.value = card.dataset.caseCount || '0';
                input.className = 'disease-quantity-input w-24 rounded-lg border border-slate-300 px-3 py-2 text-sm dark:border-slate-600 dark:bg-slate-900 dark:text-white';
                input.setAttribute('aria-label', `${card.dataset.diseaseName || 'Disease'} case count`);
                countDisplay.parentElement.insertBefore(input, countDisplay);
            });
            document.querySelectorAll('[data-edit-quantity]').forEach(button => button.addEventListener('click', () => editDiseaseQuantity(button.dataset.metricId, button.dataset.diseaseName, button.dataset.currentQty)));
            document.querySelectorAll('[data-delete-disease]').forEach(button => button.addEventListener('click', event => {
                const recordId = event.currentTarget.getAttribute('data-id') || event.currentTarget.dataset.id || event.currentTarget.getAttribute('data-disease-id') || event.currentTarget.dataset.diseaseId;
                if (!recordId) console.log('Missing ID for element:', event.currentTarget);
                deleteDiseaseMetric(recordId, event.currentTarget.getAttribute('data-disease-name') || event.currentTarget.dataset.diseaseName, event.currentTarget);
            }));
            updateHighestIncidenceDisplay();
        }

        function updateHighestIncidence() {
            const records = Array.from(document.querySelectorAll('[id^="disease-card-"], .summary-card')).map(card => ({
                diseaseName: card.dataset.diseaseName || '',
                caseCount: card.querySelector('.disease-quantity-input')
                    ? Number.parseInt(card.querySelector('.disease-quantity-input').value, 10) || 0
                    : Number.parseInt(card.getAttribute('data-quantity') || card.dataset.caseCount || 0, 10) || 0
            }));
            const highest = records.filter(record => record.diseaseName && record.diseaseName.toLowerCase() !== 'record entry' && record.caseCount > 0).sort((a, b) => b.caseCount - a.caseCount)[0] || { diseaseName: 'None', caseCount: 0 };
            document.getElementById('highest-incidence-name').textContent = highest.diseaseName;
            document.getElementById('highest-incidence-count').textContent = highest.caseCount;
        }

        function updateHighestIncidenceDisplay() {
            updateHighestIncidence();
        }

        window.saveSurveillanceMetric = function(id, newQuantity) {
            const formData = new FormData();
            formData.append('action', 'save_surveillance_metrics');
            formData.append('metric_id', id);
            formData.append('case_count', String(newQuantity));
            return fetch('dashboard_bhw.php', { method: 'POST', body: formData }).then(response => response.json());
        };

        document.addEventListener('input', function(event) {
            if (!event.target.matches('.disease-quantity-input')) return;
            const input = event.target;
            const newQuantity = Math.max(0, Number.parseInt(input.value, 10) || 0);
            const parentCard = input.closest('[id^="disease-card-"]') || input.closest('.summary-card');
            if (!parentCard) return;
            parentCard.setAttribute('data-quantity', newQuantity);
            parentCard.setAttribute('data-case-count', newQuantity);
            const countDisplay = parentCard.querySelector('.case-count-display');
            if (countDisplay) countDisplay.textContent = String(newQuantity);
            const recordId = parentCard.getAttribute('data-id');
            if (!recordId || recordId === 'undefined') return;
            saveSurveillanceMetric(recordId, newQuantity).then(data => {
                if (!data.success) throw new Error(data.message || 'Unable to save quantity.');
                surveillanceData = normalizeSurveillanceMetrics(data.metrics || []);
                if (newQuantity <= 0) parentCard.remove();
                updateHighestIncidenceDisplay();
            }).catch(error => console.error('Disease quantity save failed:', error));
        });

        window.deleteDiseaseMetric = function(diseaseId, diseaseName = '', button = null) {
            const recordId = diseaseId && diseaseId !== 'undefined' ? diseaseId : '';
            if (!recordId && !diseaseName) {
                console.error('Cannot delete: Missing database ID', button);
                return;
            }
            if (!window.confirm('Delete this disease entry?')) return;
            const formData = new FormData();
            formData.append('action', 'delete_metric');
            if (recordId) formData.append('id', recordId);
            if (diseaseName) formData.append('disease_name', diseaseName);
            fetch('dashboard_bhw.php', { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    if (!data.success) throw new Error(data.message || 'Unable to delete disease entry.');
                    const deletedId = String(data.deleted_id || recordId);
                    deletedSurveillanceMetricIds.add(deletedId);
                    surveillanceData = surveillanceData.filter(record => String(record.id) !== deletedId && (!diseaseName || record.diseaseName !== diseaseName));
                    localStorage.removeItem('scancareSurveillanceMetrics');
                    const card = button?.closest('[id^="disease-card-"]') || document.getElementById(`disease-card-${deletedId}`);
                    if (card) card.remove();
                    updateHighestIncidenceDisplay();
                })
                .catch(error => window.alert(error.message));
        };

        window.editDiseaseQuantity = function(id, diseaseName, currentQty) {
            const nextQuantity = window.prompt(`Update case count for ${diseaseName || 'this disease'}:`, currentQty);
            if (nextQuantity === null) return;
            const trimmedQuantity = String(nextQuantity).trim();
            const parsedQuantity = trimmedQuantity === '' ? 0 : Number.parseInt(trimmedQuantity, 10);
            if (!Number.isInteger(parsedQuantity)) {
                window.alert('Please enter a valid non-negative whole number.');
                return;
            }
            const caseCount = Math.max(0, parsedQuantity);
            const formData = new FormData();
            formData.append('action', 'save_surveillance_metrics');
            formData.append('metric_id', id);
            formData.append('disease_name', diseaseName || '');
            formData.append('case_count', String(caseCount));
            fetch('dashboard_bhw.php', { method: 'POST', body: formData })
                .then(response => response.json())
                .then(data => {
                    if (!data.success) throw new Error(data.message || 'Unable to update quantity.');
                    const updated = normalizeSurveillanceMetrics(data.metrics || []);
                    if (caseCount <= 0) {
                        deletedSurveillanceMetricIds.add(String(id));
                        surveillanceData = surveillanceData.filter(record => String(record.id) !== String(id));
                        localStorage.removeItem('scancareSurveillanceMetrics');
                    } else {
                        surveillanceData = surveillanceData.map(record => String(record.id) === String(id) ? { ...record, caseCount } : record);
                    }
                    surveillanceData = updated.filter(record => !deletedSurveillanceMetricIds.has(String(record.id)));
                    const card = document.getElementById(`disease-card-${id}`);
                    if (caseCount <= 0) {
                        if (card) card.remove();
                    } else if (card) {
                        const countElement = document.getElementById(`disease-count-${id}`) || card.querySelector('#previewQuantityCount');
                        const quantityInput = card.querySelector('.disease-quantity-input');
                        const editButton = card.querySelector('[data-edit-quantity]');
                        if (countElement) countElement.textContent = String(caseCount);
                        card.dataset.caseCount = String(caseCount);
                        card.dataset.quantity = String(caseCount);
                        if (quantityInput) quantityInput.value = String(caseCount);
                        if (editButton) editButton.dataset.currentQty = String(caseCount);
                    }
                    updateHighestIncidenceDisplay();
                })
                .catch(error => window.alert(error.message));
        };

        function hydrateSurveillanceForm(metrics) {
            const latest = metrics[0] || {};
            const values = {
                reportingPeriod: latest.reportingPeriod || '',
                input_disease_name: latest.diseaseName || '',
                input_quantity_count: latest.caseCount || 0,
                input_trend_status: latest.trendStatus || 'Baseline',
                input_disease_meta: latest.metaNotes || ''
            };

            Object.entries(values).forEach(([key, value]) => {
                const input = document.getElementById(key) || document.querySelector(`[name="${key}"]`);
                if (input) input.value = value;
            });
        }

        function initSurveillanceModule() {
            const metrics = getSavedSurveillanceMetrics();
            renderSurveillancePreview(metrics);
            hydrateSurveillanceForm(metrics);

            const surveillanceForm = document.getElementById('surveillanceMetricsForm');
            const saveMessage = document.getElementById('survSaveMessage');
            if (!surveillanceForm) {
                return;
            }

            window.handleSurveillanceSubmit = function(event) {
                event.preventDefault();
                const submitButton = document.getElementById('saveSurveillanceBtn');
                if (!surveillanceForm || !submitButton || submitButton.dataset.saving === 'true') return;

                const formData = new FormData(surveillanceForm);
                formData.set('action', 'save_surveillance_metrics');
                formData.set('case_count', document.getElementById('input_quantity_count').value || '0');
                formData.set('meta_notes', document.getElementById('input_disease_meta').value);

                const originalText = submitButton.innerHTML;
                submitButton.dataset.saving = 'true';
                submitButton.disabled = true;
                submitButton.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Saving...';

                fetch('dashboard_bhw.php', { method: 'POST', body: formData })
                    .then(response => {
                        const rawResponsePromise = response.text();
                        return rawResponsePromise.then(rawResponse => {
                            console.debug('Surveillance save raw response:', rawResponse);
                            if (!response.ok) {
                                throw new Error(`Surveillance save failed with HTTP ${response.status}: ${rawResponse.slice(0, 300)}`);
                            }
                            try {
                                return JSON.parse(rawResponse);
                            } catch (parseError) {
                                throw new Error(`Invalid surveillance JSON response: ${rawResponse.slice(0, 300)}`);
                            }
                        });
                    })
                    .then(data => {
                        if (!data.success) throw new Error(data.message || 'Unable to save metrics.');
                        const responseId = data.id || data.created_id;
                        const submittedName = String(formData.get('disease_name') || '').trim();
                        const submittedCount = Number(formData.get('case_count') || 0);
                        const updated = (Array.isArray(data.metrics) ? normalizeSurveillanceMetrics(data.metrics) : []).map(record => {
                            if (responseId && record.diseaseName === submittedName && record.caseCount === submittedCount) {
                                return { ...record, id: Number(responseId) };
                            }
                            return record;
                        });
                        surveillanceData = updated;
                        renderSurveillancePreview(updated);
                        if (saveMessage) {
                            saveMessage.classList.remove('hidden');
                            setTimeout(() => saveMessage.classList.add('hidden'), 1600);
                        }
                        try {
                            if (typeof BroadcastChannel !== 'undefined') {
                                const channel = new BroadcastChannel('scancare-surveillance');
                                channel.postMessage({ type: 'update', metrics: updated });
                                channel.close();
                            }
                        } catch (error) { console.warn('BroadcastChannel failed:', error); }
                    })
                    .catch(error => { console.error('Error saving surveillance metrics:', error); alert(error.message); })
                    .finally(() => {
                        submitButton.dataset.saving = 'false';
                        submitButton.disabled = false;
                        submitButton.innerHTML = originalText;
                    });
            };
        }

        // ====================================================================
        // Publish helper (global) - allows button onclick to work even if init fails
        function publishSurveillanceMetrics(evt) {
            return window.handleSurveillanceSubmit(evt);
        }

        // PAGE INITIALIZATION
        // ====================================================================
        document.addEventListener('DOMContentLoaded', function() {
            console.log('BHW Dashboard initialized');
            console.log('Worker ID:', '<?php echo htmlspecialchars($worker_id); ?>');
            console.log('Worker Name:', '<?php echo htmlspecialchars($worker_name); ?>');
            initSurveillanceModule();
        });
        // ====================================================================
        // FOLLOW-UP SCHEDULING FUNCTIONS
        // ====================================================================
        
        /**
         * Flag appointment for follow-up check-up
         * Updates status to 'flagged' so it appears in the Follow-up Check-up tab
         */
        function showFollowupScheduleModal(residentId, residentName, appointmentId) {
            if (confirm(`Flag ${residentName} for a follow-up check-up visit?`)) {
                // AJAX call to update appointment status to 'flagged' in database
                fetch('', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=update_appointment_status&appointment_id=' + appointmentId + '&status=flagged'
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(`✓ ${residentName} has been flagged for follow-up check-up.\n\nTheir record will now appear in the "Follow-up Check-up" tab where you can set the specific date and time for their return visit.`);
                        window.location.href = '?module=appointments&sub=followup';
                    } else {
                        alert('Error: ' + (data.message || 'Failed to flag appointment'));
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('Error flagging appointment');
                });
            }
        }
        
        /**
         * Update follow-up appointment date
         */
        function updateFollowupDate(appointmentId, newDate) {
            if (!newDate) {
                alert('Please select a valid date');
                return;
            }
            
            console.log(`Updating appointment ${appointmentId} follow-up date to: ${newDate}`);
            
            // AJAX call to update database
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=update_followup_date&appointment_id=' + appointmentId + '&follow_date=' + encodeURIComponent(newDate)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Follow-up date updated successfully');
                } else {
                    alert('Error updating date: ' + (data.message || 'Unknown error'));
                }
            })
            .catch(err => {
                console.error('Error:', err);
                alert('Error saving follow-up date');
            });
        }
        
        /**
         * Update follow-up appointment time
         */
        function updateFollowupTime(appointmentId, newTime) {
            if (!newTime) {
                alert('Please select a valid time');
                return;
            }
            
            console.log(`Updating appointment ${appointmentId} follow-up time to: ${newTime}`);
            
            // AJAX call to update database
            fetch('', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'action=update_followup_time&appointment_id=' + appointmentId + '&follow_time=' + encodeURIComponent(newTime)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    console.log('Follow-up time updated successfully');
                } else {
                    alert('Error updating time: ' + (data.message || 'Unknown error'));
                }
            })
            .catch(err => {
                console.error('Error:', err);
                alert('Error saving follow-up time');
            });
        }

        // ====================================================================
        // CLEAR MEDICAL HISTORY FUNCTION
        // ====================================================================
        /**
         * Clear all medical history records for a patient
         * Includes confirmation dialog and visual feedback
         */
        function clearMedicalHistory(patientId, evt) {
            // Show confirmation dialog
            const confirmMsg = `⚠️ WARNING: This action is PERMANENT!\n\nAre you sure you want to clear ALL medical visit history for this patient?\n\nThis will delete all consultation records, treatments, and notes.`;
            
            if (!confirm(confirmMsg)) {
                console.log('Medical history clear cancelled by user');
                return;
            }
            
            // Additional confirmation for safety
            const doubleConfirm = confirm(`This action cannot be undone.\n\nClick OK to permanently clear the medical history.`);
            
            if (!doubleConfirm) {
                console.log('Medical history clear cancelled by user (second confirmation)');
                return;
            }
            
            console.log(`🗑️ Clearing medical history for patient ID: ${patientId}`);
            
            // Find and disable the clear button
            const clearBtn = evt?.target || document.getElementById(`clearHistoryBtn_${patientId}`) || null;
            if (clearBtn) {
                clearBtn.disabled = true;
                const originalHTML = clearBtn.innerHTML;
                clearBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Clearing...';
                
                // AJAX call to clear medical history
                fetch('', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=clear_medical_history&patient_id=' + patientId
                })
                .then(response => {
                    console.log('Clear history response status:', response.status);
                    return response.json();
                })
                .then(data => {
                    console.log('✅ Clear history response:', data);
                    
                    if (data.success) {
                        alert(`✓ Medical history cleared successfully!\n\n${data.message}`);
                        console.log(`Reloading page to refresh medical history display...`);
                        // Reload page to refresh the medical history display
                        setTimeout(() => {
                            location.reload();
                        }, 500);
                    } else {
                        alert('❌ Error clearing medical history:\n\n' + (data.message || 'Unknown error'));
                        clearBtn.disabled = false;
                        clearBtn.innerHTML = originalHTML;
                        console.error('Server error:', data);
                    }
                })
                .catch(err => {
                    console.error('🔴 Network/Fetch error:', err);
                    alert('❌ Error clearing medical history:\n\n' + err.message + '\n\nPlease check your connection and try again.');
                    
                    // Restore button state
                    clearBtn.disabled = false;
                    clearBtn.innerHTML = originalHTML;
                });
            } else {
                console.error('Clear button not found!');
                alert('❌ Error: Could not find clear button. Please refresh the page and try again.');
            }
        }

        // ====================================================================
        // CLEAR FOLLOW-UP CHECK-UPS FUNCTION
        // ====================================================================
        /**
         * Clear all follow-up check-up records for a patient
         * Includes confirmation dialog and visual feedback
         */
        function clearFollowupCheckups(patientId) {
            // Show confirmation dialog
            const confirmMsg = `⚠️ WARNING: This action is PERMANENT!\n\nAre you sure you want to clear ALL scheduled follow-up check-ups for this patient?\n\nAll follow-up appointments will be removed.`;
            
            if (!confirm(confirmMsg)) {
                console.log('Follow-up check-ups clear cancelled by user');
                return;
            }
            
            // Additional confirmation for safety
            const doubleConfirm = confirm(`This action cannot be undone.\n\nClick OK to permanently clear the follow-up check-ups.`);
            
            if (!doubleConfirm) {
                console.log('Follow-up check-ups clear cancelled by user (second confirmation)');
                return;
            }
            
            console.log(`🗑️ Clearing follow-up check-ups for patient ID: ${patientId}`);
            
            // Find and disable the clear button
            const clearBtn = event ? event.target : null;
            if (clearBtn) {
                clearBtn.disabled = true;
                const originalHTML = clearBtn.innerHTML;
                clearBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Clearing...';
                
                // AJAX call to clear follow-up check-ups
                fetch('', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'action=clear_followup_checkups&patient_id=' + patientId
                })
                .then(response => {
                    console.log('Clear followup response status:', response.status);
                    return response.json();
                })
                .then(data => {
                    console.log('✅ Clear followup response:', data);
                    
                    if (data.success) {
                        alert(`✓ Follow-up check-ups cleared successfully!\n\n${data.message}`);
                        console.log(`Reloading page to refresh follow-up check-ups display...`);
                        // Reload page to refresh the follow-up check-ups display
                        setTimeout(() => {
                            location.reload();
                        }, 500);
                    } else {
                        alert('❌ Error clearing follow-up check-ups:\n\n' + (data.message || 'Unknown error'));
                        clearBtn.disabled = false;
                        clearBtn.innerHTML = originalHTML;
                        console.error('Server error:', data);
                    }
                })
                .catch(err => {
                    console.error('🔴 Network/Fetch error:', err);
                    alert('❌ Error clearing follow-up check-ups:\n\n' + err.message + '\n\nPlease check your connection and try again.');
                    
                    // Restore button state
                    clearBtn.disabled = false;
                    clearBtn.innerHTML = originalHTML;
                });
            } else {
                console.error('Clear button not found!');
                alert('❌ Error: Could not find clear button. Please refresh the page and try again.');
            }
        }

        // ====================================================================
        // CLEAR APPOINTMENT DETAILS FUNCTION (UI ONLY - PERSISTENT)
        // ====================================================================
        /**
         * Clear appointment details display from the dashboard (UI only)
         * Stores state in localStorage to persist across page refreshes
         * Does NOT delete any data from the database
         */
        function clearAppointmentDetails(patientId, evt) {
            // Show confirmation dialog
            const confirmMsg = `🧹 Clear Appointment Display\n\nThis will hide the appointments from the dashboard.\n\nℹ️ No data will be deleted from the database.\n\nThis will persist even after refreshing.`;
            
            if (!confirm(confirmMsg)) {
                console.log('Appointment details clear cancelled by user');
                return;
            }
            
            console.log(`🧹 Clearing appointment details display for patient ID: ${patientId} (UI only, persistent)`);
            
            try {
                // Get the appointments list container
                const appointmentsList = document.getElementById(`appointmentsList_${patientId}`);
                
                if (appointmentsList) {
                    // Replace with "cleared" message with restore button
                    appointmentsList.innerHTML = `
                        <div class="text-center py-8">
                            <i class="fas fa-check-circle text-4xl text-blue-200 mb-3 block"></i>
                            <p class="text-blue-800">Appointment details cleared from display.</p>
                            <button onclick="clearAppointmentClearFlag(${patientId})" style="margin-top: 12px; padding: 6px 12px; background-color: #3b82f6; color: white; border-radius: 4px; border: none; cursor: pointer; font-size: 12px;">Restore Appointments</button>
                        </div>
                    `;
                    
                    // Hide the clear button since there's nothing to clear anymore
                    const clearBtn = evt?.target || document.getElementById(`clearAppointmentDetailsBtn_${patientId}`);
                    if (clearBtn) {
                        clearBtn.style.display = 'none';
                    }
                    
                    // Store cleared state in localStorage (persists across page refreshes)
                    localStorage.setItem(`appointmentDetailsCleared_${patientId}`, 'true');
                    
                    console.log('✅ Appointment details hidden from display (UI only, database unchanged, state saved to localStorage)');
                    alert(`✓ Appointment details cleared from display!\n\nℹ️ Data remains in the database.\n💾 This will persist even after refreshing.`);
                } else {
                    console.error('Appointments list container not found!');
                    alert('❌ Error: Could not find appointments display. Please refresh and try again.');
                }
            } catch (err) {
                console.error('🔴 Error clearing appointment display:', err);
                alert('❌ Error: ' + err.message);
            }
        }

        // ====================================================================
        // RESTORE CLEARED APPOINTMENT DETAILS STATE ON PAGE LOAD
        // ====================================================================
        document.addEventListener('DOMContentLoaded', function() {
            // Get all appointment containers on the page
            const appointmentContainers = document.querySelectorAll('[id^="appointmentsList_"]');
            
            appointmentContainers.forEach(container => {
                // Extract patient ID from container ID (format: appointmentsList_PATIENT_ID)
                const match = container.id.match(/appointmentsList_(\d+)/);
                if (match) {
                    const patientId = match[1];
                    const clearKey = `appointmentDetailsCleared_${patientId}`;
                    
                    // Check if this patient's appointments were previously cleared
                    if (localStorage.getItem(clearKey) === 'true') {
                        console.log(`🔄 Restoring cleared state for appointment details of patient ${patientId}`);
                        
                        // Hide the appointments list
                        container.innerHTML = `
                            <div class="text-center py-8">
                                <i class="fas fa-check-circle text-4xl text-blue-200 mb-3 block"></i>
                                <p class="text-blue-800">Appointment details cleared from display.</p>
                                <button onclick="clearAppointmentClearFlag(${patientId})" style="margin-top: 12px; padding: 6px 12px; background-color: #3b82f6; color: white; border-radius: 4px; border: none; cursor: pointer; font-size: 12px;">Restore Appointments</button>
                            </div>
                        `;
                        
                        // Hide the clear button
                        const clearBtn = document.getElementById(`clearAppointmentDetailsBtn_${patientId}`);
                        if (clearBtn) {
                            clearBtn.style.display = 'none';
                        }
                    }
                }
            });
        });
        
        // Function to remove clear flag and reload page to show appointments
        window.clearAppointmentClearFlag = function(patientId) {
            localStorage.removeItem(`appointmentDetailsCleared_${patientId}`);
            location.reload();
        };
    </script>

    <!-- ========================================================================
         LOGOUT CONFIRMATION MODAL
         ======================================================================== -->
    <div id="bhwLogoutConfirmModal" style="display: none;" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div class="bg-white rounded-xl shadow-2xl max-w-sm w-full animate-in fade-in zoom-in duration-300">
            <!-- Modal Header -->
            <div class="px-6 py-6 border-b border-slate-200 flex items-center justify-center">
                <i class="fas fa-sign-out-alt text-4xl text-red-500"></i>
            </div>
            
            <!-- Modal Content -->
            <div class="px-6 py-6 text-center">
                <h2 class="text-2xl font-bold text-slate-900 mb-3">Log Out</h2>
                <p class="text-slate-600 mb-6">Are you sure you want to log out from your Health Worker account?</p>
            </div>
            
            <!-- Modal Footer -->
            <div class="px-6 py-4 border-t border-slate-200 flex items-center justify-center gap-3">
                <button type="button" onclick="closeBHWLogoutConfirmModal()" class="px-6 py-2 border border-slate-300 rounded-lg font-semibold text-slate-700 hover:bg-slate-50 transition-all">
                    Cancel
                </button>
                <button type="button" onclick="confirmBHWLogout()" class="px-6 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg font-semibold transition-all">
                    Log Out
                </button>
            </div>
        </div>
    </div>

    <!-- ========================================================================
         SETTINGS MODAL
         ======================================================================== -->
    <div id="settingsModal" style="display: none;" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div class="bg-white rounded-xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in duration-300">
            <!-- Modal Header -->
            <div class="sticky top-0 bg-white px-6 py-5 border-b border-slate-200 flex items-center justify-between">
                <div>
                    <h3 class="text-xl font-bold text-slate-900 flex items-center gap-2">
                        <i class="fas fa-cog text-[#454B1B]"></i> Settings
                    </h3>
                    <p class="text-xs text-slate-500 mt-1">Manage your preferences</p>
                </div>
                <button type="button" onclick="closeSettingsModal()" class="text-slate-400 hover:text-slate-600 transition-colors text-2xl leading-none" aria-label="Close modal">&times;</button>
            </div>
            
            <!-- Modal Content -->
            <div class="p-6 space-y-6">
                <!-- Appearance Section -->
                <div class="space-y-4">
                    <h4 class="font-semibold text-slate-900 flex items-center gap-2">
                        <i class="fas fa-palette text-[#454B1B]"></i> Appearance
                    </h4>
                    
                    <label class="flex items-center gap-3 cursor-pointer">
                        <input type="checkbox" id="darkModeToggle" class="w-4 h-4 rounded cursor-pointer">
                        <div>
                            <p class="font-medium text-slate-700">Dark Mode</p>
                            <p class="text-xs text-slate-500">Switch to dark theme</p>
                        </div>
                    </label>
                </div>

                <!-- Change Password Section -->
                <div class="border-t border-slate-200 pt-4">
                    <button type="button" onclick="changePassword()" class="w-full px-4 py-2.5 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-semibold transition-all flex items-center justify-center gap-2">
                        <i class="fas fa-key"></i> Change Password
                    </button>
                </div>
            </div>
            
            <!-- Modal Footer -->
            <div class="px-6 py-4 border-t border-slate-200 flex items-center justify-end gap-3">
                <button type="button" onclick="closeSettingsModal()" class="px-4 py-2 border border-slate-300 rounded-lg font-semibold text-slate-700 hover:bg-slate-50 transition-all">
                    Close
                </button>
                <button type="button" onclick="saveSettings()" style="background-color: #454B1B;" class="px-4 py-2 text-white rounded-lg font-semibold hover:opacity-95 transition-all">
                    Save Settings
                </button>
            </div>
        </div>
    </div>

    <!-- Edit Medicine Modal -->
    <div id="editMedicineModal" style="display: none;" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div class="bg-white rounded-xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in duration-300">
            <!-- Modal Header -->
            <div class="sticky top-0 bg-white px-6 py-5 border-b border-slate-200 flex items-center justify-between">
                <div>
                    <h3 class="text-xl font-bold text-slate-900 flex items-center gap-2">
                        <i class="fas fa-edit text-[#454B1B]"></i> Edit Medicine
                    </h3>
                    <p class="text-xs text-slate-500 mt-1">Update medicine details and inventory</p>
                </div>
                <button type="button" onclick="closeEditMedicineModal()" class="text-slate-400 hover:text-slate-600 transition-colors text-2xl leading-none" aria-label="Close modal">&times;</button>
            </div>
            
            <!-- Form Content -->
            <form id="editMedicineForm" onsubmit="handleEditMedicineSubmit(event)" class="p-6 space-y-5">
                <input type="hidden" id="editMedicineId" value="">
                
                <!-- Medicine Name -->
                <div>
                    <label for="editMedicineName" class="block text-sm font-semibold text-slate-700 mb-2">
                        <span class="text-red-500">*</span> Medicine Name
                    </label>
                    <input type="text" id="editMedicineName" name="medicine_name" 
                           placeholder="e.g., Paracetamol, Amoxicillin" 
                           class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent transition-all" 
                           required>
                </div>
                
                <!-- Dosage -->
                <div>
                    <label for="editMedicineDosage" class="block text-sm font-semibold text-slate-700 mb-2">Dosage/Strength</label>
                    <input type="text" id="editMedicineDosage" name="dosage" 
                           placeholder="e.g., 500mg" 
                           class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent transition-all">
                </div>
                
                <!-- Inventory Fields Grid -->
                <div class="grid grid-cols-3 gap-3">
                    <div>
                        <label for="editMedicineStock" class="block text-sm font-semibold text-slate-700 mb-2">
                            <span class="text-red-500">*</span> Total Stock
                        </label>
                        <input type="number" id="editMedicineStock" name="stock" 
                               min="0" 
                               class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent transition-all text-center" 
                               onchange="updateEditMedicineStatus()" required>
                    </div>
                    
                    <div>
                        <label for="editMedicineAvailable" class="block text-sm font-semibold text-slate-700 mb-2">Available</label>
                        <input type="number" id="editMedicineAvailable" name="available" 
                               min="0" 
                               class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent transition-all text-center" 
                               onchange="updateEditMedicineStatus()">
                    </div>
                    
                    <div>
                        <label for="editMedicineDispensed" class="block text-sm font-semibold text-slate-700 mb-2">Dispensed</label>
                        <input type="number" id="editMedicineDispensed" name="dispensed" 
                               min="0" 
                               class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent transition-all text-center">
                    </div>
                </div>
                
                <!-- Stock Status Preview -->
                <div class="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                    <p class="text-xs font-semibold text-amber-900 mb-2">📊 Stock Status:</p>
                    <div id="editMedicineStatusPreview" class="text-sm text-amber-800">
                        <span class="inline-flex items-center gap-1 px-3 py-1 bg-amber-100 text-amber-700 rounded-full font-medium text-xs">
                            <i class="fas fa-circle text-xs"></i> Status will update
                        </span>
                    </div>
                </div>
                
                <!-- Info Box -->
                <div class="p-3 bg-blue-50 border border-blue-200 rounded-lg text-xs text-blue-700">
                    <i class="fas fa-info-circle mr-2"></i>
                    <strong>Note:</strong> Available stock should not exceed total stock. If available drops to 0, status will change to "Out of Stock".
                </div>
                
                <!-- Form Actions -->
                <div class="flex gap-2 justify-end pt-4 border-t border-slate-200">
                    <button type="button" onclick="handleDeleteMedicine(event)" 
                            class="px-5 py-2.5 border border-red-500 bg-red-500/10 text-red-700 font-semibold rounded-lg hover:bg-red-500/20 transition-all flex items-center gap-2">
                        <i class="fas fa-trash-alt"></i> Delete
                    </button>
                    <button type="submit" style="background-color: #454B1B;" 
                            class="px-5 py-2.5 text-white rounded-lg font-semibold hover:opacity-95 transition-all flex items-center gap-2" id="editMedicineSubmitBtn">
                        <i class="fas fa-save"></i> Update Medicine
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Medicine Modal -->
    <div id="addMedicineModal" style="display: none;" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div class="bg-white rounded-xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in duration-300">
            <!-- Modal Header -->
            <div class="sticky top-0 bg-white px-6 py-5 border-b border-slate-200 flex items-center justify-between">
                <div>
                    <h3 class="text-xl font-bold text-slate-900 flex items-center gap-2">
                        <i class="fas fa-plus-circle text-[#454B1B]"></i> Add New Medicine
                    </h3>
                    <p class="text-xs text-slate-500 mt-1">Enter medicine details to add to inventory</p>
                </div>
                <button type="button" onclick="closeAddMedicineModal()" class="text-slate-400 hover:text-slate-600 transition-colors text-2xl leading-none" aria-label="Close modal">&times;</button>
            </div>
            
            <!-- Form Content -->
            <form id="addMedicineForm" onsubmit="handleAddMedicineSubmit(event)" class="p-6 space-y-5">
                <!-- Medicine Name -->
                <div>
                    <label for="addMedicineName" class="block text-sm font-semibold text-slate-700 mb-2">
                        <span class="text-red-500">*</span> Medicine Name
                    </label>
                    <input type="text" id="addMedicineName" name="medicine_name" 
                           placeholder="e.g., Paracetamol, Amoxicillin" 
                           class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent transition-all" 
                           required>
                    <p class="text-xs text-slate-500 mt-1">Generic or brand name of the medicine</p>
                </div>
                
                <!-- Dosage -->
                <div>
                    <label for="addMedicineDosage" class="block text-sm font-semibold text-slate-700 mb-2">Dosage/Strength</label>
                    <input type="text" id="addMedicineDosage" name="dosage" 
                           placeholder="e.g., 500mg, 250mg, 10ml" 
                           class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent transition-all">
                    <p class="text-xs text-slate-500 mt-1">Strength and form (tablet, capsule, liquid, etc.)</p>
                </div>
                
                <!-- Total Stock & Available Stock Grid -->
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label for="addMedicineTotalStock" class="block text-sm font-semibold text-slate-700 mb-2">
                            <span class="text-red-500">*</span> Total Stock
                        </label>
                        <input type="number" id="addMedicineTotalStock" name="quantity" 
                               min="0" value="0" placeholder="0" 
                               class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent transition-all" 
                               onchange="autoSyncAvailableStock()" required>
                        <p class="text-xs text-slate-500 mt-1">Initial stock count</p>
                    </div>
                    
                    <div>
                        <label for="addMedicineAvailableStock" class="block text-sm font-semibold text-slate-700 mb-2">Available Stock</label>
                        <input type="number" id="addMedicineAvailableStock" name="available_stock" 
                               min="0" value="0" placeholder="0" 
                               class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#454B1B] focus:border-transparent transition-all">
                        <p class="text-xs text-slate-500 mt-1">Will match total stock</p>
                    </div>
                </div>
                
                <!-- Stock Status Preview -->
                <div class="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <p class="text-xs font-semibold text-blue-900 mb-2">📊 Stock Status Preview:</p>
                    <div id="addMedicineStatusPreview" class="text-sm text-blue-800">
                        <span class="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-700 rounded-full font-medium text-xs">
                            <i class="fas fa-circle text-xs"></i> Status will be calculated
                        </span>
                    </div>
                </div>
                
                <!-- Form Actions -->
                <div class="flex gap-2 justify-end pt-4 border-t border-slate-200">
                    <button type="button" onclick="closeAddMedicineModal()" 
                            class="px-5 py-2.5 border border-slate-300 rounded-lg text-slate-700 font-semibold hover:bg-slate-50 transition-all">
                        <i class="fas fa-times mr-2"></i>Cancel
                    </button>
                    <button type="submit" style="background-color: #454B1B;" 
                            class="px-5 py-2.5 text-white rounded-lg font-semibold hover:opacity-95 transition-all flex items-center gap-2" id="addMedicineSubmitBtn">
                        <i class="fas fa-plus-circle"></i> Add Medicine
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Patient Selection Modal - REMOVED (Using Auto-Redirect Instead) -->

    <!-- Profile Dropdown & Settings Manager -->
    <script>
        // ====================================================================
        // PROFILE DROPDOWN MENU FUNCTIONS
        // ====================================================================
        function toggleProfileDropdown() {
            const dropdown = document.getElementById('profileDropdownMenu');
            const btn = document.getElementById('profileDropdownBtn');
            
            if (dropdown && btn) {
                if (dropdown.style.display === 'none' || dropdown.style.display === '') {
                    dropdown.style.display = 'block';
                    btn.classList.add('active');
                } else {
                    dropdown.style.display = 'none';
                    btn.classList.remove('active');
                }
            }
        }

        // Close dropdown when clicking outside
        document.addEventListener('click', function(event) {
            const container = document.querySelector('.profile-dropdown-container');
            if (container && !container.contains(event.target)) {
                const dropdown = document.getElementById('profileDropdownMenu');
                if (dropdown) {
                    dropdown.style.display = 'none';
                    const btn = document.getElementById('profileDropdownBtn');
                    if (btn) btn.classList.remove('active');
                }
            }

            const mobileNav = document.querySelector('.sidebar');
            const toggleBtn = document.getElementById('mobileNavToggleBtn');
            if (mobileNav && toggleBtn && !mobileNav.contains(event.target) && !toggleBtn.contains(event.target)) {
                mobileNav.classList.remove('active');
                toggleBtn.classList.remove('active');
                toggleBtn.setAttribute('aria-expanded', 'false');
            }
        });

        function toggleMobileNav() {
            const mobileNav = document.querySelector('.sidebar');
            const toggleBtn = document.getElementById('mobileNavToggleBtn');
            if (!mobileNav || !toggleBtn) return;

            const isActive = mobileNav.classList.toggle('active');
            toggleBtn.classList.toggle('active', isActive);
            toggleBtn.setAttribute('aria-expanded', isActive ? 'true' : 'false');
        }

        // ====================================================================
        // LOGOUT CONFIRMATION MODAL FUNCTIONS
        // ====================================================================
        function openBHWLogoutConfirmModal() {
            closeProfileDropdown();
            const modal = document.getElementById('bhwLogoutConfirmModal');
            if (modal) {
                modal.style.display = 'flex';
                document.body.style.overflow = 'hidden';
            } else {
                // If modal doesn't exist, create a simple confirmation
                if (confirm('Are you sure you want to log out?')) {
                    window.location.href = 'logout.php';
                }
            }
        }

        function closeBHWLogoutConfirmModal() {
            const modal = document.getElementById('bhwLogoutConfirmModal');
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }

        function confirmBHWLogout() {
            window.location.href = 'logout.php';
        }

        // Close modal when clicking outside
        document.addEventListener('DOMContentLoaded', function() {
            const modal = document.getElementById('bhwLogoutConfirmModal');
            if (modal) {
                modal.addEventListener('click', function(e) {
                    if (e.target === this) {
                        closeBHWLogoutConfirmModal();
                    }
                });
            }
        });

        // ====================================================================
        // SETTINGS MODAL STATE MANAGEMENT
        // ====================================================================
        let settingsOriginalState = {};
        let settingsSaveTriggered = false;

        function openSettingsModal() {
            settingsSaveTriggered = false;
            // Store the original state before opening modal
            settingsOriginalState = {
                darkMode: document.getElementById('darkModeToggle')?.checked || false
            };
            
            const modal = document.getElementById('settingsModal');
            if (modal) {
                modal.style.display = 'flex';
                document.body.style.overflow = 'hidden';
            }
        }

        function closeSettingsModal() {
            // Only restore original state if Save was NOT clicked
            if (!settingsSaveTriggered) {
                restoreSettingsState();
            }
            const modal = document.getElementById('settingsModal');
            if (modal) {
                modal.style.display = 'none';
                document.body.style.overflow = 'auto';
            }
        }

        function restoreSettingsState() {
            // Restore dark mode toggle to original state
            if (document.getElementById('darkModeToggle')) {
                document.getElementById('darkModeToggle').checked = settingsOriginalState.darkMode;
            }
            // Restore dark mode visual state
            applyDarkMode(settingsOriginalState.darkMode);
        }

        function applyDarkMode(enabled) {
            document.documentElement.classList.toggle('dark', enabled);
            document.documentElement.classList.toggle('dark-mode', enabled);
            document.body.classList.toggle('dark-mode', enabled);
        }

        // Listen for dark mode toggle changes (preview only, not saved until Save is clicked)
        document.addEventListener('DOMContentLoaded', function() {
            const darkModeToggle = document.getElementById('darkModeToggle');
            if (darkModeToggle) {
                darkModeToggle.addEventListener('change', function() {
                    // Apply visual change for preview
                    applyDarkMode(this.checked);
                });
            }
        });

        // ====================================================================
        // DROPDOWN CLOSE HELPER
        // ====================================================================
        function closeProfileDropdown() {
            const dropdown = document.getElementById('profileDropdownMenu');
            const btn = document.getElementById('profileDropdownBtn');
            if (dropdown) dropdown.style.display = 'none';
            if (btn) btn.classList.remove('active');
        }

        // ====================================================================
        // SETTINGS SAVE FUNCTION
        // ====================================================================
        function saveSettings() {
            const darkModeEnabled = document.getElementById('darkModeToggle')?.checked;

            // Save dark mode preference to localStorage
            localStorage.setItem('darkMode', darkModeEnabled ? 'enabled' : 'disabled');
            localStorage.setItem('theme', darkModeEnabled ? 'dark' : 'light');
            localStorage.setItem('scancare_theme', darkModeEnabled ? 'dark' : 'light');

            console.log('Saving BHW settings:', { darkModeEnabled });
            
            // Mark that Save was triggered
            settingsSaveTriggered = true;
            
            // Apply the dark mode immediately
            applyDarkMode(darkModeEnabled);
            
            alert('✓ Settings saved successfully!');
            closeSettingsModal();
        }

        // ====================================================================
        // CHANGE PASSWORD FUNCTION
        // ====================================================================
        function changePassword() {
            const currentPassword = prompt('Enter your current password:');
            if (!currentPassword) {
                return; // User cancelled
            }

            const newPassword = prompt('Enter your new password (min 6 characters):');
            if (!newPassword) {
                return; // User cancelled
            }

            if (newPassword.length < 6) {
                alert('❌ Password must be at least 6 characters long');
                return;
            }

            const confirmPassword = prompt('Confirm your new password:');
            if (!confirmPassword) {
                return; // User cancelled
            }

            if (confirmPassword !== newPassword) {
                alert('❌ New passwords do not match');
                return;
            }

            // Disable the button to prevent multiple submissions
            const btn = document.querySelector('[onclick="changePassword()"]');
            if (btn) {
                btn.disabled = true;
                btn.style.opacity = '0.6';
                btn.style.cursor = 'not-allowed';
            }

            // Send password change request to server
            fetch('change_password.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    currentPassword: currentPassword,
                    newPassword: newPassword,
                    confirmPassword: confirmPassword
                })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('HTTP error, status = ' + response.status);
                }
                return response.json();
            })
            .then(data => {
                if (btn) {
                    btn.disabled = false;
                    btn.style.opacity = '1';
                    btn.style.cursor = 'pointer';
                }

                if (data.success) {
                    alert('✓ ' + data.message);
                    closeSettingsModal();
                } else {
                    alert('❌ ' + (data.error || 'Failed to change password'));
                }
            })
            .catch(error => {
                if (btn) {
                    btn.disabled = false;
                    btn.style.opacity = '1';
                    btn.style.cursor = 'pointer';
                }
                console.error('Password change error:', error);
                alert('❌ An error occurred: ' + error.message);
            });
        }

        // ====================================================================
        // DARK MODE TOGGLE FUNCTION
        // ====================================================================
        function toggleDarkMode(enabled) {
            console.log('Dark mode toggled:', enabled);
            if (enabled) {
                document.body.classList.add('dark-mode');
                document.documentElement.classList.add('dark-mode');
            } else {
                document.body.classList.remove('dark-mode');
                document.documentElement.classList.remove('dark-mode');
            }
            localStorage.setItem('darkMode', enabled ? 'enabled' : 'disabled');
            console.log('Dark mode saved to localStorage:', localStorage.getItem('darkMode'));
        }

        // Initialize dark mode on page load
        window.addEventListener('DOMContentLoaded', function() {
            console.log('BHW Dashboard loaded, checking dark mode setting...');
            const savedDarkMode = localStorage.getItem('darkMode');
            console.log('Saved dark mode setting:', savedDarkMode);
            if (savedDarkMode === 'enabled') {
                document.body.classList.add('dark-mode');
                document.documentElement.classList.add('dark-mode');
                const toggle = document.getElementById('darkModeToggle');
                if (toggle) {
                    toggle.checked = true;
                    console.log('Dark mode enabled and toggle checked');
                }
            }
        });

        // Also initialize immediately in case DOMContentLoaded already fired
        (function() {
            const savedDarkMode = localStorage.getItem('darkMode');
            if (savedDarkMode === 'enabled') {
                document.body.classList.add('dark-mode');
                document.documentElement.classList.add('dark-mode');
                setTimeout(() => {
                    const toggle = document.getElementById('darkModeToggle');
                    if (toggle) {
                        toggle.checked = true;
                    }
                }, 50);
            }
        })();
    </script>

    <!-- Profile Picture Upload Handler -->
    <script>
        /**
         * Handle profile picture upload
         */
        async function handleProfileUpload(event) {
            const file = event.target.files[0];
            if (!file) return;
            let nativeFormSubmitted = false;

            // Validate file
            if (!validateProfileFile(file)) {
                return;
            }

            try {
                const formData = new FormData();
                formData.append('profile_picture', file);

                const response = await fetch('upload_profile.php', {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    }
                });

                // Check if response is ok
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                // Parse response text first to debug
                const responseText = await response.text();
                console.log('Upload response:', responseText);

                // Try to parse JSON
                let data;
                try {
                    data = JSON.parse(responseText);
                } catch (parseError) {
                    console.error('Failed to parse response as JSON:', parseError);
                    throw new Error('Invalid server response: ' + responseText.substring(0, 200));
                }

                if (data.success) {
                    // Update navbar profile picture
                    const navbarImg = document.getElementById('profileImageNavbar');
                    if (navbarImg) {
                        navbarImg.src = data.image_url;
                        navbarImg.style.display = 'block';
                        document.getElementById('profileInitials').style.display = 'none';
                    }

                    // Update dropdown profile picture
                    const dropdownImg = document.getElementById('dropdownProfileImage');
                    if (dropdownImg) {
                        dropdownImg.src = data.image_url;
                        dropdownImg.style.display = 'block';
                        const dropdownInitials = document.getElementById('dropdownInitials');
                        if (dropdownInitials) dropdownInitials.style.display = 'none';
                    }

                    if (!navbarImg || !dropdownImg) {
                        window.location.reload();
                        return;
                    }

                    showUploadStatus('✓ Profile picture uploaded successfully!', 'success');
                } else {
                    if ((data.message || '').toLowerCase().includes('session')) {
                        nativeFormSubmitted = true;
                        submitProfileUploadForm(event.target);
                        return;
                    }
                        showUploadStatus('❌ Upload failed: ' + (data.message || data.error || 'Server reported failure'), 'error');
                }
            } catch (error) {
                console.error('Upload error:', error);
                if (error.message.toLowerCase().includes('session')) {
                    nativeFormSubmitted = true;
                    submitProfileUploadForm(event.target);
                    return;
                }
                showUploadStatus('❌ ' + error.message, 'error');
            } finally {
                if (!nativeFormSubmitted) event.target.value = '';
            }
        }

        function submitProfileUploadForm(fileInput) {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'upload_profile.php';
            form.enctype = 'multipart/form-data';
            form.appendChild(fileInput);
            document.body.appendChild(form);
            form.submit();
        }

        /**
         * Validate profile file
         */
        function validateProfileFile(file) {
            const allowedTypes = ['image/jpeg', 'image/png'];
            const maxFileSize = 2 * 1024 * 1024; // 2MB

            if (!allowedTypes.includes(file.type)) {
                showUploadStatus('❌ Only JPG and PNG files are allowed', 'error');
                return false;
            }

            if (file.size > maxFileSize) {
                const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
                showUploadStatus(`❌ File size (${sizeMB}MB) exceeds 2MB limit`, 'error');
                return false;
            }

            return true;
        }

        /**
         * Show upload status message
         */
        function showUploadStatus(message, type) {
            // Create status element if it doesn't exist
            let statusEl = document.getElementById('profileUploadStatusMsg');
            if (!statusEl) {
                statusEl = document.createElement('div');
                statusEl.id = 'profileUploadStatusMsg';
                statusEl.style.position = 'fixed';
                statusEl.style.top = '80px';
                statusEl.style.right = '20px';
                statusEl.style.zIndex = '1000';
                statusEl.style.borderRadius = '8px';
                statusEl.style.padding = '12px 20px';
                statusEl.style.maxWidth = '300px';
                document.body.appendChild(statusEl);
            }

            statusEl.textContent = message;
            statusEl.style.display = 'block';
            statusEl.className = 'profile-upload-status ' + type;

            // Auto-hide after 4 seconds
            setTimeout(() => {
                statusEl.style.display = 'none';
            }, 4000);
        }

        /**
         * Initialize profile picture on page load
         */
        document.addEventListener('DOMContentLoaded', function() {
            initializeProfilePicture();
        });

        async function initializeProfilePicture() {
            try {
                // Fetch stored profile picture from database
                const response = await fetch('get_profile_picture.php');
                const data = await response.json();
                
                if (data.success && data.has_picture && data.profile_picture) {
                    // Display the stored profile picture in navbar
                    const navbarImg = document.getElementById('profileImageNavbar');
                    if (navbarImg) {
                        navbarImg.src = data.profile_picture;
                        navbarImg.style.display = 'block';
                        const profileInitials = document.getElementById('profileInitials');
                        if (profileInitials) profileInitials.style.display = 'none';
                    }
                    
                    // Display the stored profile picture in dropdown
                    const dropdownImg = document.getElementById('dropdownProfileImage');
                    if (dropdownImg) {
                        dropdownImg.src = data.profile_picture;
                        dropdownImg.style.display = 'block';
                        const dropdownInitials = document.getElementById('dropdownInitials');
                        if (dropdownInitials) dropdownInitials.style.display = 'none';
                    }
                } else {
                    // No profile picture stored, show initials
                    const workerNameEl = document.querySelector('[style*="color: #454B1B"][style*="font-weight: 600"]');
                    
                    if (workerNameEl) {
                        const nameText = workerNameEl.textContent.trim();
                        const initials = getInitials(nameText);
                        
                        // Update navbar initials
                        const profileInitials = document.getElementById('profileInitials');
                        if (profileInitials) {
                            profileInitials.textContent = initials;
                            profileInitials.style.display = 'block';
                        }
                        
                        const navbarImg = document.getElementById('profileImageNavbar');
                        if (navbarImg) navbarImg.style.display = 'none';
                        
                        // Update dropdown initials
                        const dropdownInitials = document.getElementById('dropdownInitials');
                        if (dropdownInitials) {
                            dropdownInitials.textContent = initials;
                            dropdownInitials.style.display = 'flex';
                        }
                        
                        const dropdownImg = document.getElementById('dropdownProfileImage');
                        if (dropdownImg) dropdownImg.style.display = 'none';
                    }
                }
            } catch (error) {
                console.error('Error initializing profile picture:', error);
                
                // Fallback to initials on error
                const workerNameEl = document.querySelector('[style*="color: #454B1B"][style*="font-weight: 600"]');
                if (workerNameEl) {
                    const nameText = workerNameEl.textContent.trim();
                    const initials = getInitials(nameText);
                    
                    // Update navbar initials
                    const profileInitials = document.getElementById('profileInitials');
                    if (profileInitials) {
                        profileInitials.textContent = initials;
                        profileInitials.style.display = 'block';
                    }
                    
                    // Update dropdown initials
                    const dropdownInitials = document.getElementById('dropdownInitials');
                    if (dropdownInitials) {
                        dropdownInitials.textContent = initials;
                        dropdownInitials.style.display = 'flex';
                    }
                }
            }
        }

        function getInitials(fullName) {
            if (!fullName) return '--';
            const parts = fullName.trim().split(' ');
            if (parts.length >= 2) {
                return (parts[0].charAt(0) + parts[parts.length - 1].charAt(0)).toUpperCase();
            }
            return fullName.substring(0, 2).toUpperCase();
        }
    </script>

    <script>
        const announcementStatusToast = document.getElementById('announcementStatusToast');
        if (announcementStatusToast) {
            window.setTimeout(function () {
                announcementStatusToast.remove();
            }, 2500);
        }

        document.querySelectorAll('[data-announcement-tab-link]').forEach(function (link) {
            link.addEventListener('click', function (event) {
                event.preventDefault();

                const mode = link.dataset.announcementMode || 'create';
                const state = link.dataset.announcementStateTab || <?php echo json_encode($announcementState); ?>;
                document.querySelectorAll('[data-announcement-panel]').forEach(function (panel) {
                    panel.hidden = panel.dataset.announcementPanel !== mode;
                });

                document.querySelectorAll('[data-announcement-state-tab]').forEach(function (stateLink) {
                    const active = stateLink.dataset.announcementStateTab === state;
                    stateLink.classList.toggle('border-[#3D4A1E]', active);
                    stateLink.classList.toggle('bg-[#3D4A1E]', active);
                    stateLink.classList.toggle('text-white', active);
                    stateLink.classList.toggle('border-slate-200', !active);
                    stateLink.classList.toggle('bg-white', !active);
                    stateLink.classList.toggle('text-slate-600', !active);
                });

                document.querySelectorAll('[data-announcement-item]').forEach(function (item) {
                    item.hidden = item.dataset.announcementItem !== state;
                });
                document.querySelectorAll('[data-announcement-empty]').forEach(function (emptyState) {
                    emptyState.hidden = emptyState.dataset.announcementEmpty !== state || <?php echo json_encode($announcementCounts); ?>[state] > 0;
                });

                document.querySelectorAll('[data-announcement-primary-tab]').forEach(function (modeLink) {
                    const active = modeLink.dataset.announcementMode === mode;
                    modeLink.classList.toggle('bg-[#3D4A1E]', active);
                    modeLink.classList.toggle('text-white', active);
                    modeLink.classList.toggle('text-slate-600', !active);
                    modeLink.classList.toggle('hover:bg-slate-100', !active);
                });

                const nextUrl = new URL(link.href, window.location.href);
                nextUrl.searchParams.set('module', 'announcements');
                nextUrl.searchParams.set('announcement_tab', mode);
                nextUrl.searchParams.set('announcement_state', state);
                window.history.replaceState({}, '', nextUrl);
            });
        });
    </script>

    <!-- Login Approval Notification System -->
    <script src="<?php echo htmlspecialchars(appPath('login-notification-system.js'), ENT_QUOTES, 'UTF-8'); ?>?v=3"></script>

</body>
</html>
